#!/bin/bash

if [ -f "$(dirname "$0")/versions.sh" ]; then
    echo "Sourcing versions.sh..."
    source "versions.sh"
else
    echo "versions.sh not found in the same directory."
    exit 1
fi
echo $NODE_VERSION
# Create the .tool-versions file

echo "nodejs ${NODE_VERSION}
erlang ${ERLANG_VERSION}
elixir ${ELIXIR_VERSION}" > .tool-versions

