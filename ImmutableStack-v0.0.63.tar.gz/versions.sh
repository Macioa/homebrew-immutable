#!/bin/bash
export NODE_VERSION="22.6.0"
export ERLANG_VERSION="27.0.1"
export ELIXIR_VERSION="1.16.0"