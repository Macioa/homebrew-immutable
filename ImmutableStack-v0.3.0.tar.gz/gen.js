"use strict";var hn=Object.create;var ie=Object.defineProperty;var yn=Object.getOwnPropertyDescriptor;var vn=Object.getOwnPropertyNames;var bn=Object.getPrototypeOf,Sn=Object.prototype.hasOwnProperty;var b=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var De=(e,t,n,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of vn(t))!Sn.call(e,a)&&a!==n&&ie(e,a,{get:()=>t[a],enumerable:!(r=yn(t,a))||r.enumerable});return e};var I=(e,t,n)=>(n=e!=null?hn(bn(e)):{},De(t||!e||!e.__esModule?ie(n,"default",{value:e,enumerable:!0}):n,e)),xn=e=>De(ie({},"__esModule",{value:!0}),e);var G=b((pe,me)=>{(function(e,t){typeof require=="function"&&typeof pe=="object"&&typeof me=="object"?me.exports=t():typeof define=="function"&&define.amd?define(function(){return t()}):e.pluralize=t()})(pe,function(){var e=[],t=[],n={},r={},a={};function s(l){return typeof l=="string"?new RegExp("^"+l+"$","i"):l}function o(l,d){return l===d?d:l===l.toLowerCase()?d.toLowerCase():l===l.toUpperCase()?d.toUpperCase():l[0]===l[0].toUpperCase()?d.charAt(0).toUpperCase()+d.substr(1).toLowerCase():d.toLowerCase()}function i(l,d){return l.replace(/\$(\d{1,2})/g,function(_,y){return d[y]||""})}function c(l,d){return l.replace(d[0],function(_,y){var v=i(d[1],arguments);return o(_===""?l[y-1]:_,v)})}function m(l,d,_){if(!l.length||n.hasOwnProperty(l))return d;for(var y=_.length;y--;){var v=_[y];if(v[0].test(d))return c(d,v)}return d}function f(l,d,_){return function(y){var v=y.toLowerCase();return d.hasOwnProperty(v)?o(y,v):l.hasOwnProperty(v)?o(y,l[v]):m(v,y,_)}}function h(l,d,_,y){return function(v){var O=v.toLowerCase();return d.hasOwnProperty(O)?!0:l.hasOwnProperty(O)?!1:m(O,O,_)===O}}function g(l,d,_){var y=d===1?g.singular(l):g.plural(l);return(_?d+" ":"")+y}return g.plural=f(a,r,e),g.isPlural=h(a,r,e),g.singular=f(r,a,t),g.isSingular=h(r,a,t),g.addPluralRule=function(l,d){e.push([s(l),d])},g.addSingularRule=function(l,d){t.push([s(l),d])},g.addUncountableRule=function(l){if(typeof l=="string"){n[l.toLowerCase()]=!0;return}g.addPluralRule(l,"$0"),g.addSingularRule(l,"$0")},g.addIrregularRule=function(l,d){d=d.toLowerCase(),l=l.toLowerCase(),a[l]=d,r[d]=l},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(l){return g.addIrregularRule(l[0],l[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(l){return g.addPluralRule(l[0],l[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(l){return g.addSingularRule(l[0],l[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(g.addUncountableRule),g})});var Ee=b(M=>{"use strict";Object.defineProperty(M,"__esModule",{value:!0});M.FORMAT_PLAIN=M.FORMAT_HTML=M.FORMATS=void 0;var Tt="html";M.FORMAT_HTML=Tt;var qt="plain";M.FORMAT_PLAIN=qt;var dr=[Tt,qt];M.FORMATS=dr});var Wt=b(S=>{"use strict";Object.defineProperty(S,"__esModule",{value:!0});S.UNIT_WORDS=S.UNIT_WORD=S.UNIT_SENTENCES=S.UNIT_SENTENCE=S.UNIT_PARAGRAPHS=S.UNIT_PARAGRAPH=S.UNITS=void 0;var Dt="words";S.UNIT_WORDS=Dt;var jt="word";S.UNIT_WORD=jt;var Ct="sentences";S.UNIT_SENTENCES=Ct;var Gt="sentence";S.UNIT_SENTENCE=Gt;var Ut="paragraphs";S.UNIT_PARAGRAPHS=Ut;var Ft="paragraph";S.UNIT_PARAGRAPH=Ft;var pr=[Dt,jt,Ct,Gt,Ut,Ft];S.UNITS=pr});var Pe=b(z=>{"use strict";Object.defineProperty(z,"__esModule",{value:!0});z.WORDS=void 0;var mr=["ad","adipisicing","aliqua","aliquip","amet","anim","aute","cillum","commodo","consectetur","consequat","culpa","cupidatat","deserunt","do","dolor","dolore","duis","ea","eiusmod","elit","enim","esse","est","et","eu","ex","excepteur","exercitation","fugiat","id","in","incididunt","ipsum","irure","labore","laboris","laborum","Lorem","magna","minim","mollit","nisi","non","nostrud","nulla","occaecat","officia","pariatur","proident","qui","quis","reprehenderit","sint","sit","sunt","tempor","ullamco","ut","velit","veniam","voluptate"];z.WORDS=mr});var zt=b(B=>{"use strict";Object.defineProperty(B,"__esModule",{value:!0});B.LINE_ENDINGS=void 0;var fr={POSIX:`
`,WIN32:`\r
`};B.LINE_ENDINGS=fr});var Bt=b(H=>{"use strict";Object.defineProperty(H,"__esModule",{value:!0});H.default=void 0;var _r=function(t){var n=t.trim();return n.charAt(0).toUpperCase()+n.slice(1)},gr=_r;H.default=gr});var Ht=b((K,ke)=>{"use strict";Object.defineProperty(K,"__esModule",{value:!0});K.default=void 0;var $r=function(){return typeof ke<"u"&&!!ke.exports},hr=$r;K.default=hr});var Kt=b(Z=>{"use strict";Object.defineProperty(Z,"__esModule",{value:!0});Z.default=void 0;var yr=function(){var t=!1;try{t=navigator.product==="ReactNative"}catch{t=!1}return t},vr=yr;Z.default=vr});var Zt=b(J=>{"use strict";Object.defineProperty(J,"__esModule",{value:!0});J.SUPPORTED_PLATFORMS=void 0;var br={DARWIN:"darwin",LINUX:"linux",WIN32:"win32"};J.SUPPORTED_PLATFORMS=br});var Jt=b(Y=>{"use strict";Object.defineProperty(Y,"__esModule",{value:!0});Y.default=void 0;var Sr=Zt(),xr=function(){var t=!1;try{t=process.platform===Sr.SUPPORTED_PLATFORMS.WIN32}catch{t=!1}return t},wr=xr;Y.default=wr});var Le=b(Q=>{"use strict";Object.defineProperty(Q,"__esModule",{value:!0});Q.default=void 0;var Or=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:0;return Array.apply(null,Array(t)).map(function(n,r){return r})},Ir=Or;Q.default=Ir});var Yt=b(X=>{"use strict";Object.defineProperty(X,"__esModule",{value:!0});X.default=void 0;var Rr=Mr(Le());function Mr(e){return e&&e.__esModule?e:{default:e}}var Ar=function(t,n){var r=(0,Rr.default)(t);return r.map(function(){return n()})},Er=Ar;X.default=Er});var Te=b(A=>{"use strict";Object.defineProperty(A,"__esModule",{value:!0});Object.defineProperty(A,"capitalize",{enumerable:!0,get:function(){return Pr.default}});Object.defineProperty(A,"isNode",{enumerable:!0,get:function(){return kr.default}});Object.defineProperty(A,"isReactNative",{enumerable:!0,get:function(){return Lr.default}});Object.defineProperty(A,"isWindows",{enumerable:!0,get:function(){return Tr.default}});Object.defineProperty(A,"makeArrayOfLength",{enumerable:!0,get:function(){return qr.default}});Object.defineProperty(A,"makeArrayOfStrings",{enumerable:!0,get:function(){return Dr.default}});var Pr=T(Bt()),kr=T(Ht()),Lr=T(Kt()),Tr=T(Jt()),qr=T(Le()),Dr=T(Yt());function T(e){return e&&e.__esModule?e:{default:e}}});var Xt=b(N=>{"use strict";Object.defineProperty(N,"__esModule",{value:!0});N.default=void 0;var jr=Pe(),qe=Te();function Cr(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function Qt(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function Gr(e,t,n){return t&&Qt(e.prototype,t),n&&Qt(e,n),Object.defineProperty(e,"prototype",{writable:!1}),e}function V(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Ur=function(){function e(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=t.sentencesPerParagraph,r=n===void 0?{max:7,min:3}:n,a=t.wordsPerSentence,s=a===void 0?{max:15,min:5}:a,o=t.random,i=t.seed,c=t.words,m=c===void 0?jr.WORDS:c;if(Cr(this,e),V(this,"sentencesPerParagraph",void 0),V(this,"wordsPerSentence",void 0),V(this,"random",void 0),V(this,"words",void 0),r.min>r.max)throw new Error("Minimum number of sentences per paragraph (".concat(r.min,") cannot exceed maximum (").concat(r.max,")."));if(s.min>s.max)throw new Error("Minimum number of words per sentence (".concat(s.min,") cannot exceed maximum (").concat(s.max,")."));this.sentencesPerParagraph=r,this.words=m,this.wordsPerSentence=s,this.random=o||Math.random}return Gr(e,[{key:"generateRandomInteger",value:function(n,r){return Math.floor(this.random()*(r-n+1)+n)}},{key:"generateRandomWords",value:function(n){var r=this,a=this.wordsPerSentence,s=a.min,o=a.max,i=n||this.generateRandomInteger(s,o);return(0,qe.makeArrayOfLength)(i).reduce(function(c,m){return"".concat(r.pluckRandomWord()," ").concat(c)},"").trim()}},{key:"generateRandomSentence",value:function(n){return"".concat((0,qe.capitalize)(this.generateRandomWords(n)),".")}},{key:"generateRandomParagraph",value:function(n){var r=this,a=this.sentencesPerParagraph,s=a.min,o=a.max,i=n||this.generateRandomInteger(s,o);return(0,qe.makeArrayOfLength)(i).reduce(function(c,m){return"".concat(r.generateRandomSentence()," ").concat(c)},"").trim()}},{key:"pluckRandomWord",value:function(){var n=0,r=this.words.length-1,a=this.generateRandomInteger(n,r);return this.words[a]}}]),e}(),Fr=Ur;N.default=Fr});var en=b(ne=>{"use strict";Object.defineProperty(ne,"__esModule",{value:!0});ne.default=void 0;var ee=Ee(),Vt=zt(),Wr=zr(Xt()),te=Te();function zr(e){return e&&e.__esModule?e:{default:e}}function Br(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function Nt(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function Hr(e,t,n){return t&&Nt(e.prototype,t),n&&Nt(e,n),Object.defineProperty(e,"prototype",{writable:!1}),e}function Kr(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var Zr=function(){function e(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:ee.FORMAT_PLAIN,r=arguments.length>2?arguments[2]:void 0;if(Br(this,e),this.format=n,this.suffix=r,Kr(this,"generator",void 0),ee.FORMATS.indexOf(n.toLowerCase())===-1)throw new Error("".concat(n," is an invalid format. Please use ").concat(ee.FORMATS.join(" or "),"."));this.generator=new Wr.default(t)}return Hr(e,[{key:"getLineEnding",value:function(){return this.suffix?this.suffix:!(0,te.isReactNative)()&&(0,te.isNode)()&&(0,te.isWindows)()?Vt.LINE_ENDINGS.WIN32:Vt.LINE_ENDINGS.POSIX}},{key:"formatString",value:function(n){return this.format===ee.FORMAT_HTML?"<p>".concat(n,"</p>"):n}},{key:"formatStrings",value:function(n){var r=this;return n.map(function(a){return r.formatString(a)})}},{key:"generateWords",value:function(n){return this.formatString(this.generator.generateRandomWords(n))}},{key:"generateSentences",value:function(n){return this.formatString(this.generator.generateRandomParagraph(n))}},{key:"generateParagraphs",value:function(n){var r=this.generator.generateRandomParagraph.bind(this.generator);return this.formatStrings((0,te.makeArrayOfStrings)(n,r)).join(this.getLineEnding())}}]),e}(),Jr=Zr;ne.default=Jr});var nn=b(j=>{"use strict";Object.defineProperty(j,"__esModule",{value:!0});Object.defineProperty(j,"LoremIpsum",{enumerable:!0,get:function(){return tn.default}});j.loremIpsum=void 0;var Yr=Ee(),k=Wt(),Qr=Pe(),tn=Xr(en());function Xr(e){return e&&e.__esModule?e:{default:e}}var Vr=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=t.count,r=n===void 0?1:n,a=t.format,s=a===void 0?Yr.FORMAT_PLAIN:a,o=t.paragraphLowerBound,i=o===void 0?3:o,c=t.paragraphUpperBound,m=c===void 0?7:c,f=t.random,h=t.sentenceLowerBound,g=h===void 0?5:h,l=t.sentenceUpperBound,d=l===void 0?15:l,_=t.units,y=_===void 0?k.UNIT_SENTENCES:_,v=t.words,O=v===void 0?Qr.WORDS:v,C=t.suffix,re=C===void 0?"":C,oe={random:f,sentencesPerParagraph:{max:m,min:i},words:O,wordsPerSentence:{max:d,min:g}},q=new tn.default(oe,s,re);switch(y){case k.UNIT_PARAGRAPHS:case k.UNIT_PARAGRAPH:return q.generateParagraphs(r);case k.UNIT_SENTENCES:case k.UNIT_SENTENCE:return q.generateSentences(r);case k.UNIT_WORDS:case k.UNIT_WORD:return q.generateWords(r);default:return""}};j.loremIpsum=Vr});var to={};module.exports=xn(to);var pn=I(require("path"));var je=require("fs"),le=I(require("path"));var p=(e,t=null)=>(Object.keys(e).forEach(n=>{let r=e[n];if(r==null)throw console.error(`${n} in StringOnlyMap cannot be null or undefined.
     Caller: ${t}`),`${n} in StringOnlyMap cannot be null or undefined. Caller: ${t}`}),!0),ae=(e,t)=>t.reduce((n,r)=>n?.[r],e);var se=(e,t,n)=>{let r=t.pop(),a=ae(e,t);a&&typeof a=="object"?a[r]=n:se(e,t,{[r]:n})};var ce=null,L={_name:null,commands:[],file_modifications:{}},Ce=({command:e,dir:t},n=null)=>{L.commands.push({command:e,dir:t,caller:n||"unreferenced"})},ue=({filename:e,dir:t},n=null)=>{p({filename:e,dir:t},n);let r=wn(t),{file_modifications:a}=L,s=r.split("/").filter(c=>c).concat([e]),i=(ae(a,s)||[]).concat([n||"unreferenced"]);return se(L,["file_modifications",...s],i),L},Ge=(e,t)=>{L._name=t;let n=JSON.stringify(L,null,2);(0,je.writeFileSync)(le.default.resolve(e,`.immutable_log_${t}.json`),n,"utf8")},Ue=(e,t=null)=>{let n=e.split("/").filter(s=>s),r=n.slice(-1)[0],a=n.slice(0,-1).join("/");return ue({filename:r,dir:a},t)},Fe=e=>{ce=le.default.resolve(e).replace(/^[^\w]+/,"")},wn=e=>(e=e.replace(/^[^\w]+/,""),(ce?e.replace(ce,""):e).replace(/^[^\w]+/,""));var de=99,On={GREEN:"\x1B[32m%s\x1B[0m",RED:"\x1B[31m%s\x1B[0m",YELLOW:"\x1B[33m%s\x1B[0m",BLUE:"\x1B[34m%s\x1B[0m"},We=e=>(de=e,de),u=({level:e,color:t},...n)=>{e<=de&&(n=t?[On[t],...n]:n,console.log(...n))};var He=I(require("fs")),Ke=I(G());var ze=require("fs/promises"),D=I(require("path"));var Be=async()=>{try{u({level:8},`Getting App Data from mix.exs in ${process.cwd()}`);let e=await(0,ze.readFile)("mix.exs","utf-8"),t="";e.replace(/defmodule (\w+)(\.Umbrella){0,1}\.MixProject do/g,(c,m)=>t=m),u({level:2},`Found app: ${t}`);let n=t.replace(/([A-Z])/g,"_$1").toLowerCase().slice(1),r=process.cwd(),a=D.default.join(r,"apps"),s=D.default.join(a,n),o=D.default.join(a,`${n}_ui`),i=D.default.join(a,`${n}_web`);return{AppNameCamel:t,AppNameSnake:n,ProjectDir:r,AppDir:a,LibDir:s,UiDir:o,WebDir:i,UmbrellaDir:r}}catch(e){console.error(`Could not get AppName from mix.exs
${e}`)}};var In=(e,t,n={})=>(e.match(/interface (\w+).*?extends GenType<.*?> \{\}/gs)?.map(r=>Rn(r,t)).forEach(({name:r,ts:a,ex:s})=>{let o=Object.keys(a||{}).length>0,i=Object.keys(s||{}).length>0;r&&o&&i&&(n[r]={ts:a,ex:s})}),n),Rn=(e,t,n={name:null,ts:{},ex:{}})=>{let r=e.match(/interface\s(\w+)/)?.[1],a=/([a-zA-Z0-9_\[\]]+):([a-zA-Z\s\|0-9_\[\]]+){0,20}/gs;return Object.assign(n,{name:r}),e.replace(a,(s,o,i)=>(i=i.trim(),n.ex[o]=i,n.ts[o]=t[i]||i,s)),n},Mn=(e,t={})=>{let n=/type\s(\w+)\s=\s(\w+)\s&\s\{\s__brand\:/gs;return e.replace(n,(r,a,s)=>(t[a]=s,r)),t},An=e=>{let t=/Immutable\s\:\sImmutableGenerator\s=([\s\S]*?)\/\*.*DECLARATIONS/,n=e.match(t)?.[1].replace(/(\w+):/g,'"$1":')?.replace(/,\s*\}/gs,"}")?.replace(/\/\/([\w ,.]+)/g,"")||"{}";u({level:8},"Found generator data: ",n);let r=n.replace(/\"([\w]+)\"\:/g,(m,f)=>`Q_HLD${f}Q_HLD:`);u({level:9},"Negated keys: ",r);let a=r.replace(/\\/g,"\\\\");u({level:9},"Doubled escape chars: ",a);let s=a.replace(/(['`\"])(.*)(\".*\")(.*)(['`\"])/g,(m,f,h,g,l,d)=>{let _=f==d?g.replace(/\"/g,'\\"'):g;return`${f}${h}${_}${l}${d}`});u({level:9},"Escaped inner quotes: ",s);let o=s.replace(/[\'\`]/g,'"');u({level:9},"Single quotes turned double: ",o);let i=o.replace(/Q_HLD/g,'"');return u({level:9},"Restored keys: ",i),u({level:3,color:"GREEN"},"Generating from: "),u({level:3,color:"YELLOW"},i),JSON.parse(i)},En=({name:e})=>{u({level:9},"Computing names for: ",e);let t=a=>{let s=a.split("_"),o=(0,Ke.default)(s.pop()||"");return[...s,o].join("_")},n=e.split("_").map(a=>a.charAt(0).toUpperCase()+a.slice(1)).join(""),r=t(e);return u({level:6},"Computed names: ",{name:e,pluralName:r,camelName:n}),{name:e,pluralName:r,camelName:n}},Ze=async e=>{let t=He.readFileSync(e,"utf8");u({level:3,color:"BLUE"},`
Reading genfile: ${e}`),u({level:5},"Analyzing types...");let n=Mn(t);u({level:5},"Reading generator...");let r=await An(t),a={...await Be(),...r,...En(r)};u({level:3},"Generator: ",a);let s=In(t,n);return u({level:5},"Generated types: ",s),{generator:a,genTypes:s}};var Ye=require("child_process"),Qe=require("fs"),Xe=require("path");var Je={dir:"",command:"",options:{forceReturnOnPrompt:!0}};var Ve=async(e,t=null)=>{let{dir:n,command:r,options:a}={...Je,...e},{timeoutResolve:s,timeoutReject:o,forceReturnOnPrompt:i,resolveOnErrorCode:c}={...Je.options,...a};return Ce({command:r,dir:n},t),u({level:4,color:"YELLOW"},`Executing: ${r}`),u({level:4},`      in ${n}...`),new Promise((m,f)=>{let h=(0,Xe.resolve)(n);(0,Qe.mkdirSync)(h,{recursive:!0});let[g,...l]=r.split(" "),d=(0,Ye.spawn)(g,l,{cwd:h,shell:!0});d.stdout.on("data",_=>{u({level:5},_.toString()),a?.prompts&&a.prompts.forEach(([y,v])=>{if(_.toString().includes(y)){let O=v+(i?`
`:"");d.stdin.write(O)}})}),d.stderr.on("error",_=>{console.error(`Could not run ${r}:
      ${_}`),f(_||`Could not run ${r}`)}),d.on("close",_=>{!c&&_?(console.error(`Process exited with exit code ${_}:
       ${r}`),f(`Process exited with ${_}`)):m(n)}),s&&setTimeout(()=>m(n),s),o&&setTimeout(()=>f(new Error("Time out")),o)})};var Ne=async({generate:e,WebDir:t},n)=>{let{schema:r,databaseModel:a}=e,s=(n.Schema||n.ImmutableGlobal)?.ex||{};u({level:9},"Gen schema source: ",s);let o=`mix phx.gen.schema ${r} ${a}`+Object.keys(s).map(i=>` ${i}:${s[i]}`).join("")+" --no-prompts";return u({level:2,color:"BLUE"},`Generating Phoenix Schema and Migrations for ${r}`),Ve({command:o,dir:t||"."},"gen_schema")};var ct=require("path");var R=require("fs"),F=require("path");var fe=require("child_process"),U=async e=>new Promise((t,n)=>{let r=e.endsWith(".tsx")||e.endsWith(".ts"),a=e.endsWith(".ex")||e.endsWith(".exs");r&&(0,fe.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),a&&(0,fe.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)});var w=async({filename:e,dir:t,content:n},r=null)=>{ue({filename:e,dir:t},r);let a=e.replace(/(.*)\.(\w+)$/,(i,c,m)=>`${c.replace(/\./g,"/")}.${m}`),s=(0,F.resolve)(t),o=(0,F.join)(t,a);return u({level:3},`Generating ${a} ...`),u({level:9},n),(0,R.mkdirSync)(s,{recursive:!0}),(0,R.existsSync)(o)&&(0,R.unlinkSync)(o),(0,R.writeFileSync)(o,n,"utf8"),await U(o),[o]};var $=(e,t)=>{let n=t(e);u({level:5},"Generating header for:",n);let r="";return n.split(/[ \n]+do/)[0].replace(/(defp{0,1})(.*)/s,(a,s,o)=>r=o),r=r.replace(/,{0,1}\s*(do){0,1}$/,"").trim(),u({level:5},"Generated header:",r),r};var Pn=({pluralName:e},t)=>(p({pluralName:e},"comment_main"),`
  @doc """
    Create ${e} by id.

    ## Examples
    ${t}
    """
`),kn=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"comment_many"),`
create_${e}(attrs) when is_list attrs -> Creates ${t} from an array of attrs.

  ## Examples
      iex> create_${e}([%{field: value}, %{field: value}])
      {:ok, [%${n}{}, %${n}{}]}
`),Ln=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
 create_${e}(attrs \\ %{}) -> Creates a ${e}.

  ## Examples
      iex> create_${e}(%{field: value})
      {:ok, %${t}{}}
      iex> create_${e}(%{field: bad_value})
      {:error, %Ecto.Changeset{}}
`),_e=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"create_many"),`
  def create_${e}(attrs) when is_list(attrs) do
    attrs
    |> Chunk.apply(fn attr_chunk ->
      changesets = change_${e}(attr_chunk)

      case Enum.split_with(changesets, & &1.valid?) do
        {valid, []} ->
          created = Chunk.prep(valid)
          {_, result} = Repo.insert_all(${n}, created, returning: true)
          {:ok, result, []}

        {[], invalid} ->
          {:error, [], invalid}

        {valid, invalid} ->
          created = Chunk.prep(valid)
          {_, result} = Repo.insert_all(${n}, created, returning: true)
          {:partial_success, result, invalid}
      end
    end)
    |> Chunk.flat_reduce()
  end
`),ge=({genName:e})=>(p({genName:e},"create_single"),`
  def create_${e}(${e}_params) when is_map(${e}_params) do
    changeset = change_${e}(${e}_params)
    if changeset.valid?, do: Repo.insert(changeset), else: {:error, changeset}
  end
`),Tn=[{id:"create_many",fn:_e,header:e=>$(e,_e)},{id:"create_single",fn:ge,header:e=>$(e,ge)}],qn={create_many:kn,create_single:Ln},Dn={create_many:_e,create_single:ge},et=(e,t)=>{let n=Tn.map(({id:c,fn:m,header:f})=>({id:c,def:m(t),header:f(t)}));u({level:2},"Gen Create APIS",n);let a=n.filter(({header:c})=>e.includes(c)).map(({id:c})=>c||""),s=a.map(c=>qn[c](t)).join(`
`),o=Pn(t,s),i=a.map(c=>Dn[c](t)).join(`
`);return{result:o+`
`+i,remaining_apis:e.filter(c=>!n.map(({header:m})=>m).includes(c))}};var jn=({pluralName:e},t)=>(p({pluralName:e},"comment_main"),`
  @doc """
    Delete ${e} by id.

    ## Examples
    ${t}
    """
`),Cn=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_many"),`
  ## Examples
      iex> delete_${e}([${e}, ${e}])
      {:ok, [%${t}{}, %${t}{}]}
`),tt=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
  ## Examples
      iex> delete_${e}(${e})
      {:ok, %${t}{}}
      iex> delete_${e}(${e})
      {:error, %Ecto.Changeset{}}
`),$e=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"delete_many"),`
  def delete_${e}(${t}) when is_list(${t}) do
    result =
      ${t}
      |> Chunk.apply(fn ${e}_chunk ->
        ids =
          Enum.map(${e}_chunk, fn
            id when is_binary(id) -> id
            ${e} when is_map(${e}) -> MapUtil.get(${e}, :id)
          end)

        {count, _} =
          from(b in ${n}, where: b.id in ^ids)
          |> Repo.delete_all()

        case count do
          0 -> {:error, 0, length(ids)}
          count when count == length(ids) -> {:ok, count, 0}
          _ -> {:partial_success, count, length(ids) - count}
        end
      end)
      |> Chunk.flat_reduce()

    if elem(result, 0) == :error,
      do: {:error, :not_found},
      else: result
  end
`),he=({genName:e})=>(p({genName:e},"delete_single"),`
  def delete_${e}(${e}_params) when is_map(${e}_params), do:  MapUtil.get(${e}_params, :id) |> delete_${e}
`),ye=({genName:e})=>(p({genName:e},"delete_single_by_id"),`
    def delete_${e}(id) when is_binary(id), do: get_${e}!(id) |> Repo.delete!    
    `),Gn=[{id:"delete_many",fn:$e,header:e=>$(e,$e)},{id:"delete_single",fn:he,header:e=>$(e,he)},{id:"delete_single_by_id",fn:ye,header:e=>$(e,ye)}],Un={delete_many:Cn,delete_single:tt,delete_single_by_id:tt},Fn={delete_many:$e,delete_single:he,delete_single_by_id:ye},nt=(e,t)=>{let n=Gn.map(({id:i,fn:c,header:m})=>({id:i,def:c(t),header:m(t)})).filter(({header:i})=>e.includes(i)),r=n.map(({id:i})=>i||""),a=r.map(i=>Un[i](t)).join(`
`),s=jn(t,a),o=r.map(i=>Fn[i](t)).join(`
`);return{result:s+`
`+o,remaining_apis:e.filter(i=>!n.map(({header:c})=>c).includes(i))}};var Wn=({pluralName:e},t)=>(p({pluralName:e},"comment_main"),`
@doc """
    Retrieve ${e} by id.

    ## Examples
  ${t}
"""
  `),zn=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"comment_many"),`
    get_${e}!(ids) when is_list(ids) -> Gets specified ${t}.
    
    iex> get_${e}!([123, 456])
      [%${n}{}, %${n}{}]
      %${n}{}
`),rt=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
  get_${e}!(id) -> Gets a single ${e}.
      Raises \`Ecto.NoResultsError\` if the ${t} does not exist.

  ## Examples
      iex> get_${e}!(123)
      %${t}{}
      iex> get_${e}!(456)
      ** (Ecto.NoResultsError)    
`),ve=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"get_many"),`
  def get_${e}!(${t}) when is_list(${t}) do
    ids =
      Enum.map(${t}, fn
        id when is_binary(id) -> id
        ${e} when is_map(${e}) -> MapUtil.get(${e}, :id)
      end)

    from(b in ${n}, where: b.id in ^ids)
    |> Repo.all()
  end
`),be=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"get_single"),`
  def get_${e}!(${e}_params) when is_map(${e}_params) do
    id = MapUtil.get(${e}_params, :id) 
    Repo.get!(${t}, id)
  end
    `),Se=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"get_single_by_id"),`
  def get_${e}!(id) when is_binary(id), do: Repo.get!(${t}, id)    
`),Bn=[{id:"get_many",fn:ve,header:e=>$(e,ve)},{id:"get_single",fn:be,header:e=>$(e,be)},{id:"get_single_by_id",fn:Se,header:e=>$(e,Se)}],Hn={get_many:zn,get_single:rt,get_single_by_id:rt},Kn={get_many:ve,get_single:be,get_single_by_id:Se},ot=(e,t)=>{let n=Bn.map(({id:i,fn:c,header:m})=>({id:i,def:c(t),header:m(t)})).filter(({header:i})=>e.includes(i)),r=n.map(({id:i})=>i||""),a=r.map(i=>Hn[i](t)).join(`
`),s=Wn(t,a),o=r.map(i=>Kn[i](t)).join(`
`);return{result:s+`
`+o,remaining_apis:e.filter(i=>!n.map(({header:c})=>c).includes(i))}};var Zn=({pluralName:e,genCamelName:t})=>(p({pluralName:e,genCamelName:t},"comment_standard"),`
@doc """
Returns the list of ${e}.

## Examples
    iex> list_${e}()
    [%${t}{}, ...]

"""
    `),xe=({pluralName:e,genCamelName:t})=>(p({pluralName:e,genCamelName:t},"list_standard"),`
    def list_${e}(page_query \\\\ %{}), do: Paginate.apply(${t}, Repo, page_query)
    `),Jn=({pluralName:e,genCamelName:t})=>(p({pluralName:e,genCamelName:t},"comment_dynamic"),`
@doc """
Use a Dynamic Query to get a list of ${e} with specific values for any directly queryable fields.
"""
    `),we=({pluralName:e,genCamelName:t})=>(p({pluralName:e,genCamelName:t},"list_dynamic"),`
def list_${e}_by(entity_queries, page_queries \\\\ %{}) do
  with {:ok, query, entity_queries} <- DynamicQuery.by_schema(entity_queries, ${t}),
       {:ok, result, page_queries} <- Paginate.apply(query, Repo, page_queries) do
    {:ok, result, Map.put(entity_queries, :page, page_queries)}
  end
end
`),Yn=[{id:"list_standard",fn:xe,header:e=>$(e,xe)},{id:"list_dynamic",fn:we,header:e=>$(e,we)}],Qn={list_standard:Zn,list_dynamic:Jn},Xn={list_standard:xe,list_dynamic:we},it=(e,t)=>{let n=Yn.map(({id:a,fn:s,header:o})=>({id:a,def:s(t),header:o(t)})).filter(({header:a})=>e.includes(a));return{result:n.map(({id:a})=>a||"").map(a=>Qn[a](t)+`
`+Xn[a](t)).join(`
`),remaining_apis:e.filter(a=>!n.map(({header:s})=>s).includes(a))}};var Vn=({pluralName:e},t)=>(p({pluralName:e},"comment_main"),`
  @doc """
    Update ${e} records.

    ## Examples
    ${t}
    """
`),Nn=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"comment_many"),`
update_${e}(${t}) when is_list ${t} -> Updates ${t} with an array of tuples [{${e}, attrs}].

## Examples
    iex> update_${e}([{%{field: new_value}}, {%{field: new_value}}])
    {:ok, [%${n}{}, %${n}{}]}
`),er=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
update_${e}(%${t}{} = ${e}, attrs) -> Updates a ${e}.

## Examples
    iex> update_${e}(${e}, %{field: new_value})
    {:ok, %${t}{}}
    iex> update_${e}(${e}, %{field: bad_value})
    {:error, %Ecto.Changeset{}}
`),Oe=({genName:e,pluralName:t,genCamelName:n})=>(p({genName:e,pluralName:t,genCamelName:n},"update_many"),`
def update_${e}(${t}) when is_list(${t}) do
  ${t}
  |> Chunk.apply(fn ${e}_chunk ->
    multi =
      Multi.new()
      |> Multi.run(:initial_query, fn repo, _ ->
        requested_ids = Enum.map(${e}_chunk, &MapUtil.get(&1, :id))

        found_${t} = from(b in ${n}, where: b.id in ^requested_ids) |> repo.all()
        found_ids = Enum.map(found_${t}, & &1.id)
        unfound_ids = requested_ids -- found_ids

        {matched_attrs, unmatched_attrs} =
          Enum.split_with(${e}_chunk, fn attrs -> MapUtil.get(attrs, :id) not in unfound_ids end)

        changesets =
          Enum.zip(found_${t}, matched_attrs)
          |> Enum.map(fn {${e}, attrs} -> change_${e}(${e}, attrs) end)
          |> Enum.filter(& &1.valid?)

        {:ok, %{changesets: changesets, unmatched: unmatched_attrs}}
      end)
      |> Multi.run(:updates, fn repo, %{initial_query: query_res} ->
        %{
          changesets: changesets,
          unmatched: unmatched_attrs
        } = query_res

        {succeeded, failed_updates} =
          changesets
          |> Enum.map(&repo.update/1)
          |> Enum.reduce({[], []}, fn
            {:ok, ${e}}, {s, f} -> {[${e} | s], f}
            {_, changeset}, {s, f} -> [s, changeset | f]
          end)

        {:ok, %{succeeded: succeeded, failed: failed_updates ++ unmatched_attrs}}
      end)

    {:ok, %{updates: updates}} = Repo.transaction(multi)
    %{succeeded: succeeded, failed: failed} = updates

    case {succeeded, failed} do
      {succeeded, []} -> {:ok, succeeded, []}
      {[], failed} -> {:error, [], failed}
      {succeeded, failed} -> {:partial_success, succeeded, failed}
    end
  end)
  |> Chunk.flat_reduce()
end
`),Ie=({genName:e})=>(p({genName:e},"update_single"),`
def update_${e}(attrs) when is_map(attrs) do
  changeset =
    MapUtil.get(attrs, :id)
    |> get_${e}!()
    |> change_${e}(attrs)

  if changeset.valid?, do: Repo.update(changeset)
end
`),tr=[{id:"update_many",fn:Oe,header:e=>$(e,Oe)},{id:"update_single",fn:Ie,header:e=>$(e,Ie)}],nr={update_many:Nn,update_single:er},rr={update_many:Oe,update_single:Ie},at=(e,t)=>{let n=tr.map(({id:i,fn:c,header:m})=>({id:i,def:c(t),header:m(t)})).filter(({header:i})=>e.includes(i)),r=n.map(({id:i})=>i||""),a=r.map(i=>nr[i](t)).join(`
`),s=Vn(t,a),o=r.map(i=>rr[i](t)).join(`
`);return{result:s+`
`+o,remaining_apis:e.filter(i=>!n.map(({header:c})=>c).includes(i))}};var or=({header:e})=>(p({header:e},"custom"),`
    def ${e} do
        # TODO: Provide function definition here
    end
`),st={id:"custom",fn:or,header:({header:e})=>e};var ir=(e,t)=>{u({level:5},"Requested Apis: ",e);let n=[et,nt,ot,it,at],{computed:r,remaining_apis:a}=n.reduce((o,i)=>{u({level:8},"APIFN REDUCER",o,i);let{computed:c,remaining_apis:m}=o;u({level:8},"APIFN COM",c),u({level:8},"APIFN REM",m),u({level:8},"APIFN RES",i(m,t));let{result:f,remaining_apis:h}=i(m,t);return{computed:c+f,remaining_apis:h}},{computed:"",remaining_apis:e});u({level:7},"Computed Apis: ",r);let s=a.map(o=>st.fn({header:o})).join(`
`);return r+`
`+s},lt=async(e,t)=>{let{AppNameCamel:n,LibDir:r,generate:a,name:s,camelName:o,pluralName:i}=e,{name:c,apiFunctions:m}=a.context,f=(0,ct.join)(r||"","/lib/"),h=c.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g,"$1_$2").replace(/^_/,"").toLowerCase(),l=`
defmodule ${n}.${c} do
  @moduledoc """
  The ${c} context.
  """

  import Ecto.Query, warn: false

  alias Ecto.Multi
  alias ${n}.Repo
  alias ${n}.Utils.DynamicQuery
  alias ${n}.Utils.Paginate
  alias ${n}.Utils.Chunk
  alias ${n}.Utils.MapUtil

  alias ${n}.${o}

  ${ir(m,{camelName:c||"",genName:s,context:c,pluralName:i||"",AppNameCamel:n||"",genCamelName:o||""})}

  @doc """
  change_${s}(${i}) when is_list ${i} -> Returns a list of \`%Ecto.Changeset{}\` for tracking ${s} changes

  ## Examples
      iex> change_${s}([{${s}1, attrs1}, {${s}2, attrs2}])
      %Ecto.Changeset{data: [%${o}{}, %${o}{}]}

  change_${s}(%${o}{} = ${s}, attrs \\\\ %{}) -> Returns \`%Ecto.Changeset{}\` for tracking ${s} changes.

  ## Examples
      iex> change_${s}(${s})
      %Ecto.Changeset{data: %${o}{}}

  """
  def change_${s}(attrs \\\\ %{})
  def change_${s}(attrs) when is_map(attrs), do: change_${s}(%${o}{}, attrs)

  def change_${s}(${i}) when is_list(${i}),
    do:
      Enum.map(${i}, fn
        {${s}, attr} -> change_${s}(${s}, attr)
        attr when is_map(attr) -> change_${s}(attr)
      end)

  def change_${s}(%${o}{} = ${s}, attrs), do: ${o}.changeset(${s}, attrs)
end
`;return w({dir:f,filename:`${h}.ex`,content:l},"gen_phx_contex")};var dt=I(require("path"));var Re=I(require("fs"));var W=async({file:e,injections:t},n=null)=>(u({level:5},`Injecting into ${e}....`),new Promise(async(r,a)=>{Ue(e,n);let o=Re.default.readFileSync(e,"utf8");t.forEach(([i,c,m])=>{switch(u({level:7},`Injecting ${m} into ${e}`),u({level:9},"File: ",o),i){case"REPLACE":let f=o.replace(c,m);if(f==o||f==""){ut(c,e,a);return}else u({level:8},`Found ${c} in ${e}`),o=f;break;default:o=ar(o,e,[i,c,m])||ut(c,e,a)}}),o.length?(Re.default.writeFileSync(e,o,"utf8"),await U(e),r([e])):a(new Error(`Insertion failed for ${e}`))})),ut=(e,t,n)=>(console.error(`${e} not found in the ${t} file.`),n(new Error(`Insertion failed for ${t}`)),""),ar=(e,t,[n,r,a])=>{let s=e.match(r);if(!s)return null;let o=s.index;if(u({level:8},`Found ${r} at ${o} in ${t}`),n==="AFTER")o+=s[0].length;else if(n!="BEFORE")return null;return e.slice(0,o)+a+e.slice(o)};var pt=async e=>{let{WebDir:t,generate:n,AppNameSnake:r,name:a}=e||{},{http_controller:s}=n||{},{name:o}=s||{},i=dt.default.join(t||".",`lib/${r}_web/router.ex`),c=[["AFTER",/pipe_through[\s\(]{1,3}:api\){0,1}/,`
resources "/${a}", ${o}
put "/${a}", ${o}, :update
delete "/${a}", ${o}, :delete`]];return W({file:i,injections:c},"inject_router")};var Pt=require("path");var mt=({pluralName:e,context:t,genName:n})=>(p({pluralName:e,context:t,genName:n},"show_list"),`
    def show(conn, ${n}_list) when is_list(${n}_list) do
      ${e} = ${t}.get_${n}!(${n}_list)
      render(conn, :show, ${e}: ${e})
    end
  `),ft=({genName:e,context:t})=>(p({genName:e,context:t},"show"),`
    def show(conn, %{"id" => id}) do
        ${e} = ${t}.get_${e}!(id)
        render(conn, :show, ${e}: ${e})
    end
`),_t=[{id:"show_list",fn:mt,header:e=>$(e,mt)},{id:"show",fn:ft,header:e=>$(e,ft)}];var gt=({pluralName:e,context:t})=>(p({pluralName:e,context:t},"index_standard"),`
    defp routed_index(conn, entity_queries, page_queries) when entity_queries == %{} do
      with {:ok, ${e}, query_data} <- ${t}.list_${e}(page_queries) do
        render(conn, :show, ${e}: ${e}, query_data: query_data)
      end
    end
  `),$t=({pluralName:e,context:t})=>(p({pluralName:e,context:t},"index_dynamic"),`
    defp routed_index(conn, entity_queries, page_queries) when entity_queries != %{} do
      with {:ok, ${e}, query_data} <- ${t}.list_${e}_by(entity_queries, page_queries) do
        render(conn, :show, ${e}: ${e}, query_data: query_data)
      end
    end
  `),ht=[{id:"index_standard",fn:gt,header:e=>$(e,gt)},{id:"index_dynamic",fn:$t,header:e=>$(e,$t)}];var yt=({genName:e,context:t,pluralName:n,AppNameCamel:r})=>(p({genName:e,context:t,pluralName:n,AppNameCamel:r},"create_list"),`
    def create(conn, ${e}_list) when is_list(${e}_list) do
      with {:ok, ${n}, []} <- ${t}.create_${e}(${e}_list) do
        conn
        |> put_status(:created)
        |> put_resp_header("location", ~p"/api/${e}")
        |> render(:show, ${n}: ${n})
      else
        {:partial_success, created_${n}, failed_${n}} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeeded: created_${n}, failed: failed_${n}, query_data: ${e}_list)
  
        error ->
          ${r}Web.FallbackController.call(conn, error)
      end
    end
    `),vt=({genName:e,camelUpperName:t,context:n,pluralName:r})=>(p({genName:e,camelUpperName:t,context:n,pluralName:r},"create"),`
    def create(conn, ${e}_params) do
      with {:ok, %${t}{} = ${e}} <- ${e}_params |> MapUtil.str_to_atom() |> ${n}.create_${e}() do
        conn
        |> put_status(:created)
        |> put_resp_header("location", ~p"/api/${e}/#{${e}.id}")
        |> render(:show, ${e}: ${e})
      end
    end
    `),bt=[{id:"create_list",fn:yt,header:e=>$(e,yt)},{id:"create",fn:vt,header:e=>$(e,vt)}];var St=({pluralName:e,context:t,genName:n,AppNameCamel:r})=>(p({pluralName:e,context:t,genName:n,AppNameCamel:r},"update_list"),`
    def update(conn, ${n}_list) when is_list(${n}_list) do
      with {:ok, ${e}, []} <- ${t}.update_${n}(${n}_list) do
        render(conn, :show, ${e}: ${e})
      else
        {:partial_success, updated_${e}, failed_${e}} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeeded: updated_${e}, failed: failed_${e}, query_data: ${n}_list)
  
        error ->
          ${r}Web.FallbackController.call(conn, error)
      end
    end
    `),xt=({genName:e,context:t,camelName:n})=>(p({genName:e,context:t,camelName:n},"update"),`
    def update(conn, ${e}_params) when is_map(${e}_params) do
      with {:ok, %${n}{} = ${e}} <- ${t}.update_${e}(${e}_params) do
        render(conn, :show, ${e}: ${e})
      end
    end
  `),wt=[{id:"update_list",fn:St,header:e=>$(e,St)},{id:"update",fn:xt,header:e=>$(e,xt)}];var Ot=({pluralName:e,context:t,genName:n,AppNameCamel:r})=>(p({pluralName:e,context:t,genName:n,AppNameCamel:r},"delete_list"),`
    def delete(conn, ${n}_list) when is_list(${n}_list) do
      with {:ok, count, _} <- ${t}.delete_${n}(${n}_list) do
        render(conn, :show, count: count)
      else
        {:partial_success, success_count, fail_count} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeess_count: success_count, fail_count: fail_count, query_data: ${n}_list)
  
        e ->
          ${r}Web.FallbackController.call(conn, e)
      end
    end
  `),It=({genName:e,context:t,camelUpperName:n})=>`
    def delete(conn, %{"id" => id}) do
      with %${n}{} = ${e} <- ${t}.delete_${e}(id) do
        conn
        |> put_status(:ok)
        |> render(:show, ${e}: ${e})
      end
    end 
  `,Rt=[{id:"delete_list",fn:Ot,header:e=>$(e,Ot)},{id:"delete",fn:It,header:e=>$(e,It)}];var cr=({header:e})=>(p({header:e},"custom"),`
    def ${e} do
        # TODO: Provide function definition here
    end
`),Mt={id:"custom",fn:cr,header:({header:e})=>e};var At=require("path");var Me=async(e,t)=>{let{WebDir:n,AppNameCamel:r,AppNameSnake:a}=e,{generate:s}=e,{http_controller:o}=s,i=(0,At.join)(n||".",`lib/${a}_web/controllers`),c=`
defmodule ${r}Web.FallbackController do
  @moduledoc """
  Translates controller action results into valid \`Plug.Conn\` responses.

  See \`Phoenix.Controller.action_fallback/1\` for more details.
  """
  use ${r}Web, :controller

  alias Ecto.Changeset

  # This clause handles errors returned by Ecto's insert/update/delete.
  def call(conn, {:error, %Ecto.Changeset{} = changeset}) do
    conn
    |> put_status(:unprocessable_entity)
    |> json(error_transform(changeset))
  end

  def call(conn, {:error, [], failed_changesets}) when is_list(failed_changesets) do
    conn
    |> put_status(:unprocessable_entity)
    |> json(%{errors: error_transform(failed_changesets)})
  end

  # This clause is an example of how to handle resources that cannot be found.
  def call(conn, {:error, :not_found}) do
    conn
    |> put_status(:not_found)
    |> put_view(html: ${r}Web.ErrorHTML, json: ${r}Web.ErrorJSON)
    |> render(:"404")
  end

  def error_transform(changesets) when is_list(changesets),
    do: changesets |> Enum.map(&error_transform/1)

  def error_transform(%Changeset{} = cs) do
    errors =
      Enum.reduce(cs.errors, %{}, fn {key, {reason, _}}, acc -> Map.put(acc, key, reason) end)

    Map.put(cs.changes, :errors, errors)
  end
end
`;return o?w({dir:i,filename:"fallback_controller.ex",content:c},"gen_fallback_controller"):!1};var Et=require("path");var Ae=async(e,t)=>{let{WebDir:n,AppNameCamel:r,AppNameSnake:a,camelName:s,pluralName:o,name:i}=e,{generate:{http_controller:c}}=e,{ImmutableGlobal:m,Schema:f}=t,h=(0,Et.join)(n||".",`lib/${a}_web/controllers`),g=(m||f)?.ex,l=Object.keys(g||{}).map(_=>`${_}: Map.get(${i}, :${_})`).join(`,
      `),d=`
defmodule ${r}Web.${s}JSON do
  alias ${r}Web.FallbackController

  @doc """
  Renders a ${i} or list of ${o}.

  ## Examples
      iex> render(conn, :show, ${o}: ${o})
      {:ok, %{data: [%${s}{}]}

      iex> render(conn, :show, ${i}: ${i})
      {:ok, %{data: %${s}{}}}
  """
  def show(%{${o}: ${o}, query_data: q}) when is_list(${o}) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.merge(%{data: transform(${o}), count: length(${o})})
  end

  def show(%{${i}: ${i}, query_data: q}) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.put(:data, transform(${i}))
  end

  def show(%{count: c}), do: %{success_count: c, fail_count: 0}

  def show(params), do: Map.merge(%{query_data: %{}}, params) |> show

  @doc """
  Renders ${o} from batch operations

  ## Examples
      iex> render(conn, :show_partial, succeeded: ${i}_maps, failed: ${i}_changesets)
      {:partial_success, [%${s}{}], [%Changeset{}]}
  """
  def show_partial(params \\\\ %{query_data: %{}, succeeded: [], failed: []})

  def show_partial(%{succeeded: succeeded_${o}, failed: failed_changesets, query_data: q})
      when is_list(succeeded_${o}) and is_list(failed_changesets) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.merge(%{
      success_count: length(succeeded_${o}),
      fail_count: length(failed_changesets),
      data: transform(succeeded_${o}),
      failed: FallbackController.error_transform(failed_changesets)
    })
  end

  def show_partial(%{success_count: s_count, fail_count: f_count}), do: %{success_count: s_count, failed_count: f_count}

  defp transform(${o}) when is_list(${o}), do: Enum.map(${o}, &transform/1)

  defp transform(${i}) when is_map(${i}) do
    %{
      id: Map.get(${i}, :id),
      ${l}
    }
  end
end
`;return c?w({dir:h,filename:`${i}_json.ex`,content:d},"gen_json_handler"):null};var lr=[_t,ht,bt,wt,Rt].flat(),ur=(e,t,n)=>{u({level:7},"Requested Routes: ",e);let r=t.reduce((a,s)=>({...a,[s.header(n)]:s.fn(n)}),{});return u({level:7},"Route Data Computed: ",r),e.map(a=>(u({level:7},"Header: ",a),r[a]||Mt.fn({header:a}))).join(`

`)},kt=async(e,t)=>{let{AppNameSnake:n,AppNameCamel:r,WebDir:a,generate:s,name:o,camelName:i,pluralName:c}=e,{name:m,routes:f}=s.http_controller,{name:h}=s.context,g=(0,Pt.join)(a||"",`/lib/${n}_web/controllers/`),l=m.replace(/([a-z0-9])([A-Z])/g,"$1_$2").toLowerCase(),d={camelName:i||"",genName:o,context:h,pluralName:c||"",AppNameCamel:r||"",camelUpperName:i||""};u({level:7},"Generating controller: ",m,l,d);let _=`
defmodule ${r}Web.${m} do
use ${r}Web, :controller
plug ${r}.Plugs.ListAsJSON

alias ${r}.Utils.Paginate
alias ${r}.Utils.MapUtil

alias ${r}.${h}
alias ${r}.${i}

action_fallback ${r}Web.FallbackController

def index(conn, params) do
    {entity_queries, page_queries} = Paginate.split_page_opts(params)
    routed_index(conn, entity_queries, page_queries)
end

${ur(f,lr,d)}

end
`;return w({dir:g,filename:`${l}.ex`,content:_},"gen_phx_controller")};var Lt=async(e,t)=>{let n=e.generate,r=[];return n.schema&&r.push(await Ne(e,t)),n.context&&r.push(await lt(e,t)),n.http_controller&&r.push(Promise.all([kt(e,t),Me(e,t),Ae(e,t),pt(e)])),r};var an=require("path"),E=I(G());var rn=I(nn()),ya=new rn.LoremIpsum,Nr={number:"Math.floor(Math.random() * 100)",string:"Lorem.generateWords(3)",boolean:"Math.random() > 0.5",object:"({ lorem: Lorem.generateWords(1), ipsum: Lorem.generateWords(2) })",array:'Lorem.generateWords(3).split(" ")',any:"Lorem.generateSentences(1)"};var on=e=>Nr[e];var sn=async(e,t)=>{u({level:7},"GEN ENTITY STORE",e),u({level:7},"TYPE DICT",t);let{name:n,generate:r,LibDir:a,UiDir:s,AppNameCamel:o}=e,{tstype:i,appstate:c,factory:m,slice:f}=r,h=(0,an.join)(a,"lib/typescript/state/"),g=n.charAt(0).toUpperCase()+n.slice(1),l=(t.TsType||t.ImmutableGlobal).ts,d=(t.AppState||t.ImmutableGlobal).ts,_=t.InitialAppState?.ts||{},y=Object.keys(l).map(x=>`${x}: ${l[x]}`).join(`;
`),v=`type ${i} = {${y}}`,O=Object.keys(d).map(x=>`${x}: ${d[x]}`).join(`;
`),C=`interface ${c} {${O}}`,re=Object.keys(l).map(x=>`${x}: ${on(l[x])}`).join(`,
`),oe=`const ${i}Factory = (params: object): ${i} => {
    const ${n} = {${re}};
    return Object.assign(${n}, params) as ${i};
}`,q=Object.keys(_).map(x=>`${x}: ${_[x]}`).join(`,
`),mn=`const initial${c}State: ${g}StoreState = {${q}}`,fn=`
const ${f} = createSlice({
      name: "${n}",
      initialState: initial${c}State,
      reducers: {
        set${i}(state: ${c}, action: PayloadAction<${i}>) {
          state.${i?.toLowerCase()} = action.payload;
        },
        set${(0,E.default)(i)}(state: ${c}, action: PayloadAction<${i}[]>) {
          state.${(0,E.default)(i)?.toLowerCase()} = action.payload;
        },
      },
    });
const ${n}Reducer = ${f}.reducer;

const select${i} = (state: GenericAppState) => state.${`${n}Store`}.${i?.toLowerCase()};
const select${(0,E.default)(i)} = (state: GenericAppState) => state.${`${n}Store`}.${(0,E.default)(i)?.toLowerCase()};
`,_n=[c?`initial${c}State`:null,m?`${i}Factory`:null,f?`${n}Reducer`:null,f?`select${i}`:null,f?`select${(0,E.default)(i)}`:null].filter(x=>!!x).join(", "),gn=[f?`const { set${i}, set${(0,E.default)(i)} } = ${f}.actions
export { set${i}, set${(0,E.default)(i)} }`:null,i||c?`export type { ${[i,c,"GenericAppState"].join(", ")} }`:null,`export { ${_n} }`,f?`export default ${f}`:null].filter(x=>!!x).join(`
`),$n=`
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import Lorem from "../utils/lorem";

${i?`
${v}
`:""}
${c?`
${C}
`:""}
${c?`
${mn}
`:""}
${m?`
${oe}
`:""}
${f?`
${fn}
`:""}

interface GenericAppState {
    ${n}Store: ${g}StoreState;
    [key: string]: any;
}

${gn}
`;return w({dir:h,filename:`${n}.tsx`,content:$n},"gen_entity_store")};var cn=I(require("path"));var ln=async e=>{let{name:t,generate:n,UiDir:r}=e,{appstate:a}=n,s=cn.default.join(r,"src/store/index.tsx"),o=[["AFTER",/reducer\:\scombineReducers\(\{/,`
${t}Store: ${t}Reducer,`],["AFTER",/import\s.*/,`
import { ${t}Reducer, ${a} } from '@state/${t}';`],["AFTER",/type\s+[A-Za-z]+State\s+\=\s+\{/,`
  ${t}Store: ${a};`]];return W({file:s,injections:o},"addReducerToGlobal")};var un=require("path"),P=I(G());var dn=async(e,t)=>{let{name:n,generate:r,AppNameCamel:a,LibDir:s}=e,{tstype:o}=r,i=(0,un.join)(s||"","lib/typescript/requests/"),c=`
import { Dispatch } from "redux";
import { Request } from "./index";
import { ${o}, set${o}, set${(0,P.default)(o)} } from "../state/${n}";

const request${o} = (id: string, dispatch: Dispatch) => {
  Request.API({
    name: "fetch${o}",
    api_url_key: "${a?.toUpperCase()}_API_URL",
    route: \`${(0,P.default)(o).toLowerCase()}/\${id}\`,
    callback: (res: any) => dispatch(set${o}(res.data))
  }, dispatch);
};

const request${(0,P.default)(o)} = (dispatch: Dispatch) => {
  return Request.API({
    name: "fetch${(0,P.default)(o)}",
    api_url_key: "${a?.toUpperCase()}_API_URL",
    route: \`${(0,P.default)(o).toLowerCase()}\`,
    callback: (res: any) => dispatch(set${(0,P.default)(o)}(res.data)),
  }, dispatch);
};

const update${o} = (${o?.toLowerCase()}: ${o}, dispatch: Dispatch) => {
  Request.API({
    name: "update${o}",
    api_url_key: "${a?.toUpperCase()}_API_URL",
    route: "${o?.toLowerCase()}",
    options: {
      method: "PUT",
      body: JSON.stringify(${o?.toLowerCase()}),
    },
    callback: (_data: any) => null,
  }, dispatch);
};

const delete${o} = (id: string, dispatch: Dispatch) => {
  Request.API({
    name: "delete${o}",
    api_url_key: "${a?.toUpperCase()}_API_URL",
    route: \`${o?.toLowerCase()}/\${id}\`,
    options: {
      method: "DELETE",
    },
  }, dispatch);
};

export { request${o}, request${(0,P.default)(o)}, update${o}, delete${o} };
`;return w({dir:i,filename:`${n}.tsx`,content:c},"gen_entity_requests")};We(5);var eo=async()=>{let e=process.argv.slice(2),t=pn.resolve(e[0]);e.length<1&&(console.error("Please provide the input file path as an argument."),process.exit(1)),u({level:1,color:"GREEN"},`

 Generating from genfile...

`);let{generator:n,genTypes:r}=await Ze(t);Fe(n.UmbrellaDir||"./"),u({level:2,color:"BLUE"},`
Generating server components...`),u({level:3},await Lt(n,r)),u({level:2,color:"BLUE"},`
Generating front end components...`),u({level:3},ln(n)),u({level:3},await sn(n,r)),u({level:3},await dn(n,r)),Ge(n.UmbrellaDir||"./",`generate_${n.name}`)};eo().catch(console.error);
