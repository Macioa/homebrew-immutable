"use strict";var G=Object.create;var C=Object.defineProperty;var A=Object.getOwnPropertyDescriptor;var k=Object.getOwnPropertyNames;var z=Object.getPrototypeOf,L=Object.prototype.hasOwnProperty;var j=(a,i)=>()=>(i||a((i={exports:{}}).exports,i),i.exports);var E=(a,i,s,p)=>{if(i&&typeof i=="object"||typeof i=="function")for(let u of k(i))!L.call(a,u)&&u!==s&&C(a,u,{get:()=>i[u],enumerable:!(p=A(i,u))||p.enumerable});return a};var T=(a,i,s)=>(s=a!=null?G(z(a)):{},E(i||!a||!a.__esModule?C(s,"default",{value:a,enumerable:!0}):s,a));var S=j((v,x)=>{(function(a,i){typeof require=="function"&&typeof v=="object"&&typeof x=="object"?x.exports=i():typeof define=="function"&&define.amd?define(function(){return i()}):a.pluralize=i()})(v,function(){var a=[],i=[],s={},p={},u={};function f(e){return typeof e=="string"?new RegExp("^"+e+"$","i"):e}function g(e,n){return e===n?n:e===e.toLowerCase()?n.toLowerCase():e===e.toUpperCase()?n.toUpperCase():e[0]===e[0].toUpperCase()?n.charAt(0).toUpperCase()+n.substr(1).toLowerCase():n.toLowerCase()}function d(e,n){return e.replace(/\$(\d{1,2})/g,function(c,o){return n[o]||""})}function $(e,n){return e.replace(n[0],function(c,o){var l=d(n[1],arguments);return g(c===""?e[o-1]:c,l)})}function w(e,n,c){if(!e.length||s.hasOwnProperty(e))return n;for(var o=c.length;o--;){var l=c[o];if(l[0].test(n))return $(n,l)}return n}function _(e,n,c){return function(o){var l=o.toLowerCase();return n.hasOwnProperty(l)?g(o,l):e.hasOwnProperty(l)?g(o,e[l]):w(l,o,c)}}function h(e,n,c,o){return function(l){var y=l.toLowerCase();return n.hasOwnProperty(y)?!0:e.hasOwnProperty(y)?!1:w(y,y,c)===y}}function r(e,n,c){var o=n===1?r.singular(e):r.plural(e);return(c?n+" ":"")+o}return r.plural=_(u,p,a),r.isPlural=h(u,p,a),r.singular=_(p,u,i),r.isSingular=h(p,u,i),r.addPluralRule=function(e,n){a.push([f(e),n])},r.addSingularRule=function(e,n){i.push([f(e),n])},r.addUncountableRule=function(e){if(typeof e=="string"){s[e.toLowerCase()]=!0;return}r.addPluralRule(e,"$0"),r.addSingularRule(e,"$0")},r.addIrregularRule=function(e,n){n=n.toLowerCase(),e=e.toLowerCase(),u[e]=n,p[n]=e},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(e){return r.addIrregularRule(e[0],e[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(e){return r.addPluralRule(e[0],e[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(e){return r.addSingularRule(e[0],e[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(r.addUncountableRule),r})});var b=T(require("fs")),q=require("path"),I=T(S()),[,,t]=process.argv,R=(0,q.join)(process.cwd(),`.genfile_${t}.ts`);t||(console.error("Please provide a name as an argument."),process.exit(1));var P=()=>b.default.existsSync(R)?F():U(),U=()=>{let a=(0,I.default)(t),i=`
const Immutable : ImmutableGenerator = {
  name: '${t}',
  generate: {
    // BACK END
    http_controller: {
      name: '${m(t)}Controller',
      routes: [
        'routed_index(conn, entity_queries, page_queries) when entity_queries == %{}',
        'routed_index(conn, entity_queries, page_queries) when entity_queries != %{}',
        'create(conn, ${t}_list) when is_list(${t}_list)',
        'create(conn, ${t}_params)',
        'show(conn, ${t}_list) when is_list(${t}_list)',
        'show(conn, %{"id" => id})',
        'update(conn, ${t}_list) when is_list(${t}_list)',
        'update(conn, ${t}_params) when is_map(${t}_params)',
        'delete(conn, ${t}_list) when is_list(${t}_list)',
        'delete(conn, %{"id" => id})'
      ]
    },
    channel_controller: '${t}_channel',     // Requires Context, Schema, and DatabaseModel
    context: {
      name: '${m(t)}Context',
      apiFunctions: [
      'create_${t}(attrs) when is_list(attrs)',
      'create_${t}(${t}_params) when is_map(${t}_params)',
      'delete_${t}(${a}) when is_list(${a})',
      'delete_${t}(${t}_params) when is_map(${t}_params)',
      'delete_${t}(id) when is_binary(id)',
      'get_${t}!(${a}) when is_list(${a})',
      'get_${t}!(${t}_params) when is_map(${t}_params)',
      'get_${t}!(id) when is_binary(id)',
      'list_${a}(page_query \\\\ %{})',
      'list_${a}_by(entity_queries, page_queries \\\\ %{})',
      'update_${t}(${a}) when is_list(${a})',
      'update_${t}(attrs) when is_map(attrs)'
      ]
    },  
    schema: "${m(t)}",               // Requires DatabaseModel
    databaseModel: "${a}",       // Requires Schema
    
    // FRONT END
    appstate: "${m(t)}StoreState",
    factory: true,
    slice: "${t}Slice",
    tstype: "${m(t)}"
  },
  test: true
}

/*                  DECLARATIONS

   Global will be used when other types are not specified. If all types are specified, Global will be ignored. 
       If genfile is run again with the same name argument, global will be propagated to all other types which can then be customized.
*/
interface ImmutableGlobal
  extends GenType<{
    example1: integer;
    example2: string;
    example3: float;
  }> {}

interface AppState extends GenType<{
  ${t}: ${m(t)} | null;
  ${a}: ${m(t)}[];
}> {}
interface InitialAppState extends AppState {
  ${t}: null;
  ${a}: [];
}
interface TransitoryState extends GenType<{

}> {}
interface Schema extends GenType<{

}> {}
interface DatabaseModel extends GenType<{

}> {}
interface TsType extends GenType<{
  
}> {}

/*                   AVAILABLE TYPES

   The following ecto types, with their default typescript equivalents, are available for assignment
*/
type integer = number & { __brand: "integer" };
type float = number & { __brand: "float" };
type decimal = number & { __brand: "decimal" };
// type string = string & { __brand: 'string'  };
// type boolean = boolean & { __brand: 'boolean'  };
type date = string & { __brand: "date" };
type time = string & { __brand: "time" };
type naive_datetime = string & { __brand: "naive_datetime" };
type utc_datetime = string & { __brand: "utc_datetime" };
type binary = string & { __brand: "binary" };
type array = any[] & { __brand: "array" };
type map = object & { __brand: "map" };
type json = object & { __brand: "json" };
type id = string & { __brand: "id" };
type uuid = string & { __brand: "uuid" };
type binary_id = string & { __brand: "binary_id" };

/*                   INTERNAL

  The following types are unused other than to provide type checking for the fields above

*/

interface AllowedTypes {
  [key: string]:
    | integer
    | float
    | decimal
    | string
    | boolean
    | date
    | time
    | naive_datetime
    | utc_datetime
    | binary
    | array
    | map
    | json
    | id
    | uuid
    | binary_id
    // unique types for appstate only
    | ${m(t)}
    | ${m(t)}[]
    | null;
}
interface ${m(t)} {}
type GenType<T extends AllowedTypes> = T;

interface ImmutableGenerator {
    name: string
    generate: {
      slice?: string
      http_controller?: ImmutableController;
      channel_controller?: string;
      context?: ImmutableContext;
      databaseModel?: string;
      schema?: string;
      tstype?: string;
      appstate?: string;
      factory?: boolean;
    }
    test: boolean
}

interface ImmutableController {
    name: string;
    routes: string[];
}

interface ImmutableContext {
    name: string;
    apiFunctions: string[];
}

export { Immutable }
export type { ImmutableGenerator, ImmutableGlobal, AppState, InitialAppState, TransitoryState, Schema, DatabaseModel, TsType }
`;b.default.writeFileSync(`.genfile_${t}.ts`,i,"utf8"),console.log(`Created .genfile_${t}.ts`)},F=()=>{let a=b.default.readFileSync(R,"utf8"),i=a,s=a.match(/interface \w+.*?extends GenType<.*?> \{\}/gs),p=s?.map(d=>N(d)),[u,f]=p?.find(([d,$])=>d==="ImmutableGlobal")||[];p?.map(([d,$,w],_)=>{if($.length===0&&f){let h="";return s?.[_].replace(/interface\s(\w+).*?extends\sGenType<\{(.*?)\}?> \{\}/gs,(r,e,n)=>(h=`interface ${r} extends GenType<{${f}}> {}`,h)),h}else return s?.[_]})?.forEach((d,$)=>{d&&(i=i.replace(s?.[$]||"",d))}),b.default.writeFileSync(`.genfile_${t}.ts`,i,"utf8"),console.log(`Updated .genfile_${t}.ts`)},N=a=>{let i=a.match(/interface\s(\w+)/)?.[1]||"",s=a.match(/\w+\:\s\w+/gs)?.join(`
`)||"";return[i,s,a]};function m(a){return a&&a.charAt(0).toUpperCase()+a.slice(1)}P();
