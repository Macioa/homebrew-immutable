"use strict";var nt=Object.create;var T=Object.defineProperty;var it=Object.getOwnPropertyDescriptor;var ot=Object.getOwnPropertyNames;var rt=Object.getPrototypeOf,st=Object.prototype.hasOwnProperty;var at=(e,t,n,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of ot(t))!st.call(e,o)&&o!==n&&T(e,o,{get:()=>t[o],enumerable:!(i=it(t,o))||i.enumerable});return e};var p=(e,t,n)=>(n=e!=null?nt(rt(e)):{},at(t||!e||!e.__esModule?T(n,"default",{value:e,enumerable:!0}):n,e));var j=require("path");var ct=99,lt={GREEN:"\x1B[32m%s\x1B[0m",RED:"\x1B[31m%s\x1B[0m",YELLOW:"\x1B[33m%s\x1B[0m",BLUE:"\x1B[34m%s\x1B[0m"};var c=({level:e,color:t},...n)=>{e<=ct&&(n=t?[lt[t],...n]:n,console.log(...n))};var B=require("child_process"),z=require("fs"),W=require("path");var M=require("fs"),I=p(require("path"));var f=(e,t=null)=>(Object.keys(e).forEach(n=>{let i=e[n];if(i==null)throw console.error(`${n} in StringOnlyMap cannot be null or undefined.
     Caller: ${t}`),`${n} in StringOnlyMap cannot be null or undefined. Caller: ${t}`}),!0),w=(e,t)=>t.reduce((n,i)=>n?.[i],e);var R=(e,t,n)=>{let i=t.pop(),o=w(e,t);o&&typeof o=="object"?o[i]=n:R(e,t,{[i]:n})};var S=null,v={_name:null,commands:[],file_modifications:{}},A=({command:e,dir:t},n=null)=>{v.commands.push({command:e,dir:t,caller:n||"unreferenced"})},$=({filename:e,dir:t},n=null)=>{f({filename:e,dir:t},n);let i=pt(t),{file_modifications:o}=v,a=i.split("/").filter(m=>m).concat([e]),u=(w(o,a)||[]).concat([n||"unreferenced"]);return R(v,["file_modifications",...a],u),v},C=(e,t)=>{v._name=t;let n=JSON.stringify(v,null,2);(0,M.writeFileSync)(I.default.resolve(e,`.immutable_log_${t}.json`),n,"utf8")},D=(e,t=null)=>{let n=e.split("/").filter(a=>a),i=n.slice(-1)[0],o=n.slice(0,-1).join("/");return $({filename:i,dir:o},t)},U=e=>{S=I.default.resolve(e).replace(/^[^\w]+/,"")},pt=e=>(e=e.replace(/^[^\w]+/,""),(S?e.replace(S,""):e).replace(/^[^\w]+/,""));var G={dir:"",command:"",options:{forceReturnOnPrompt:!0}};var x=async(e,t=null)=>{let{dir:n,command:i,options:o}={...G,...e},{timeoutResolve:a,timeoutReject:s,forceReturnOnPrompt:u,resolveOnErrorCode:m}={...G.options,...o};return A({command:i,dir:n},t),c({level:4,color:"YELLOW"},`Executing: ${i}`),c({level:4},`      in ${n}...`),new Promise((g,_)=>{let L=(0,W.resolve)(n);(0,z.mkdirSync)(L,{recursive:!0});let[He,...Ze]=i.split(" "),b=(0,B.spawn)(He,Ze,{cwd:L,shell:!0});b.stdout.on("data",y=>{c({level:5},y.toString()),o?.prompts&&o.prompts.forEach(([Ne,et])=>{if(y.toString().includes(Ne)){let tt=et+(u?`
`:"");b.stdin.write(tt)}})}),b.stderr.on("error",y=>{console.error(`Could not run ${i}:
      ${y}`),_(y||`Could not run ${i}`)}),b.on("close",y=>{!m&&y?(console.error(`Process exited with exit code ${y}:
       ${i}`),_(`Process exited with ${y}`)):g(n)}),a&&setTimeout(()=>g(n),a),s&&setTimeout(()=>_(new Error("Time out")),s)})};var O=p(require("path"));var P=p(require("fs"));var q=require("child_process"),k=async e=>new Promise((t,n)=>{let i=e.endsWith(".tsx")||e.endsWith(".ts"),o=e.endsWith(".ex")||e.endsWith(".exs");i&&(0,q.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),o&&(0,q.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)});var r=async({file:e,injections:t},n=null)=>(c({level:5},`Injecting into ${e}....`),new Promise(async(i,o)=>{D(e,n);let s=P.default.readFileSync(e,"utf8");t.forEach(([u,m,g])=>{switch(c({level:7},`Injecting ${g} into ${e}`),c({level:9},"File: ",s),u){case"REPLACE":let _=s.replace(m,g);if(_==s||_==""){V(m,e,o);return}else c({level:8},`Found ${m} in ${e}`),s=_;break;default:s=mt(s,e,[u,m,g])||V(m,e,o)}}),s.length?(P.default.writeFileSync(e,s,"utf8"),await k(e),i([e])):o(new Error(`Insertion failed for ${e}`))})),V=(e,t,n)=>(console.error(`${e} not found in the ${t} file.`),n(new Error(`Insertion failed for ${t}`)),""),mt=(e,t,[n,i,o])=>{let a=e.match(i);if(!a)return null;let s=a.index;if(c({level:8},`Found ${i} at ${s} in ${t}`),n==="AFTER")s+=a[0].length;else if(n!="BEFORE")return null;return e.slice(0,s)+o+e.slice(s)};var ut=async(e,t)=>{let n=O.default.join(t,"vite.config.ts"),i=[["AFTER",/export\s+default\s+defineConfig\(\{[\s\n]+plugins\:\s+\[react\(\)\]\,/,`

  resolve: {
    alias: {
      '@utils': path.resolve(__dirname, '../${e}/lib/typescript/utils'),
      '@state': path.resolve(__dirname, '../${e}/lib/typescript/state'),
      '@requests': path.resolve(__dirname, '../${e}/lib/typescript/requests'),
      '@components': path.resolve(__dirname, '../${e}/lib/typescript/components'),
      '@test': path.resolve(__dirname, 'src/test')
    }
  },
`],["BEFORE",/import\s+react/,`import path from 'path';
`]];return r({file:n,injections:i},"inject_viteconfig")},dt=async(e,t)=>{let n=O.default.join(t,"tsconfig.app.json"),i=[["AFTER",/"compilerOptions":\s+\{/,`

  "baseUrl": "../../",
  "paths": {
    "@utils/*": ["apps/${e}/lib/typescript/utils/*"],
    "@state/*": ["apps/${e}/lib/typescript/state/*"],
    "@requests/*": ["apps/${e}/lib/typescript/requests/*"],
    "@components/*": ["apps/${e}/lib/typescript/components/*"]
  },
`]];return r({file:n,injections:i},"inject_tsconfig")},J=async(e,t)=>Promise.all([ut(e,t),dt(e,t)]);var Y=p(require("path"));var K=async(e,t)=>{let n=Y.default.join(t,"vite.config.ts"),i=[["AFTER",/export\s+default\s+defineConfig\(\{/,`

  build: {
    outDir: '../${e}_web/priv/static', // Output the build to priv/static/assets
    assetsDir: 'assets', 
  },
`]];return r({file:n,injections:i},"inject_vite_build_output")};var Q=require("path");var h=require("fs"),E=require("path");var l=async({filename:e,dir:t,content:n},i=null)=>{$({filename:e,dir:t},i);let o=e.replace(/(.*)\.(\w+)$/,(u,m,g)=>`${m.replace(/\./g,"/")}.${g}`),a=(0,E.resolve)(t),s=(0,E.join)(t,o);return c({level:3},`Generating ${o} ...`),c({level:9},n),(0,h.mkdirSync)(a,{recursive:!0}),(0,h.existsSync)(s)&&(0,h.unlinkSync)(s),(0,h.writeFileSync)(s,n,"utf8"),await k(s),[s]};var X=async(e,t,n)=>{let i=(0,Q.join)(n,"/lib/mix/processes/"),o=`
defmodule ${t}.ViteDevSupervisor do
  use GenServer

  @vite_dev_cmd ["run", "dev", "--prefix", "apps/${e}_ui/"]
  @timeout_sec 5
  @type state :: %{
          vite_server: nil | Port.t(),
          existing_vite_pids: [Integer.t()],
          timeout: nil | PID.t()
        }
  @init_state %{vite_server: nil, existing_vite_pids: [], timeout: nil}

  def init_state(map) when is_map(map), do: Map.merge(@init_state, map)

  def start_link(_), do: GenServer.start(__MODULE__, nil, name: __MODULE__)

  @impl true
  def init(_) do
    existing_vite_pids = get_vite_processes()
    Process.flag(:trap_exit, true)
    Process.link(self())

    Process.whereis(:vite_server) |> kill

    state =
      %{existing_vite_pids: existing_vite_pids}
      |> init_state()
      |> restart_timeout()

    Process.send_after(self(), :restart, @timeout_sec * 1000)
    {:ok, state}
  end

  @impl true
  # Polling mechanism
  def handle_info(:restart, state) do
    Process.send_after(self(), :restart, @timeout_sec * 1000)
    {:noreply, restart_timeout(state)}
  end

  @impl true
  # Forward Vite console output
  def handle_info({_port, {:data, msg}}, state) do
    IO.puts(msg)
    {:noreply, state}
  end

  @impl true
  # Ignore Process exit
  def handle_info({:EXIT, _port, :normal}, state), do: {:noreply, state}

  @impl true
  # Catch all unhandled info, print, and force error
  def handle_info(msg, state) do
    IO.inspect({msg, state}, label: :error_unhandled_info)
    {:error, :unhandled_info}
  end

  defp restart_timeout(state = %{vite_server: port, timeout: timeout}) do
    case [port, timeout] do
      [nil, nil] ->
        state
        |> start_dev_server()
        |> start_timeout()

      [nil, _] ->
        state
        |> cancel_timeout()
        |> start_dev_server()
        |> start_timeout()

      [_, nil] ->
        state
        |> start_timeout()

      [_, _] ->
        state
        |> cancel_timeout()
        |> start_timeout()
    end
  end

  defp start_dev_server(state) do
    port =
      {:spawn_executable, System.find_executable("npm")}
      |> Port.open([:binary, args: @vite_dev_cmd])

    Process.register(port, :vite_server)
    Process.link(port)

    %{state | vite_server: port}
  end

  defp start_timeout(state = %{existing_vite_pids: pids}) do
    spawned_vite_pids =
      get_vite_processes()
      |> Enum.filter(fn pid -> pid not in pids end)

    kill_cmd = fn pid -> "kill -9 #{pid}" end
    kill_vite_pids = spawned_vite_pids |> Enum.map(&kill_cmd.(&1)) |> Enum.join(" & ")

    full_cmd =
      "sleep #{@timeout_sec + 0.15} ; #{kill_vite_pids} #ViteTimeout"

    %{state | timeout: Task.async(fn -> {_, 0} = System.cmd("bash", ["-c", full_cmd]) end)}
  end

  defp cancel_timeout(state = %{timeout: timeout}) do
    Task.shutdown(timeout)

    case System.cmd("bash", [
           "-c",
           "ps aux | grep 'ViteTimeout' | grep -v grep | awk '{print $2}'"
         ]) do
      {timeout_pids, 0} ->
        timeout_pids
        |> String.split("
")
        |> Enum.filter(fn s -> s not in ["", nil] end)
        |> Enum.each(&kill/1)

      _ ->
        :ok
    end

    %{state | timeout: nil}
  end

  defp get_vite_processes do
    case System.cmd("pgrep", ["-af", "vite"]) do
      {output, 0} ->
        output
        |> String.split("
")
        |> Enum.map(&String.trim/1)
        |> Enum.filter(fn string -> string != "" end)

      _ ->
        []
    end
  end

  defp get_pid(nil), do: {:error, :cannot_be_nil}
  defp get_pid(port) when is_port(port), do: Port.info(port)[:os_pid]
  defp get_pid(key) when is_atom(key), do: Process.whereis(key)

  defp kill(nil), do: {:error, :cannot_be_nil}
  defp kill(pid) when is_integer(pid) or is_binary(pid), do: System.cmd("kill", ["-9", pid])
  defp kill(port) when is_port(port), do: port |> get_pid |> kill
  defp kill(pid) when is_pid(pid), do: Process.exit(pid, :kill)
end
`;return l({dir:i,filename:"vite_dev_supervisor.ex",content:o},"gen_vite_supervisor")};var H=p(require("path"));var Z=async(e,t,n)=>{let i=H.default.join(n,`lib/${e}_web/application.ex`),o=[["REPLACE",new RegExp(`${t}Web\\.Endpoint\\n\\s+\\]`),`
      ${t}Web.Endpoint,
      (if (Mix.env() == :dev), do: {${t}.ViteDevSupervisor, []})
    ]
    |> Enum.filter(&(&1 != nil))
`]];return r({file:i,injections:o},"inject_vite_supervisor_to_application_ex")};var N=async({projectName:e,projectNameCamel:t,appdir:n,libdir:i,uidir:o,webdir:a})=>{f({projectName:e,projectNameCamel:t,appdir:n,libdir:i,uidir:o,webdir:a},"init_react_app_with_vite"),c({level:2,color:"BLUE"},`
Generating React app: ${e}_ui with vite ...`);let s=await x({command:`npx create-vite@latest ${e}_ui --template react-ts`,dir:n},"init_react_app_with_vite");return c({level:2,color:"BLUE"},`
Configuring Vite build output and aliases...`),[await J(e,o),await K(e,o),await X(e,t,i),await Z(e,t,a)].flat()};var ee=require("path");var te=async e=>{let t=(0,ee.join)(e,"/lib/typescript/utils/");return l({dir:t,filename:"lorem.ts",content:`
import { LoremIpsum } from "lorem-ipsum";

const Lorem = new LoremIpsum();
export default Lorem;
`},"gen_lorem_utils")};var ne=require("path");var ie=async e=>{let t=(0,ne.join)(e,"lib/typescript/requests");return l({dir:t,filename:"index.tsx",content:`
import { Dispatch } from "redux";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import merge from "deepmerge";

interface GenericAppState {
  RequestsStore: RequestsStoreState;
  [key: string]: any;
}

type AppRequest = {
  name: string;
  request: Promise<any>;
  details: requestAPIinterface;
};

interface RequestsStoreState {
  activeRequests: {
    [key: string]: object;
  };
}

const initialRequestsState: RequestsStoreState = {
  activeRequests: {},
};

const requestSlice = createSlice({
  name: "requests",
  initialState: initialRequestsState,
  reducers: {
    addRequest(
      state: RequestsStoreState,
      { payload }: PayloadAction<AppRequest>
    ) {
      state.activeRequests = {
        ...state.activeRequests,
        [payload.name]: payload.request,
      };
    },
    completeRequest(
      state: RequestsStoreState,
      { payload }: PayloadAction<string>
    ) {
      delete state.activeRequests[payload];
    },
  },
});
const requestReducer = requestSlice.reducer;

const isLoading = (state: GenericAppState, key: string | null = null) => {
  const requests = state.requestsStore.activeRequests;
  return key ? !!requests[key] : !!Object.keys(requests).length;
};

type requestAPIinterface = {
  name: string;
  api_url_key: string;
  route: string;
  options?: RequestInit;
  callback?: Function;
};
const defaultOptions = {
  method: "GET",
  headers: {
    "Content-Type": "application/json",
  },
};

const requestAPI = async (details: requestAPIinterface, dispatch: Dispatch) => {
  const { name, api_url_key, route, options, callback } = details;
  const req = new Promise<any>(async (resolve, reject) => {

    const handleError = (err: string, rej: Function) => {
      console.error(err);
      rej(err);
      dispatch(completeRequest(name));
    };
    const handleSuccess = (data: any, res: Function) => {
        callback && callback(["hello"])
      if (callback) callback(data);
      res(data);
      dispatch(completeRequest(name));
    };

    try {
      const API_URL = process.env[api_url_key] || "http://localhost:4000/api/",
        reqOptions = merge(defaultOptions, options || {});

      const res = await fetch(\`\${API_URL}/\${route}\`, reqOptions)
        .catch((err) => handleError(String(err), reject));

      if (!res?.ok)
        handleError(
          \`\${API_URL} request failed: \${res?.status}\\n\${res?.statusText}\`,
          reject
        );

      handleSuccess(await res?.json(), resolve);
    } catch (error) {
      handleError(String(error), reject);
    }
  });

  dispatch(addRequest({ name, details, request: req }));
};

const Request = { API: requestAPI };

export const { addRequest, completeRequest } = requestSlice.actions;
export type { AppRequest, RequestsStoreState, requestAPIinterface, GenericAppState };
export {
  initialRequestsState,
  requestReducer,
  isLoading,
  Request,
};
export default requestSlice;
`},"gen_request_lib")};var oe=require("path");var re=async(e,t)=>{let n=(0,oe.join)(t,"/src/store"),i=`
import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { RequestsStoreState, requestReducer } from "@requests/index"; 


type ${e}State = {
    requestsStore: RequestsStoreState;
};

const ${e}Store = configureStore({
  reducer: combineReducers({
    requestsStore: requestReducer,
  }),
      middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoredActionPaths: ['payload.details.callback', 'payload.request'],
      ignoredPaths: ["requestsStore.activeRequests"],
    },
  }),
    // devTools: {
    // actionsDenylist: ['add_request', 'complete_request'],
    // },
});

export { ${e}Store };
export type { ${e}State };
        `;return l({dir:n,filename:"index.tsx",content:i},"gen_store")};var se=p(require("path"));var ae=async(e,t)=>{let n=se.default.join(t,"src/App.tsx"),i=[["AFTER",/import\s+['"]\.\/App\.css['"]/,`
import { Provider } from 'react-redux';
 import { ${e}Store } from './store';`],["AFTER",/\<\>/,`
<Provider store={${e}Store}>`],["BEFORE",/\<\/\>/,`</Provider>
`]];return r({file:n,injections:i},"inject_redux_provider")};var ce=p(require("path"));var le=async(e,t)=>{let n=ce.default.join(t,"package.json"),i=[["AFTER",/\"scripts\":\s+\{/,`
    "postinstall": "ln -s $(pwd)/node_modules ../${e}/lib/typescript/node_modules",`]];return r({file:n,injections:i},"inject_package_scripts")};var pe=p(require("path"));var me=async e=>{let t=pe.default.join(e,"package.json"),n=[["AFTER",/\"dependencies\":\s+\{/,`
    "@reduxjs/toolkit": "^2.3.0",
    "@types/react-redux": "^7.1.34",
    "deepmerge": "^4.3.1",
    "react-redux": "^9.1.2",`],["AFTER",/\"devDependencies\":\s+\{/,`
    "@babel/plugin-transform-private-property-in-object": "^7.25.9",
    "@types/node": "^22.10.0",
    "lorem-ipsum": "^2.0.8",`]];return r({file:t,injections:n},"inject_react_deps")};var ue=async({projectName:e,projectNameCamel:t,uidir:n,libdir:i})=>(f({projectName:e,projectNameCamel:t,uidir:n,libdir:i},"build_tool_agnostic_init_tasks"),[await Promise.all([re(t,n),ae(t,n),te(i),ie(i),le(e,n),me(n)]).catch(console.error)].flat());var de=p(require("path"));var _e=async(e,t)=>{let n=de.default.join(t,"mix.exs"),i=[["AFTER",/apps_path\:\s\"apps\"\,/,`
  apps: [:${e}, :${e}_web],`]];return r({file:n,injections:i},"inject_app_declarations")};var fe=p(require("path"));var ge=async(e,t)=>{let n=fe.default.join(t,"config/dev.exs"),i=[["BEFORE",/config\s*:\w+\s*,\s*\w+\.\s*Endpoint\s*,/,`config :${e}, CORSPlug, origin: "*"
`],["REPLACE",/(?<=config\s+:\w+,\s+\w+\.Repo,(\n\s+\w+:\s+[^\n]+){0,10}\n\s+database:\s+\")[^\n]+(?=\",)/,"postgres"]];return r({file:n,injections:i},"inject_dev_config")};var F=p(require("path"));var _t=async(e,t)=>{let n=F.default.join(t,"mix.exs"),i=[["AFTER",/defp\sdeps\sdo\s*\n{0,5}\s*\[/,`
      {:cors_plug, "~> 2.0"},`]];return r({file:n,injections:i},"inject_web_app_libs")},ft=async(e,t)=>Promise.resolve(!0),gt=async e=>{let t=F.default.join(e,"mix.exs"),n=[["AFTER",/\{\:ecto_sql\, \".*\"\}\,/,`
      {:scrivener_ecto, "~> 3.0"},`]];return r({file:t,injections:n},"inject_app_libs")},ye=async(e,{WebDir:t,AppDir:n,UmbrellaDir:i,LibDir:o})=>Promise.all([_t(e,t||""),gt(o||""),ft(e,i||"")]);var he=p(require("path"));var xe=async(e,t)=>{let n=he.default.join(t,`lib/${e}_web/endpoint.ex`),i=[["BEFORE",/plug\sPlug\.MethodOverride/,`plug CORSPlug, origin: Application.compile_env(:${e}, CORSPlug)[:origin]
`]];return r({file:n,injections:i},"inject_web_endpoint")};var ve=require("path");var je=async(e,t)=>{let n=(0,ve.join)(t||"","/lib/utils"),i=`
defmodule ${e}.Utils.Chunk do
  @size 1000

  @doc """
  Applies a function to a list in chunks with specified or default chunk size.
  """
  def apply(list, fun, size \\\\ @size) do
    list
    |> Enum.chunk_every(size)
    |> Enum.map(&fun.(&1))
  end

  @doc """
  Given a chunked list of :ok, :partial_success, or :error tuples, in
  {:status, succeeded_list, failed_list} or
  {:status, success_count, fail_count} format,
  reduce the result lists, counts, and status to summarize the entire operation.
  """
  def flat_reduce(chunked_tuples) do
    case List.first(chunked_tuples) do
      {status, s, f} when is_atom(status) and is_list(s) and is_list(f) ->
        chunked_tuples
        |> Enum.reduce({:ok, [], []}, fn
          # {:status, created [], invalid []}
          # destructured chunk, destructured accumulator -> accumulated result
          {:ok, c, []}, {:ok, csum, []} -> {:ok, csum ++ c, []}
          {:ok, c, []}, {_, csum, isum} -> {:partial_success, csum ++ c, isum}
          {:partial_success, c, i}, {_, csum, isum} -> {:partial_success, csum ++ c, isum ++ i}
          {:error, [], i}, {_, [], isum} -> {:error, [], isum ++ i}
          {:error, [], i}, {_, csum, isum} -> {:partial_success, csum, isum ++ i}
        end)

      {status, s, f} when is_atom(status) and is_integer(s) and is_integer(f) ->
        chunked_tuples
        |> Enum.reduce({:ok, 0, 0}, fn
          # {:status, succeeded 0, failed 0}
          # destructured chunk, destructured accumulator -> accumulated result
          {:ok, s, 0}, {:ok, ssum, 0} -> {:ok, ssum + s, 0}
          {:ok, s, 0}, {_, ssum, fsum} -> {:partial_success, ssum + s, fsum}
          {:partial_success, s, f}, {_, ssum, fsum} -> {:partial_success, ssum + s, fsum + f}
          {:error, 0, f}, {_, 0, fsum} -> {:error, 0, fsum + f}
          {:error, 0, f}, {_, ssum, fsum} -> {:partial_success, ssum, fsum + f}
        end)
    end
  end

  @doc """
  Given a list of records, prep the chunk for bulk db edits
  """
  def prep(changesets, opts \\\\ %{}) do
    def_opts = %{
      inserted_at?: true
    }

    %{inserted_at?: inserted} = Map.merge(def_opts, opts)
    timestamp = NaiveDateTime.utc_now() |> NaiveDateTime.truncate(:second)

    changesets
    |> Enum.map(& &1.changes)
    |> Enum.map(fn record ->
      new_properties =
        case [inserted] do
          [true] -> Map.merge(record, %{inserted_at: timestamp, updated_at: timestamp})
          [false] -> Map.delete(record, :inserted_at) |> Map.merge(%{updated_at: timestamp})
        end

      Map.merge(record, new_properties)
    end)
  end
end
`;return l({dir:n,filename:"chunk.ex",content:i},"gen_chunk_util")};var be=require("path");var ke=async(e,t)=>{let n=(0,be.join)(t||"","/lib/utils"),i=`
defmodule ${e}.Utils.DynamicQuery do
  import Ecto.Query
  @moduledoc """
  A utility module for building dynamic queries based on controller level restful query params.
  Pass the params and schema to by_schema to convert the restful query to a database query.
  """

  @doc """
  Given a map of controller level restful query params and a schema module,
      cast controller parameters to schema types for dynamic Ecto query construction.
  """
  def by_schema(controller_params, schema_module) do
    field_types = get_schema_field_types(schema_module)

    case validate_params(controller_params, field_types) do
      {:ok, parsed_params} ->
        query = Enum.reduce(parsed_params, from(s in schema_module), &apply_filter/2)

        opts =
          Enum.reduce(parsed_params, %{}, fn {key, op, value}, acc ->
            Map.put(acc, key, "#{op} #{value}")
          end)

        {:ok, query, opts}

      error_forward ->
        error_forward
    end
  end

  @doc """
  Given a schema module, return a map of field names to their types.
  """
  def get_schema_field_types(schema_module) when is_atom(schema_module) do
    schema_module.__schema__(:fields)
    |> Enum.map(fn field ->
      {field, schema_module.__schema__(:type, field)}
    end)
    |> Enum.into(%{})
  end

  @doc """
  Given controller level params and designated field types, validate the mathmatical operator and return a list of parsed params.
  """
  def validate_params(params, field_types) do
    Enum.reduce_while(params, {:ok, []}, fn {key, value}, {:ok, acc} ->
      case parse_param(key, value, field_types) do
        {:ok, parsed_param} -> {:cont, {:ok, [parsed_param | acc]}}
        {:error, message} -> {:halt, {:error, message}}
      end
    end)
  end

  @doc """
  Build query with parsed params.
  """
  def apply_filter({field, operator, value}, query) do
    field_atom = String.to_atom(field)

    dynamic_clause =
      case operator do
        "<" -> dynamic([u], field(u, ^field_atom) < ^value)
        ">" -> dynamic([u], field(u, ^field_atom) > ^value)
        "<=" -> dynamic([u], field(u, ^field_atom) <= ^value)
        ">=" -> dynamic([u], field(u, ^field_atom) >= ^value)
        "=" -> dynamic([u], field(u, ^field_atom) == ^value)
        _ -> raise "Invalid operator: #{operator}"
      end

    where(query, ^dynamic_clause)
  end

  # Check type of each param and build where clauses
  defp parse_param(key, value, field_types) do
    reg =
      ~r/(?<key>[_a-zA-z0-9]+)(?<operator>[ =<>])(?<value>.*)/
      |> Regex.named_captures(key)

    case reg do
      nil ->
        {:ok, {key, "=", value}}

      %{"key" => k, "operator" => o, "value" => v} ->
        validate_param_type(k, o, v, field_types)
    end
  end

  # Validate type based on the schema's field types
  defp validate_param_type(key, operator, value, field_types) do
    expected_type = Map.get(field_types, String.to_atom(key))

    case {expected_type, parse_value(value, expected_type)} do
      {nil, _} -> {:error, "Unknown field #{key}"}
      {_, :error} -> {:error, "Invalid value for #{key}. Expected a #{expected_type}."}
      {_, parsed_value} -> {:ok, {key, operator, parsed_value}}
    end
  end

  # Parse the value based on expected type
  defp parse_value(value, :integer) do
    case Integer.parse(value) do
      {v, ""} -> v
      _ -> :error
    end
  end

  defp parse_value(value, :string), do: value
end

defmodule ${e}.Plugs.ListAsJSON do
  @moduledoc """
  A plug for controllers that allows lists to be sent as top-level JSON arrays
  without needing to wrap them in an object. It detects the "_json" param and
  elevates it to the top level.
  """

  def init(options), do: options

  def call(%Plug.Conn{params: %{"_json" => json_data}} = conn, _opts) do
    %{conn | params: json_data}
  end

  def call(conn, _opts), do: conn
end
`;return l({dir:n,filename:"dynamic_query.ex",content:i},"gen_dynamic_query_util")};var Ee=require("path");var we=async(e,t)=>{let n=(0,Ee.join)(t||"","/lib/utils"),i=`
defmodule ${e}.Utils.Paginate do
  @doc """
  Utility functions for pagination with Scriniver Lib.
  """

  def apply(query, repo, pagination_options \\\\ %{}) do
    page = repo.paginate(query, default(pagination_options))
    res = page |> Map.get(:entries)
    params = Map.drop(page, [:entries])

    {:ok, res, Map.from_struct(params)}
  end

  def default(opts) do
    %{
      page: 1,
      page_size: 100,
      max_page_size: 1000
    }
    |> Map.merge(opts)
  end

  def split_page_opts(opts) do
    page_opts = ["page", "page_size", "max_page_size", "filter", "select", "sort"]

    {Map.drop(opts, page_opts), Map.take(opts, page_opts)}
  end
end
`;return l({dir:n,filename:"paginate.ex",content:i},"gen_paginate_util")};var Re=require("path");var Se=async(e,t)=>{let n=(0,Re.join)(t||"","/lib/utils"),i=`
defmodule ${e}.Utils.MapUtil do
  def get(map, key, default \\\\ nil),
    do: Map.get(map, key, false) || Map.get(map, Atom.to_string(key), default)

  def str_to_atom(map),
    do:
      Map.keys(map)
      |> Enum.reduce(%{}, fn key, acc -> Map.put(acc, to_atom(key), Map.get(map, key)) end)

  defp to_atom(string) when is_binary(string), do: String.to_atom(string)
  defp to_atom(atom) when is_atom(atom), do: atom

  def id_list_from(list) when is_list(list) do
    Enum.map(list, fn 
      s when is_binary(s) -> s; 
      m when is_map(m) -> get(m, :id);
    end)
  end
end
`;return l({dir:n,filename:"map.ex",content:i},"gen_map_util")};var Ie=async(e,t)=>Promise.all([je(e,t),ke(e,t),we(e,t),Se(e,t)]);var $e=p(require("path"));var qe=async e=>{let{LibDir:t,AppNameSnake:n}=e||{},i=$e.default.join(t||".",`lib/${n}/repo.ex`),o=[["BEFORE",/end[\s\n]*$/,`  use Scrivener
`]];return r({file:i,injections:o},"inject_scrinever")};var Pe=require("path");var Oe=async(e,t)=>{let n=(0,Pe.join)(t,"/lib/mix/tasks"),i=`
defmodule Mix.Tasks.Compile.CustomCompiler do
  use Mix.Task.Compiler

  @impl Mix.Task.Compiler
  def run(_args) do
    case System.cmd("npm", ["run", "build", "--emptyOutDir"], stderr_to_stdout: true, cd: "apps/${e}_ui") do
      {output, 0} ->
        IO.puts(output)
        {:ok, []}
      {output, _exit_code} ->
        IO.puts(:stderr, output)
        {:error, []}
    end
  end

  @impl Mix.Task.Compiler
  def manifests, do: []
end
`;return l({dir:n,filename:"custom_compiler.ex",content:i},"gen_custom_compiler")};var Fe=require("path");var Le=async(e,t,n)=>{let i=(0,Fe.join)(n,`/lib/${e}_web/controllers`),o=`
defmodule ${t}Web.PageController do
  use ${t}Web, :controller

  def index(conn, _params) do
    # Serve the static index.html file
    conn
    |> put_resp_content_type("text/html")
    |> send_file(200, Path.join([:code.priv_dir(:${e}_web), "static", "index.html"]))
  end
end

`;return l({dir:i,filename:"page_controller.ex",content:o},"gen_page_controller")};var Te=p(require("path"));var Me=async(e,t)=>{let n=Te.default.join(t,"mix.exs"),i=[["AFTER",/def\sproject\s+do[\s\n]+\[/,`compilers: Mix.compilers() ++ [:custom_compiler],
`]];return r({file:n,injections:i},"inject_custom_compile_to_mix_exs")};var Ae=p(require("path"));var Ce=async(e,t,n)=>{let i=Ae.default.join(n,`lib/${e}_web/router.ex`),o=[["BEFORE",/pipeline\s+\:api\s+do/,`
  scope "/", ${t}Web do
    get "/", PageController, :index
  end
`]];return r({file:i,injections:o},"inject_page_to_router")};var De=p(require("path"));var Ue=async(e,t)=>{let n=De.default.join(t,`lib/${e}_web/endpoint.ex`),i=[["REPLACE",/(?<=plug\(Plug\.Static\,.*only:\s)[^\n]*/s,"~w(assets fonts images js css vite.svg index.html)"]];return r({file:n,injections:i},"inject_static_output_to_endpoint")};var Ge=async({AppName:e,AppNameCamel:t,WebDir:n,LibDir:i})=>{f({AppName:e,AppNameCamel:t,WebDir:n,LibDir:i},"configure_phoenix_to_serve_react");let o=await Le(e,t,n),a=await Ue(e,n),s=await Ce(e,t,n),u=await Oe(e,i),m=await Me(e,n);return[o,a,s,u,m].flat()};var Be=p(require("path"));var ze=async(e,t)=>{let n=Be.default.join(t,"mix.exs"),i=[["BEFORE",/defp\s+aliases\s+do[\s\n]+\[/,`
  defp npm_install(_) do
    Mix.shell().cmd("npm install", cd: "apps/${e}_ui")
  end


`],["AFTER",/defp\s+aliases\s+do[\s\n]+\[/,`
"deps.get": ["deps.get", &npm_install/1],`]];return r({file:n,injections:i},"inject_deps_get_aliases_to_mix_exs")};var We=require("path");var Ve=async(e,t)=>{let n=(0,We.join)(t,"/lib/mix/tasks/"),i=`
defmodule Mix.Tasks.CustomFormatter do
  use Mix.Task

  def run(args \\\\ []) do
    IO.puts("Immutable Formatter")

    {js_paths, ex_paths} =
      Enum.split_with(args, fn path ->
        String.contains?(path, "apps/${e}_ui") || String.ends_with?(path, ".ts") ||
          String.ends_with?(path, ".tsx")
      end)

    js_paths = Enum.map(js_paths, &String.replace(&1, ~r/(.*){0,1}apps\\/${e}_ui\\//, ""))

    IO.puts("Formatting Elixir files...")
    Mix.Task.run("format", ex_paths)

    IO.puts("Formatting TS files...")
    format_react_files(js_paths)

    IO.puts("Complete.")
  end

  defp format_react_files(paths) do
    js_paths = Enum.join(paths, " ")

    {_result, 0} =
      System.cmd("bash", ["-c", "npm run format #{js_paths}"], cd: "./apps/${e}_ui")

    # IO.puts(result)
  end
end
`;return l({dir:n,filename:"custom_formatter.ex",content:i},"gen_custom_formatter")};var Je=p(require("path"));var Ye=async e=>{let t=Je.default.join(e,"mix.exs"),n=[["AFTER",/defp\s+aliases\s+do[\s\n]+\[/s,`
format: "custom_formatter",`]];return r({file:t,injections:n},"inject_custom_format_to_mix_exs")};var Ke=async({AppName:e,LibDir:t})=>{f({AppName:e,LibDir:t},"configure_phoenix_to_format_react");let n=Ve(e,t),i=Ye(t);return[n,i].flat()};var Qe=async({projectName:e,projectNameCamel:t,umbrellaDir:n,libdir:i,webdir:o})=>{f({projectName:e,projectNameCamel:t,umbrellaDir:n,libdir:i,webdir:o},"init_phoenix_umbrella_app"),c({level:2,color:"BLUE"},`
Generating Phoenix project...`);let a=await x({command:`mix phx.new ${e} --no-live --no-html --no-assets --binary-id --umbrella --no-install`,dir:"."},"init_phoenix_umbrella_app"),s=await _e(e,n),u=await Promise.all([ye(e,{WebDir:o,LibDir:i}),xe(e,o),ge(e,n),qe({LibDir:i,AppNameSnake:e}),Ie(t,i)]),m=await Ge({AppName:e,AppNameCamel:t,WebDir:o,LibDir:i}),g=await Ke({AppName:e,LibDir:i}),_=await ze(e,n);return[a,s,u,m,g,_].flat()};var Xe=process.argv.slice(2);async function yt(){Xe.length<1&&(console.error(`Usage: node init_proj.js <project_name>
   Or: immutable -init <project_name>`),process.exit(1));let e=Xe[0];e=e.toLowerCase().replace(/[\s-]/g,"_").replace(/[^a-z0-9_]/g,"");let t=e.split("_").map(_=>_.charAt(0).toUpperCase()+_.slice(1)).join(""),n=process.cwd(),i=(0,j.join)(n,`${e}_umbrella`),o=(0,j.join)(i,"apps"),a=(0,j.join)(o,e),s=(0,j.join)(o,`${e}_ui`),u=(0,j.join)(o,`${e}_web`);U(i),c({level:1,color:"GREEN"},`

 Generating ${e} App with Immutable Stack

`),await Qe({projectName:e,projectNameCamel:t,umbrellaDir:i,libdir:a,webdir:u}),await N({projectName:e,projectNameCamel:t,appdir:o,uidir:s,webdir:u,libdir:a}),await ue({projectName:e,projectNameCamel:t,uidir:s,libdir:a}),C(i,`init_project_${e}`);let m=await x({command:"mix deps.get",dir:i},"init_proj"),g=await x({command:"mix compile",dir:i},"init_proj");c({level:1,color:"GREEN"},`

Initialization Complete.

Generated ${e}_umbrella`),c({level:1,color:"BLUE"},`    in ${n}

`)}yt().catch(console.error);
