"use strict";var h=Object.create;var g=Object.defineProperty;var w=Object.getOwnPropertyDescriptor;var D=Object.getOwnPropertyNames;var x=Object.getPrototypeOf,T=Object.prototype.hasOwnProperty;var p=(e,n,t,r)=>{if(n&&typeof n=="object"||typeof n=="function")for(let s of D(n))!T.call(e,s)&&s!==t&&g(e,s,{get:()=>n[s],enumerable:!(r=w(n,s))||r.enumerable});return e};var d=(e,n,t)=>(t=e!=null?h(x(e)):{},p(n||!e||!e.__esModule?g(t,"default",{value:e,enumerable:!0}):t,e)),$=e=>p(g({},"__esModule",{value:!0}),e);var k={};module.exports=$(k);var y=d(require("fs")),f=d(require("path"));var l=require("child_process"),c=require("fs/promises"),M=(e,n,t)=>{let r=(t.DatabaseModel||t.ImmutableGlobal).ex,s=n.generate.databaseModel,i=Object.keys(r).map(a=>`add :${a}, :${r[a]}`).join(`
`);return new Promise(async(a,o)=>{e||o(!1);try{let b=(await(0,c.readFile)(e,"utf-8")).replace(/def\s+change\s+do\s*\n{0,10}\s*end/g,C=>`
  def up do
    create table(:${s}) do
      ${i}

      timestamps()
    end
  end

  def down do
    drop table(:${s})
  end`);await(0,c.writeFile)(e,b,"utf-8"),a(!0)}catch(m){console.log("Could not update migration: ",m),o(!1)}})},_=e=>new Promise((n,t)=>{try{let r=`mix ecto.gen.migration create_${e.generate.databaseModel}`;(0,l.exec)(r,(s,i,a)=>{let o=i.match(/\* creating (.+\.exs)/);o&&o[1]&&!s&&!a?(n(o[1]),console.log(`Migration created at ${o[1]}`)):(console.error(`Error creating migration: ${s||a}`),t(null))})}catch(r){console.error(r),t(null)}}),u=async(e,n)=>{let t=await _(e);await M(t||"",e,n),(0,l.exec)(`mix format ${t}`)};var G=(e,n,t={})=>(e.match(/interface (\w+).*?extends GenType<.*?> \{\}/gs)?.map(r=>F(r,n)).forEach(({name:r,ts:s,ex:i})=>{let a=Object.keys(s||{}).length>0,o=Object.keys(i||{}).length>0;r&&a&&o&&(t[r]={ts:s,ex:i})}),t),F=(e,n,t={name:null,ts:{},ex:{}})=>{let r=e.match(/interface\s(\w+)/),s=/(\w+):\s(\w+)/gs;return Object.assign(t,{name:r?.[1]}),e.replace(s,(i,a,o)=>(t.ex[a]=o,t.ts[a]=n[o],i)),t},I=(e,n={})=>{let t=/type\s(\w+)\s=\s(\w+)\s&\s\{\s__brand\:/gs;return e.replace(t,(r,s,i)=>(n[s]=i,r)),n},O=e=>{let n=/Immutable\s\:\sImmutableGenerator\s=([\s\S]*?)\/\*.*DECLARATIONS/,t=e.match(n)?.[1].replace(/(\w+):/g,'"$1":')?.replace(/,\s*\}/gs,"}");return JSON.parse(t||"{}")},S=async()=>{let e=process.argv.slice(2);e.length<1&&(console.error("Please provide the input file path as an argument."),process.exit(1));let n=y.readFileSync(f.resolve(e[0]),"utf8"),t=I(n),r=O(n),s=G(n,t);console.log(r,s),console.log(await u(r,s))};S().catch(console.error);
//# sourceMappingURL=gen.js.map
