"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const gen_migration_1 = require("./gen_migration");
const getGenTypes = (fileContent, typeDict, mem = {}) => {
    fileContent
        .match(/interface (\w+).*?extends GenType<.*?> \{\}/gs)
        ?.map((match) => interperetType(match, typeDict))
        .forEach(({ name, ts, ex }) => {
        const hasTs = Object.keys(ts || {}).length > 0, hasEx = Object.keys(ex || {}).length > 0;
        if (name && hasTs && hasEx)
            mem[name] = { ts, ex };
    });
    return mem;
};
const interperetType = (str, dict, mem = { name: null, ts: {}, ex: {} }) => {
    const name = str.match(/interface\s(\w+)/);
    const attr_reg = /(\w+):\s(\w+)/gs;
    Object.assign(mem, { name: name?.[1] });
    str.replace(attr_reg, (match, k, v) => {
        mem.ex[k] = v;
        mem.ts[k] = dict[v];
        return match;
    });
    return mem;
};
const getTypeEquivalents = (file, mem = {}) => {
    const type_reg = /type\s(\w+)\s=\s(\w+)\s&\s\{\s__brand\:/gs;
    file.replace(type_reg, (f, ex, ts) => {
        mem[ex] = ts;
        return f;
    });
    return mem;
};
const getGenerator = (file) => {
    const gen_reg = /Immutable\s\:\sImmutableGenerator\s=([\s\S]*?)\/\*.*DECLARATIONS/;
    const gen = file
        .match(gen_reg)?.[1]
        .replace(/(\w+):/g, '"$1":')
        ?.replace(/,\s*\}/gs, "}");
    return JSON.parse(gen || "{}");
};
const main = async () => {
    const args = process.argv.slice(2);
    if (args.length < 1) {
        console.error("Please provide the input file path as an argument.");
        process.exit(1);
    }
    const fileContent = fs.readFileSync(path.resolve(args[0]), "utf8");
    const typeDict = getTypeEquivalents(fileContent);
    const gen = getGenerator(fileContent);
    const mem = getGenTypes(fileContent, typeDict);
    console.log(gen, mem);
    console.log(await (0, gen_migration_1.createMigration)(gen, mem));
};
main().catch(console.error);
