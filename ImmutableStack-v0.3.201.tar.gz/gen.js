"use strict";var Xr=Object.create;var ne=Object.defineProperty;var Jr=Object.getOwnPropertyDescriptor;var Nr=Object.getOwnPropertyNames;var en=Object.getPrototypeOf,tn=Object.prototype.hasOwnProperty;var x=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var De=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Nr(t))!tn.call(e,o)&&o!==r&&ne(e,o,{get:()=>t[o],enumerable:!(n=Jr(t,o))||n.enumerable});return e};var A=(e,t,r)=>(r=e!=null?Xr(en(e)):{},De(t||!e||!e.__esModule?ne(r,"default",{value:e,enumerable:!0}):r,e)),rn=e=>De(ne({},"__esModule",{value:!0}),e);var me=x((de,ue)=>{(function(e,t){typeof require=="function"&&typeof de=="object"&&typeof ue=="object"?ue.exports=t():typeof define=="function"&&define.amd?define(function(){return t()}):e.pluralize=t()})(de,function(){var e=[],t=[],r={},n={},o={};function s(d){return typeof d=="string"?new RegExp("^"+d+"$","i"):d}function i(d,_){return d===_?_:d===d.toLowerCase()?_.toLowerCase():d===d.toUpperCase()?_.toUpperCase():d[0]===d[0].toUpperCase()?_.charAt(0).toUpperCase()+_.substr(1).toLowerCase():_.toLowerCase()}function a(d,_){return d.replace(/\$(\d{1,2})/g,function($,y){return _[y]||""})}function c(d,_){return d.replace(_[0],function($,y){var v=a(_[1],arguments);return i($===""?d[y-1]:$,v)})}function l(d,_,$){if(!d.length||r.hasOwnProperty(d))return _;for(var y=$.length;y--;){var v=$[y];if(v[0].test(_))return c(_,v)}return _}function m(d,_,$){return function(y){var v=y.toLowerCase();return _.hasOwnProperty(v)?i(y,v):d.hasOwnProperty(v)?i(y,d[v]):l(v,y,$)}}function g(d,_,$,y){return function(v){var M=v.toLowerCase();return _.hasOwnProperty(M)?!0:d.hasOwnProperty(M)?!1:l(M,M,$)===M}}function f(d,_,$){var y=_===1?f.singular(d):f.plural(d);return($?_+" ":"")+y}return f.plural=m(o,n,e),f.isPlural=g(o,n,e),f.singular=m(n,o,t),f.isSingular=g(n,o,t),f.addPluralRule=function(d,_){e.push([s(d),_])},f.addSingularRule=function(d,_){t.push([s(d),_])},f.addUncountableRule=function(d){if(typeof d=="string"){r[d.toLowerCase()]=!0;return}f.addPluralRule(d,"$0"),f.addSingularRule(d,"$0")},f.addIrregularRule=function(d,_){_=_.toLowerCase(),d=d.toLowerCase(),o[d]=_,n[_]=d},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(d){return f.addIrregularRule(d[0],d[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(d){return f.addPluralRule(d[0],d[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(d){return f.addSingularRule(d[0],d[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(f.addUncountableRule),f})});var Se=x(E=>{"use strict";Object.defineProperty(E,"__esModule",{value:!0});E.FORMAT_PLAIN=E.FORMAT_HTML=E.FORMATS=void 0;var sr="html";E.FORMAT_HTML=sr;var or="plain";E.FORMAT_PLAIN=or;var ti=[sr,or];E.FORMATS=ti});var mr=x(I=>{"use strict";Object.defineProperty(I,"__esModule",{value:!0});I.UNIT_WORDS=I.UNIT_WORD=I.UNIT_SENTENCES=I.UNIT_SENTENCE=I.UNIT_PARAGRAPHS=I.UNIT_PARAGRAPH=I.UNITS=void 0;var ar="words";I.UNIT_WORDS=ar;var cr="word";I.UNIT_WORD=cr;var lr="sentences";I.UNIT_SENTENCES=lr;var pr="sentence";I.UNIT_SENTENCE=pr;var dr="paragraphs";I.UNIT_PARAGRAPHS=dr;var ur="paragraph";I.UNIT_PARAGRAPH=ur;var ri=[ar,cr,lr,pr,dr,ur];I.UNITS=ri});var Te=x(L=>{"use strict";Object.defineProperty(L,"__esModule",{value:!0});L.WORDS=void 0;var ni=["ad","adipisicing","aliqua","aliquip","amet","anim","aute","cillum","commodo","consectetur","consequat","culpa","cupidatat","deserunt","do","dolor","dolore","duis","ea","eiusmod","elit","enim","esse","est","et","eu","ex","excepteur","exercitation","fugiat","id","in","incididunt","ipsum","irure","labore","laboris","laborum","Lorem","magna","minim","mollit","nisi","non","nostrud","nulla","occaecat","officia","pariatur","proident","qui","quis","reprehenderit","sint","sit","sunt","tempor","ullamco","ut","velit","veniam","voluptate"];L.WORDS=ni});var _r=x(k=>{"use strict";Object.defineProperty(k,"__esModule",{value:!0});k.LINE_ENDINGS=void 0;var ii={POSIX:`
`,WIN32:`\r
`};k.LINE_ENDINGS=ii});var fr=x(z=>{"use strict";Object.defineProperty(z,"__esModule",{value:!0});z.default=void 0;var si=function(t){var r=t.trim();return r.charAt(0).toUpperCase()+r.slice(1)},oi=si;z.default=oi});var $r=x((B,Pe)=>{"use strict";Object.defineProperty(B,"__esModule",{value:!0});B.default=void 0;var ai=function(){return typeof Pe<"u"&&!!Pe.exports},ci=ai;B.default=ci});var gr=x(H=>{"use strict";Object.defineProperty(H,"__esModule",{value:!0});H.default=void 0;var li=function(){var t=!1;try{t=navigator.product==="ReactNative"}catch{t=!1}return t},pi=li;H.default=pi});var hr=x(Z=>{"use strict";Object.defineProperty(Z,"__esModule",{value:!0});Z.SUPPORTED_PLATFORMS=void 0;var di={DARWIN:"darwin",LINUX:"linux",WIN32:"win32"};Z.SUPPORTED_PLATFORMS=di});var yr=x(K=>{"use strict";Object.defineProperty(K,"__esModule",{value:!0});K.default=void 0;var ui=hr(),mi=function(){var t=!1;try{t=process.platform===ui.SUPPORTED_PLATFORMS.WIN32}catch{t=!1}return t},_i=mi;K.default=_i});var Ge=x(Y=>{"use strict";Object.defineProperty(Y,"__esModule",{value:!0});Y.default=void 0;var fi=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:0;return Array.apply(null,Array(t)).map(function(r,n){return n})},$i=fi;Y.default=$i});var vr=x(Q=>{"use strict";Object.defineProperty(Q,"__esModule",{value:!0});Q.default=void 0;var gi=hi(Ge());function hi(e){return e&&e.__esModule?e:{default:e}}var yi=function(t,r){var n=(0,gi.default)(t);return n.map(function(){return r()})},vi=yi;Q.default=vi});var qe=x(w=>{"use strict";Object.defineProperty(w,"__esModule",{value:!0});Object.defineProperty(w,"capitalize",{enumerable:!0,get:function(){return bi.default}});Object.defineProperty(w,"isNode",{enumerable:!0,get:function(){return xi.default}});Object.defineProperty(w,"isReactNative",{enumerable:!0,get:function(){return Ii.default}});Object.defineProperty(w,"isWindows",{enumerable:!0,get:function(){return Oi.default}});Object.defineProperty(w,"makeArrayOfLength",{enumerable:!0,get:function(){return Mi.default}});Object.defineProperty(w,"makeArrayOfStrings",{enumerable:!0,get:function(){return Ai.default}});var bi=G(fr()),xi=G($r()),Ii=G(gr()),Oi=G(yr()),Mi=G(Ge()),Ai=G(vr());function G(e){return e&&e.__esModule?e:{default:e}}});var xr=x(X=>{"use strict";Object.defineProperty(X,"__esModule",{value:!0});X.default=void 0;var Ri=Te(),Ce=qe();function Ei(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function br(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function wi(e,t,r){return t&&br(e.prototype,t),r&&br(e,r),Object.defineProperty(e,"prototype",{writable:!1}),e}function V(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var Si=function(){function e(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=t.sentencesPerParagraph,n=r===void 0?{max:7,min:3}:r,o=t.wordsPerSentence,s=o===void 0?{max:15,min:5}:o,i=t.random,a=t.seed,c=t.words,l=c===void 0?Ri.WORDS:c;if(Ei(this,e),V(this,"sentencesPerParagraph",void 0),V(this,"wordsPerSentence",void 0),V(this,"random",void 0),V(this,"words",void 0),n.min>n.max)throw new Error("Minimum number of sentences per paragraph (".concat(n.min,") cannot exceed maximum (").concat(n.max,")."));if(s.min>s.max)throw new Error("Minimum number of words per sentence (".concat(s.min,") cannot exceed maximum (").concat(s.max,")."));this.sentencesPerParagraph=n,this.words=l,this.wordsPerSentence=s,this.random=i||Math.random}return wi(e,[{key:"generateRandomInteger",value:function(r,n){return Math.floor(this.random()*(n-r+1)+r)}},{key:"generateRandomWords",value:function(r){var n=this,o=this.wordsPerSentence,s=o.min,i=o.max,a=r||this.generateRandomInteger(s,i);return(0,Ce.makeArrayOfLength)(a).reduce(function(c,l){return"".concat(n.pluckRandomWord()," ").concat(c)},"").trim()}},{key:"generateRandomSentence",value:function(r){return"".concat((0,Ce.capitalize)(this.generateRandomWords(r)),".")}},{key:"generateRandomParagraph",value:function(r){var n=this,o=this.sentencesPerParagraph,s=o.min,i=o.max,a=r||this.generateRandomInteger(s,i);return(0,Ce.makeArrayOfLength)(a).reduce(function(c,l){return"".concat(n.generateRandomSentence()," ").concat(c)},"").trim()}},{key:"pluckRandomWord",value:function(){var r=0,n=this.words.length-1,o=this.generateRandomInteger(r,n);return this.words[o]}}]),e}(),Ti=Si;X.default=Ti});var Mr=x(ee=>{"use strict";Object.defineProperty(ee,"__esModule",{value:!0});ee.default=void 0;var J=Se(),Ir=_r(),Pi=Gi(xr()),N=qe();function Gi(e){return e&&e.__esModule?e:{default:e}}function qi(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function Or(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function Ci(e,t,r){return t&&Or(e.prototype,t),r&&Or(e,r),Object.defineProperty(e,"prototype",{writable:!1}),e}function Di(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var Fi=function(){function e(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:J.FORMAT_PLAIN,n=arguments.length>2?arguments[2]:void 0;if(qi(this,e),this.format=r,this.suffix=n,Di(this,"generator",void 0),J.FORMATS.indexOf(r.toLowerCase())===-1)throw new Error("".concat(r," is an invalid format. Please use ").concat(J.FORMATS.join(" or "),"."));this.generator=new Pi.default(t)}return Ci(e,[{key:"getLineEnding",value:function(){return this.suffix?this.suffix:!(0,N.isReactNative)()&&(0,N.isNode)()&&(0,N.isWindows)()?Ir.LINE_ENDINGS.WIN32:Ir.LINE_ENDINGS.POSIX}},{key:"formatString",value:function(r){return this.format===J.FORMAT_HTML?"<p>".concat(r,"</p>"):r}},{key:"formatStrings",value:function(r){var n=this;return r.map(function(o){return n.formatString(o)})}},{key:"generateWords",value:function(r){return this.formatString(this.generator.generateRandomWords(r))}},{key:"generateSentences",value:function(r){return this.formatString(this.generator.generateRandomParagraph(r))}},{key:"generateParagraphs",value:function(r){var n=this.generator.generateRandomParagraph.bind(this.generator);return this.formatStrings((0,N.makeArrayOfStrings)(r,n)).join(this.getLineEnding())}}]),e}(),ji=Fi;ee.default=ji});var Rr=x(D=>{"use strict";Object.defineProperty(D,"__esModule",{value:!0});Object.defineProperty(D,"LoremIpsum",{enumerable:!0,get:function(){return Ar.default}});D.loremIpsum=void 0;var Ui=Se(),T=mr(),Wi=Te(),Ar=Li(Mr());function Li(e){return e&&e.__esModule?e:{default:e}}var ki=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=t.count,n=r===void 0?1:r,o=t.format,s=o===void 0?Ui.FORMAT_PLAIN:o,i=t.paragraphLowerBound,a=i===void 0?3:i,c=t.paragraphUpperBound,l=c===void 0?7:c,m=t.random,g=t.sentenceLowerBound,f=g===void 0?5:g,d=t.sentenceUpperBound,_=d===void 0?15:d,$=t.units,y=$===void 0?T.UNIT_SENTENCES:$,v=t.words,M=v===void 0?Wi.WORDS:v,F=t.suffix,te=F===void 0?"":F,re={random:m,sentencesPerParagraph:{max:l,min:a},words:M,wordsPerSentence:{max:_,min:f}},q=new Ar.default(re,s,te);switch(y){case T.UNIT_PARAGRAPHS:case T.UNIT_PARAGRAPH:return q.generateParagraphs(n);case T.UNIT_SENTENCES:case T.UNIT_SENTENCE:return q.generateSentences(n);case T.UNIT_WORDS:case T.UNIT_WORD:return q.generateWords(n);default:return""}};D.loremIpsum=ki});var Ki={};module.exports=rn(Ki);var Kr=A(require("path"));var Fe=require("fs"),ae=A(require("path"));var p=(e,t=null)=>(Object.keys(e).forEach(r=>{let n=e[r];if(n==null)throw console.error(`${r} in StringOnlyMap cannot be null or undefined.
     Caller: ${t}`),`${r} in StringOnlyMap cannot be null or undefined. Caller: ${t}`}),!0),ie=(e,t)=>t.reduce((r,n)=>r?.[n],e);var se=(e,t,r)=>{let n=t.pop(),o=ie(e,t);o&&typeof o=="object"?o[n]=r:se(e,t,{[n]:r})};var oe=null,P={_name:null,commands:[],file_modifications:{}},je=({command:e,dir:t},r=null)=>{P.commands.push({command:e,dir:t,caller:r||"unreferenced"})},ce=({filename:e,dir:t},r=null)=>{p({filename:e,dir:t},r);let n=nn(t),{file_modifications:o}=P,s=n.split("/").filter(c=>c).concat([e]),a=(ie(o,s)||[]).concat([r||"unreferenced"]);return se(P,["file_modifications",...s],a),P},Ue=(e,t)=>{P._name=t;let r=JSON.stringify(P,null,2);(0,Fe.writeFileSync)(ae.default.resolve(e,`.immutable_history_${t}.json`),r,"utf8")},We=(e,t=null)=>{let r=e.split("/").filter(s=>s),n=r.slice(-1)[0],o=r.slice(0,-1).join("/");return ce({filename:n,dir:o},t)},Le=e=>{oe=ae.default.resolve(e).replace(/^[^\w]+/,"")},nn=e=>(e=e.replace(/^[^\w]+/,""),(oe?e.replace(oe,""):e).replace(/^[^\w]+/,""));var le=99,sn={GREEN:"\x1B[32m%s\x1B[0m",RED:"\x1B[31m%s\x1B[0m",YELLOW:"\x1B[33m%s\x1B[0m",BLUE:"\x1B[34m%s\x1B[0m"},ke=e=>(le=e,le),u=async({level:e,color:t},...r)=>{if(e<=le)return r=t?[sn[t],...r]:r,e<5&&console.log(`

`),console.log(...r),await pe(e>=5?0:5-e)},pe=e=>new Promise(t=>setTimeout(t,e*1e3));var Ne=A(require("fs"));var ze=require("fs/promises"),C=A(require("path"));var Be=async()=>{try{u({level:8},`Getting App Data from mix.exs in ${process.cwd()}`);let t=(await(0,ze.readFile)("mix.exs","utf-8")).match(/(?<=defmodule\s+)\w+(?=\.Umbrella\.MixProject)/)?.[0]||"",r=t?.replace(/([A-Z])/g,"_$1")?.toLowerCase()?.slice(1),n=r.toUpperCase(),o=process.cwd(),s=C.default.join(o,"apps"),i=C.default.join(s,r),a=C.default.join(s,`${r}_ui`),c=C.default.join(s,`${r}_web`);return{AppNameCamel:t,AppNameSnake:r,AppNameCaps:n,AppDir:s,LibDir:i,UiDir:a,WebDir:c,UmbrellaDir:o}}catch(e){console.error(`Could not get AppName from mix.exs
${e}`)}};var He=e=>{let t=/(?<=const\s+Immutable:\s+ImmutableGenerator\s+=\s+)[\s\S]*?(?=[\s\n\*;]+PRIMITIVES)/,r=e.match(t)?.[0],n={},o=[["keysInQuotes",s=>s?.replace(/^\s{0,100}(\w+):/gm,"Q_HLD$1Q_HLD:")],["fullLineCommentsRemoved",s=>s?.replace(/^\s{0,999}\/\/.*\n/g,"")],["inlineCommentsRemoved",s=>s?.replace(/\/\/.*(?=\n)/g,"")],["trailingCommasRemoved",s=>s?.replace(/,(?=[\s\n]+[\}\]])/gs,"")],["double_escape",s=>s?.replace(/\\/g,"\\\\\\\\")],["escaped_inner_quotes",s=>s?.replace(/(['`\"])(.*)(\".*\")(.*)(['`\"])/g,(i,a,c,l,m,g)=>{let f=a==g?l.replace(/\"/g,'\\"'):l;return`${a}${c}${f}${m}${g}`})],["single_quotes_turned_double",s=>s?.replace(/[\'\`]/g,'"')],["keys_restored",s=>s?.replace(/Q_HLD/g,'"')],["trailing_semicolons_removed",s=>s?.replace(/(?<=\})[;\/\s\n\*]+$/,"")],["json_parse",s=>JSON.parse(s||"{}")]];try{let s=o.reduce((i,[a,c])=>{let l=c(i);return n[a]=l,l},r)}catch(s){console.error("Error parsing generator file:"),console.log("Original String:",e);for(let i of Object.keys(n))console.log(`${i}:
`,`${n[i]}`,`

`);throw console.error(s),s}return n.json_parse};var Ze=(e,t)=>({...on(e,t),...an(e)}),on=(e,t)=>{let r={};return e.replace(/(interface\s+)(\w+)(\s+extends\s+GenType\<\{\s+)([^\>]*?)(\s+\}\>\s*\{\})/g,(n,o,s,i,a)=>{u({level:9},"Found Type: ",{name:s,definition:a});let{ex:c,ts:l}=Ke(s,a,t);return(!!Object.keys(l).length||!!Object.keys(c).length)&&(r[s]={name:s,ts:l,ex:c}),""}),r},an=e=>{let t={};return e.replace(/(interface\s+)(InitialAppState)(\s+extends\s+AppState\s*\{\s*)([^\>]*?)(\s*\}\s+\w+)/g,(r,n,o,s,i)=>{u({level:9},"Found InitalState: ",{definition:i});let{ex:a,ts:c}=Ke("InitialAppState",i);return(!!Object.keys(c).length||!!Object.keys(a).length)&&(t.InitialAppState={name:"InitialAppState",ts:c,ex:a}),""}),t},Ke=(e,t,r={})=>{let n=[];t.replace(/\/\/.*|\/\*[\s\S]*?\*\//g,"").replace(/[;,]\s*(?=$)/gm,"").trim().replace(/^\s*\"?(\w+)\"?\s*:\s*(.*?)\s*$/gm,(i,a,c)=>(c=c.trim(),u({level:8},{key:a,value:c}),n.push({key:a,value:c}),""));let s=n.reduce((i,{key:a,value:c})=>Object.assign(i,{ex:{...i.ex,[a]:c},ts:{...i.ts,[a]:r[c]||c}}),{name:e,ts:{},ex:{}});return u({level:6},"Parsed Type: ",s),s},Ye=(e,t={})=>{let r=/type\s(\w+)\s=\s(\w+)\s&\s\{\s__brand\:/gs;return e.replace(r,(n,o,s)=>(t[o]=s,"")),t};var Xe=A(me()),Je=e=>{let t=cn(e),r=Qe(e),n=Ve(r),o=Qe(t),s=Ve(o),i=e[0];return{singleSnake:e,pluralSnake:t,singleLowerCamel:n,singleUpperCamel:r,pluralLowerCamel:s,pluralUpperCamel:o,singleChar:i}},cn=e=>{let t=e.split("_"),r=(0,Xe.default)(t.pop()||"");return[...t,r].join("_")},Qe=e=>e.split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(""),Ve=e=>e.replace(e[0],e[0].toLowerCase());var et=async e=>{let t=Ne.readFileSync(e,"utf8");u({level:3,color:"BLUE"},`
Reading genfile: ${e}`),u({level:5},"Analyzing types...");let r=Ye(t);u({level:5},"Reading generator...");let n=await He(t),o={...await Be(),...n,name:Je(n?.name)};u({level:3,color:"BLUE"},"Found app:"),await u({level:3,color:"GREEN"},`      ${o.AppNameCamel}`),await u({level:3,color:"BLUE"},`Generator: 
`,o);let s=o.generate;[["ControllerRoutes",s.http_controller?.routes],["ContextFunctions",s.context?.apiFunctions],["Requests",s.requests?.requestFunctions],["Reducers",s.stateSlice?.reducers],["Selectors",s.stateSlice?.selectors]].forEach(([c,l])=>u({level:3,color:"YELLOW"},`${c}:`,l)),await pe(2);let a=Ze(t,r);return await u({level:3,color:"BLUE"},`TypeDict: 
`,a),{generator:o,genTypes:a}};var rt=require("child_process"),nt=require("fs"),it=require("path");var tt={dir:"",command:"",options:{forceReturnOnPrompt:!0}};var st=async(e,t=null)=>{let{dir:r,command:n,options:o}={...tt,...e},{timeoutResolve:s,timeoutReject:i,forceReturnOnPrompt:a,resolveOnErrorCode:c}={...tt.options,...o};return je({command:n,dir:r},t),u({level:2,color:"YELLOW"},`Executing: ${n}`),u({level:4},`      in ${r}...`),new Promise((l,m)=>{let g=(0,it.resolve)(r);(0,nt.mkdirSync)(g,{recursive:!0});let[f,...d]=n.split(" "),_=(0,rt.spawn)(f,d,{cwd:g,shell:!0});_.stdout.on("data",$=>{u({level:5},$.toString()),o?.prompts&&o.prompts.forEach(([y,v])=>{if($.toString().includes(y)){let M=v+(a?`
`:"");_.stdin.write(M)}})}),_.stderr.on("error",$=>{console.error(`Could not run ${n}:
      ${$}`),m($||`Could not run ${n}`)}),_.on("close",$=>{!c&&$?(console.error(`Process exited with exit code ${$}:
       ${n}`),m(`Process exited with ${$}`)):l(r)}),s&&setTimeout(()=>l(r),s),i&&setTimeout(()=>m(new Error("Time out")),i)})};var ot=async({generate:e,WebDir:t},r)=>{let{schema:n,databaseTable:o}=e,s=(r.Schema||r.ImmutableGlobal)?.ex||{};u({level:9},"Gen schema source: ",s);let i=`mix phx.gen.schema ${n} ${o}`+Object.keys(s).map(a=>` ${a}:${s[a]}`).join("")+" --no-prompts";return u({level:2,color:"BLUE"},`Generating Phoenix Schema and Migrations for ${n}`),st({command:i,dir:t||"."},"gen_schema")};var ft=require("path");var R=require("fs"),U=require("path");var _e=require("child_process"),j=async e=>new Promise((t,r)=>{let n=e.endsWith(".tsx")||e.endsWith(".ts"),o=e.endsWith(".ex")||e.endsWith(".exs");n&&(0,_e.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),o&&(0,_e.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)});var b=async({filename:e,dir:t,content:r},n=null)=>{ce({filename:e,dir:t},n);let o=e.replace(/(.*)\.(\w+)$/,(a,c,l)=>`${c.replace(/\./g,"/")}.${l}`),s=(0,U.resolve)(t),i=(0,U.join)(t,o);return u({level:3},`Generating ${o} ...`),u({level:9},r),(0,R.mkdirSync)(s,{recursive:!0}),(0,R.existsSync)(i)&&(0,R.unlinkSync)(i),(0,R.writeFileSync)(i,r,"utf8"),await j(i),[i]};var h=(e,t)=>{let r=t(e);u({level:6},"Generating header for:",r);let n="";return r.split(/[ \n]+do/)[0].replace(/(defp{0,1})(.*)/s,(o,s,i)=>n=i),n=n.replace(/,{0,1}\s*(do){0,1}$/,"").trim(),u({level:6},"Generated header:",n),n};var ln=({pluralNameSnake:e},t)=>(p({pluralNameSnake:e},"comment_main"),`
  @doc """
    Create ${e} by id.

    ## Examples
    ${t}
    """
`),pn=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"comment_many"),`
create_${e}(attrs) when is_list attrs -> Creates ${t} from an array of attrs.

  ## Examples
      iex> create_${e}([%{field: value}, %{field: value}])
      {:ok, [%${r}{}, %${r}{}]}
`),dn=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
 create_${e}(attrs \\ %{}) -> Creates a ${e}.

  ## Examples
      iex> create_${e}(%{field: value})
      {:ok, %${t}{}}
      iex> create_${e}(%{field: bad_value})
      {:error, %Ecto.Changeset{}}
`),fe=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"create_many"),`
  def create_${e}(attrs) when is_list(attrs) do
    attrs
    |> Chunk.apply(fn attr_chunk ->
      changesets = change_${e}(attr_chunk)

      case Enum.split_with(changesets, & &1.valid?) do
        {valid, []} ->
          created = Chunk.prep(valid)
          {_, result} = Repo.insert_all(${r}, created, returning: true)
          {:ok, result, []}

        {[], invalid} ->
          {:error, [], invalid}

        {valid, invalid} ->
          created = Chunk.prep(valid)
          {_, result} = Repo.insert_all(${r}, created, returning: true)
          {:partial_success, result, invalid}
      end
    end)
    |> Chunk.flat_reduce()
  end
`),$e=({genName:e})=>(p({genName:e},"create_single"),`
  def create_${e}(${e}_params) when is_map(${e}_params) do
    changeset = change_${e}(${e}_params)
    if changeset.valid?, do: Repo.insert(changeset), else: {:error, changeset}
  end
`),un=[{id:"create_many",fn:fe,header:e=>h(e,fe)},{id:"create_single",fn:$e,header:e=>h(e,$e)}],mn={create_many:pn,create_single:dn},_n={create_many:fe,create_single:$e},at=(e,t)=>{let r=un.map(({id:c,fn:l,header:m})=>({id:c,def:l(t),header:m(t)}));u({level:7},"Gen Create APIS",r);let o=r.filter(({header:c})=>e.includes(c)).map(({id:c})=>c||""),s=o.map(c=>mn[c](t)).join(`
`),i=ln(t,s),a=o.map(c=>_n[c](t)).join(`
`);return{result:i+`
`+a,remaining_apis:e.filter(c=>!r.map(({header:l})=>l).includes(c))}};var fn=({pluralNameSnake:e},t)=>(p({pluralNameSnake:e},"comment_main"),`
  @doc """
    Delete ${e} by id.

    ## Examples
    ${t}
    """
`),$n=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_many"),`
  ## Examples
      iex> delete_${e}([${e}, ${e}])
      {:ok, [%${t}{}, %${t}{}]}
`),ct=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
  ## Examples
      iex> delete_${e}(${e})
      {:ok, %${t}{}}
      iex> delete_${e}(${e})
      {:error, %Ecto.Changeset{}}
`),ge=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"delete_many"),`
  def delete_${e}(${t}) when is_list(${t}) do
    result =
      ${t}
      |> Chunk.apply(fn ${e}_chunk ->
        ids =
          Enum.map(${e}_chunk, fn
            id when is_binary(id) -> id
            ${e} when is_map(${e}) -> MapUtil.get(${e}, :id)
          end)

        {count, _} =
          from(b in ${r}, where: b.id in ^ids)
          |> Repo.delete_all()

        case count do
          0 -> {:error, 0, length(ids)}
          count when count == length(ids) -> {:ok, count, 0}
          _ -> {:partial_success, count, length(ids) - count}
        end
      end)
      |> Chunk.flat_reduce()

    if elem(result, 0) == :error,
      do: {:error, :not_found},
      else: result
  end
`),he=({genName:e})=>(p({genName:e},"delete_single"),`
  def delete_${e}(${e}_params) when is_map(${e}_params), do:  MapUtil.get(${e}_params, :id) |> delete_${e}
`),ye=({genName:e})=>(p({genName:e},"delete_single_by_id"),`
    def delete_${e}(id) when is_binary(id), do: get_${e}!(id) |> Repo.delete!    
    `),gn=[{id:"delete_many",fn:ge,header:e=>h(e,ge)},{id:"delete_single",fn:he,header:e=>h(e,he)},{id:"delete_single_by_id",fn:ye,header:e=>h(e,ye)}],hn={delete_many:$n,delete_single:ct,delete_single_by_id:ct},yn={delete_many:ge,delete_single:he,delete_single_by_id:ye},lt=(e,t)=>{let r=gn.map(({id:a,fn:c,header:l})=>({id:a,def:c(t),header:l(t)})).filter(({header:a})=>e.includes(a)),n=r.map(({id:a})=>a||""),o=n.map(a=>hn[a](t)).join(`
`),s=fn(t,o),i=n.map(a=>yn[a](t)).join(`
`);return{result:s+`
`+i,remaining_apis:e.filter(a=>!r.map(({header:c})=>c).includes(a))}};var vn=({pluralNameSnake:e},t)=>(p({pluralNameSnake:e},"comment_main"),`
@doc """
    Retrieve ${e} by id.

    ## Examples
  ${t}
"""
  `),bn=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"comment_many"),`
    get_${e}!(ids) when is_list(ids) -> Gets specified ${t}.
    
    iex> get_${e}!([123, 456])
      [%${r}{}, %${r}{}]
      %${r}{}
`),pt=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
  get_${e}!(id) -> Gets a single ${e}.
      Raises \`Ecto.NoResultsError\` if the ${t} does not exist.

  ## Examples
      iex> get_${e}!(123)
      %${t}{}
      iex> get_${e}!(456)
      ** (Ecto.NoResultsError)    
`),ve=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"get_many"),`
  def get_${e}!(${t}) when is_list(${t}) do
    ids =
      Enum.map(${t}, fn
        id when is_binary(id) -> id
        ${e} when is_map(${e}) -> MapUtil.get(${e}, :id)
      end)

    from(b in ${r}, where: b.id in ^ids)
    |> Repo.all()
  end
`),be=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"get_single"),`
  def get_${e}!(${e}_params) when is_map(${e}_params) do
    id = MapUtil.get(${e}_params, :id) 
    Repo.get!(${t}, id)
  end
    `),xe=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"get_single_by_id"),`
  def get_${e}!(id) when is_binary(id), do: Repo.get!(${t}, id)    
`),xn=[{id:"get_many",fn:ve,header:e=>h(e,ve)},{id:"get_single",fn:be,header:e=>h(e,be)},{id:"get_single_by_id",fn:xe,header:e=>h(e,xe)}],In={get_many:bn,get_single:pt,get_single_by_id:pt},On={get_many:ve,get_single:be,get_single_by_id:xe},dt=(e,t)=>{let r=xn.map(({id:a,fn:c,header:l})=>({id:a,def:c(t),header:l(t)})).filter(({header:a})=>e.includes(a)),n=r.map(({id:a})=>a||""),o=n.map(a=>In[a](t)).join(`
`),s=vn(t,o),i=n.map(a=>On[a](t)).join(`
`);return{result:s+`
`+i,remaining_apis:e.filter(a=>!r.map(({header:c})=>c).includes(a))}};var Mn=({pluralNameSnake:e,genCamelName:t})=>(p({pluralNameSnake:e,genCamelName:t},"comment_standard"),`
@doc """
Returns the list of ${e}.

## Examples
    iex> list_${e}()
    [%${t}{}, ...]

"""
    `),Ie=({pluralNameSnake:e,genCamelName:t})=>(p({pluralNameSnake:e,genCamelName:t},"list_standard"),`
    def list_${e}(page_query \\\\ %{}), do: Paginate.apply(${t}, Repo, page_query)
    `),An=({pluralNameSnake:e,genCamelName:t})=>(p({pluralNameSnake:e,genCamelName:t},"comment_dynamic"),`
@doc """
Use a Dynamic Query to get a list of ${e} with specific values for any directly queryable fields.
"""
    `),Oe=({pluralNameSnake:e,genCamelName:t})=>(p({pluralNameSnake:e,genCamelName:t},"list_dynamic"),`
def list_${e}_by(entity_queries, page_queries \\\\ %{}) do
  with {:ok, query, entity_queries} <- DynamicQuery.by_schema(entity_queries, ${t}),
       {:ok, result, page_queries} <- Paginate.apply(query, Repo, page_queries) do
    {:ok, result, Map.put(entity_queries, :page, page_queries)}
  end
end
`),Rn=[{id:"list_standard",fn:Ie,header:e=>h(e,Ie)},{id:"list_dynamic",fn:Oe,header:e=>h(e,Oe)}],En={list_standard:Mn,list_dynamic:An},wn={list_standard:Ie,list_dynamic:Oe},ut=(e,t)=>{let r=Rn.map(({id:o,fn:s,header:i})=>({id:o,def:s(t),header:i(t)})).filter(({header:o})=>e.includes(o));return{result:r.map(({id:o})=>o||"").map(o=>En[o](t)+`
`+wn[o](t)).join(`
`),remaining_apis:e.filter(o=>!r.map(({header:s})=>s).includes(o))}};var Sn=({pluralNameSnake:e},t)=>(p({pluralNameSnake:e},"comment_main"),`
  @doc """
    Update ${e} records.

    ## Examples
    ${t}
    """
`),Tn=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"comment_many"),`
update_${e}(${t}) when is_list ${t} -> Updates ${t} with an array of tuples [{${e}, attrs}].

## Examples
    iex> update_${e}([{%{field: new_value}}, {%{field: new_value}}])
    {:ok, [%${r}{}, %${r}{}]}
`),Pn=({genName:e,genCamelName:t})=>(p({genName:e,genCamelName:t},"comment_single"),`
update_${e}(%${t}{} = ${e}, attrs) -> Updates a ${e}.

## Examples
    iex> update_${e}(${e}, %{field: new_value})
    {:ok, %${t}{}}
    iex> update_${e}(${e}, %{field: bad_value})
    {:error, %Ecto.Changeset{}}
`),Me=({genName:e,pluralNameSnake:t,genCamelName:r})=>(p({genName:e,pluralNameSnake:t,genCamelName:r},"update_many"),`
def update_${e}(${t}) when is_list(${t}) do
  ${t}
  |> Chunk.apply(fn ${e}_chunk ->
    multi =
      Multi.new()
      |> Multi.run(:initial_query, fn repo, _ ->
        requested_ids = Enum.map(${e}_chunk, &MapUtil.get(&1, :id))

        found_${t} = from(b in ${r}, where: b.id in ^requested_ids) |> repo.all()
        found_ids = Enum.map(found_${t}, & &1.id)
        unfound_ids = requested_ids -- found_ids

        {matched_attrs, unmatched_attrs} =
          Enum.split_with(${e}_chunk, fn attrs -> MapUtil.get(attrs, :id) not in unfound_ids end)

        changesets =
          Enum.zip(found_${t}, matched_attrs)
          |> Enum.map(fn {${e}, attrs} -> change_${e}(${e}, attrs) end)
          |> Enum.filter(& &1.valid?)

        {:ok, %{changesets: changesets, unmatched: unmatched_attrs}}
      end)
      |> Multi.run(:updates, fn repo, %{initial_query: query_res} ->
        %{
          changesets: changesets,
          unmatched: unmatched_attrs
        } = query_res

        {succeeded, failed_updates} =
          changesets
          |> Enum.map(&repo.update/1)
          |> Enum.reduce({[], []}, fn
            {:ok, ${e}}, {s, f} -> {[${e} | s], f}
            {_, changeset}, {s, f} -> [s, changeset | f]
          end)

        {:ok, %{succeeded: succeeded, failed: failed_updates ++ unmatched_attrs}}
      end)

    {:ok, %{updates: updates}} = Repo.transaction(multi)
    %{succeeded: succeeded, failed: failed} = updates

    case {succeeded, failed} do
      {succeeded, []} -> {:ok, succeeded, []}
      {[], failed} -> {:error, [], failed}
      {succeeded, failed} -> {:partial_success, succeeded, failed}
    end
  end)
  |> Chunk.flat_reduce()
end
`),Ae=({genName:e})=>(p({genName:e},"update_single"),`
def update_${e}(attrs) when is_map(attrs) do
  id = MapUtil.get(attrs, :id)

  if id == nil do
    create_${e}(attrs)
  else
    changeset =
      MapUtil.get(attrs, :id)
      |> get_${e}!()
      |> change_${e}(attrs)

    if changeset.valid?, do: Repo.update(changeset)
  end
end
`),Gn=[{id:"update_many",fn:Me,header:e=>h(e,Me)},{id:"update_single",fn:Ae,header:e=>h(e,Ae)}],qn={update_many:Tn,update_single:Pn},Cn={update_many:Me,update_single:Ae},mt=(e,t)=>{let r=Gn.map(({id:a,fn:c,header:l})=>({id:a,def:c(t),header:l(t)})).filter(({header:a})=>e.includes(a)),n=r.map(({id:a})=>a||""),o=n.map(a=>qn[a](t)).join(`
`),s=Sn(t,o),i=n.map(a=>Cn[a](t)).join(`
`);return{result:s+`
`+i,remaining_apis:e.filter(a=>!r.map(({header:c})=>c).includes(a))}};var Dn=({header:e})=>(p({header:e},"custom"),`
    def ${e} do
        # TODO: Provide function definition here
    end
`),_t={id:"custom",fn:Dn,header:({header:e})=>e};var Fn=(e,t)=>{u({level:7},"Requested Apis: ",e);let r=[at,lt,dt,ut,mt],{computed:n,remaining_apis:o}=r.reduce((i,a)=>{u({level:8},"APIFN REDUCER",i,a);let{computed:c,remaining_apis:l}=i;u({level:8},"APIFN COM",c),u({level:8},"APIFN REM",l),u({level:8},"APIFN RES",a(l,t));let{result:m,remaining_apis:g}=a(l,t);return{computed:c+m,remaining_apis:g}},{computed:"",remaining_apis:e});u({level:7},"Computed Apis: ",n);let s=o.map(i=>_t.fn({header:i})).join(`
`);return n+`
`+s},$t=async(e,t)=>{let{AppNameCamel:r,LibDir:n,generate:o,name:s}=e,{singleSnake:i,singleUpperCamel:a,pluralUpperCamel:c,pluralSnake:l}=s,{name:m,apiFunctions:g}=o.context,f=(0,ft.join)(n||"","/lib/"),d=m.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g,"$1_$2").replace(/^_/,"").toLowerCase(),$=`
defmodule ${r}.${m} do
  @moduledoc """
  The ${m} context.
  """

  import Ecto.Query, warn: false

  alias Ecto.Multi
  alias ${r}.Repo
  alias ${r}.Utils.DynamicQuery
  alias ${r}.Utils.Paginate
  alias ${r}.Utils.Chunk
  alias ${r}.Utils.MapUtil

  alias ${r}.${a}

  ${Fn(g,{camelName:m||"",genName:i,context:m||"",pluralNameSnake:l||"",pluralNameCamel:c||"",AppNameCamel:r||"",genCamelName:a||""})}

  @doc """
  change_${i}(${l}) when is_list ${l} -> Returns a list of \`%Ecto.Changeset{}\` for tracking ${i} changes

  ## Examples
      iex> change_${i}([{${i}1, attrs1}, {${i}2, attrs2}])
      %Ecto.Changeset{data: [%${a}{}, %${a}{}]}

  change_${i}(%${a}{} = ${i}, attrs \\\\ %{}) -> Returns \`%Ecto.Changeset{}\` for tracking ${i} changes.

  ## Examples
      iex> change_${i}(${i})
      %Ecto.Changeset{data: %${a}{}}

  """
  def change_${i}(attrs \\\\ %{})
  def change_${i}(attrs) when is_map(attrs), do: change_${i}(%${a}{}, attrs)

  def change_${i}(${l}) when is_list(${l}),
    do:
      Enum.map(${l}, fn
        {${i}, attr} -> change_${i}(${i}, attr)
        attr when is_map(attr) -> change_${i}(attr)
      end)

  def change_${i}(%${a}{} = ${i}, attrs), do: ${a}.changeset(${i}, attrs)
end
`;return b({dir:f,filename:`${d}.ex`,content:$},"gen_phx_context")};var qt=require("path");var gt=({camelName:e,genLowerSnakePlural:t,genLowerSnake:r,genUpperCamel:n})=>(p({camelName:e,genLowerSnakePlural:t,genLowerSnake:r,genUpperCamel:n},"create_many_test"),`
  test "create_${r}/1 creates multiple ${t}" do
    operation = ${e}.create_${r}([@valid_attrs, @valid_attrs])
    assert {:ok, [%${n}{}, %${n}{}], []} = operation
  end

  test "create_${r}/1 creates some ${t} with partial success" do
    operation = ${e}.create_${r}([@valid_attrs, @invalid_attrs])
    assert {:partial_success, [%${n}{}], [%Ecto.Changeset{}]} = operation
  end
`),ht=({camelName:e,genLowerSnake:t,genUpperCamel:r})=>(p({camelName:e,genLowerSnake:t,genUpperCamel:r},"create_single_test"),`
 test "create_${t}/1 creates a single ${t}" do
    operation = ${e}.create_${t}(@valid_attrs)
    assert {:ok, %${r}{}} = operation
  end
`),jn=[{id:"create_many_test",fn:gt,header:({genLowerSnake:e})=>`create_${e}(attrs) when is_list(attrs)`},{id:"create_single_test",fn:ht,header:({genLowerSnake:e})=>`create_${e}(${e}_params) when is_map(${e}_params)`}],Un={create_many_test:gt,create_single_test:ht},yt=(e,t)=>{let r=jn.map(({id:i,fn:a,header:c})=>({id:i,def:a(t),header:c(t)}));return u({level:7},"Gen Create API tests",r),{result:r.filter(({header:i})=>e.includes(i)).map(({id:i})=>i||"").map(i=>Un[i](t)).join(`
`),remaining_apis:e.filter(i=>!r.map(({header:a})=>a).includes(i))}};var vt=({genLowerSnake:e,camelName:t,genLowerSnakePlural:r,genUpperCamel:n})=>(p({genLowerSnake:e,camelName:t,genLowerSnakePlural:r,genUpperCamel:n},"get_many_test"),`
  test "get_${e}!/1 returns the ${r} with given ${r}" do
    {:ok, ${r}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs])
    valid_operation = ${t}.get_${e}!(${r})
    assert [%${n}{}, %${n}{}] = valid_operation
    retreived = ${t}.get_${e}!(${r} ++ [@fake_attrs])
    # should have one less ${e} than number of ids, since one id does not exist
    assert [%${n}{}, %${n}{}] = retreived
  end

  test "get_${e}!/1 returns the ${r} with given ids" do
    {:ok, ${r}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs])
    ${r} = ${r} |> Enum.map(&Map.get(&1, :id))
    valid_operation = ${t}.get_${e}!(${r})
    assert [%${n}{}, %${n}{}] = valid_operation
    retreived = ${t}.get_${e}!(${r} ++ [@fake_id])
    # should have one less ${e} than number of ids, since one id does not exist
    assert [%${n}{}, %${n}{}] = retreived
  end
`),bt=({genLowerSnake:e,camelName:t,genUpperCamel:r})=>(p({genLowerSnake:e,camelName:t,genUpperCamel:r},"get_single_test"),`
  test "get_${e}!/1 returns the ${e} with given ${e}" do
    {:ok, ${e}} = ${t}.create_${e}(@valid_attrs)
    valid_operation = ${t}.get_${e}!(${e})
    assert %${r}{} = valid_operation

    assert_raise Ecto.NoResultsError, fn ->
      ${t}.get_${e}!(@fake_attrs)
    end
  end
    `),xt=({genLowerSnake:e,camelName:t,genUpperCamel:r})=>(p({genLowerSnake:e,camelName:t,genUpperCamel:r},"get_single_by_id_test"),`
  test "get_${e}!/1 returns the ${e} with given id" do
    {:ok, ${e}} = ${t}.create_${e}(@valid_attrs)
    valid_operation = ${t}.get_${e}!(${e}.id)
    assert %${r}{} = valid_operation

    assert_raise Ecto.NoResultsError, fn ->
      ${t}.get_${e}!(@fake_id)
    end
  end  
`),Wn=[{id:"get_many_test",fn:vt,header:({genLowerSnake:e,genLowerSnakePlural:t})=>`get_${e}!(${t}) when is_list(${t})`},{id:"get_single_test",fn:bt,header:({genLowerSnake:e})=>`get_${e}!(${e}_params) when is_map(${e}_params)`},{id:"get_single_by_id_test",fn:xt,header:({genLowerSnake:e})=>`get_${e}!(id) when is_binary(id)`}],Ln={get_many_test:vt,get_single_test:bt,get_single_by_id_test:xt},It=(e,t)=>{let r=Wn.map(({id:s,fn:i,header:a})=>({id:s,def:i(t),header:a(t)})).filter(({header:s})=>e.includes(s));return{result:r.map(({id:s})=>s||"").map(s=>Ln[s](t)).join(`
`),remaining_apis:e.filter(s=>!r.map(({header:i})=>i).includes(s))}};var Re=({camelName:e,genLowerSnakePlural:t,genLowerSnake:r})=>(p({camelName:e,genLowerSnakePlural:t,genLowerSnake:r},"delete_many_test"),`
  test "delete_${r}/1 deletes multiple ${t}" do
    {:ok, ${t}, []} = ${e}.create_${r}([@valid_attrs, @valid_attrs])
    operation = ${e}.delete_${r}(${t})
    assert {:ok, 2, 0} = operation
  end
`),Ot=({camelName:e,genLowerSnake:t})=>(p({camelName:e,genLowerSnake:t},"delete_single_test"),`
  test "delete_${t}/1 deletes a single ${t}" do
    {:ok, ${t}} = ${e}.create_${t}(@valid_attrs)
    ${e}.delete_${t}(${t})

    assert_raise Ecto.NoResultsError, fn ->
      ${e}.get_${t}!(${t}.id)
    end
  end
`),Mt=({camelName:e,genLowerSnake:t})=>(p({camelName:e,genLowerSnake:t},"delete_single_by_id_test"),`
  test "delete_${t}/1 deletes a single ${t} by id" do
    {:ok, ${t}} = ${e}.create_${t}(@valid_id)
    ${e}.delete_${t}(${t})

    assert_raise Ecto.NoResultsError, fn ->
      ${e}.get_${t}!(${t}.id)
    end
  end
    `),kn=[{id:"delete_many_test",fn:Re,header:e=>h(e,Re)},{id:"delete_single_test",fn:Ot,header:({genLowerSnake:e,genLowerSnakePlural:t})=>`delete_${e}(${t}) when is_list(${t})`},{id:"delete_single_by_id_test",fn:Mt,header:({genLowerSnake:e})=>`delete_${e}(${e}_params) when is_map(${e}_params)`}],zn={delete_many_test:Re,delete_single_test:Ot,delete_single_by_id_test:Mt},At=(e,t)=>{let r=kn.map(({id:s,fn:i,header:a})=>({id:s,def:i(t),header:a(t)})).filter(({header:s})=>e.includes(s));return{result:r.map(({id:s})=>s||"").map(s=>zn[s](t)).join(`
`),remaining_apis:e.filter(s=>!r.map(({header:i})=>i).includes(s))}};var Rt=({genLowerSnakePlural:e,camelName:t,genUpperCamel:r})=>(p({genLowerSnakePlural:e,camelName:t,genUpperCamel:r},"list_standard_test"),`
  test "list_${e}/0 returns all ${e}" do
    {:ok, _${e}} = ${t}.create_${e}(@valid_attrs)
    operation = ${t}.list_${e}()

    assert {:ok, [%${r}{}],
            %{page_size: 100, page_number: 1, total_entries: 1, total_pages: 1}} = operation
  end
    `),Et=({genLowerSnakePlural:e,camelName:t,genUpperCamel:r})=>(p({genLowerSnakePlural:e,camelName:t,genUpperCamel:r},"list_dynamic_test"),`
  test "list_${e}_by/2 returns all ${e} by field" do
    {:ok, _${e}} = ${t}.create_${e}(@valid_attrs)
    operation = ${t}.list_${e}_by(%{"example1" => "1"}, %{})

    assert {:ok, [%${r}{}],
            %{
              "example1" => "= 1",
              page: %{page_size: 100, page_number: 1, total_entries: 1, total_pages: 1}
            }} = operation
  end

  test "list_${e}_by/2 returns all ${e} by field with pagination" do
    {:ok, _${e}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs, @valid_attrs])
    operation = ${t}.list_${e}_by(%{"example1" => "1"}, %{page_size: 2})
    {:ok, ${e}, page} = operation
    assert [%${r}{}, %${r}{}] = ${e}

    assert %{
             :page => %{page_size: 2, page_number: 1, total_entries: 3, total_pages: 2},
             "example1" => "= 1"
           } = page
  end
`),Bn=[{id:"list_standard_test",fn:Rt,header:({genLowerSnakePlural:e})=>`list_${e}(page_query \\\\ %{})`},{id:"list_dynamic_test",fn:Et,header:({genLowerSnakePlural:e})=>`list_${e}_by(entity_queries, page_queries \\\\ %{})`}],Hn={list_standard_test:Rt,list_dynamic_test:Et},wt=(e,t)=>{let r=Bn.map(({id:o,fn:s,header:i})=>({id:o,def:s(t),header:i(t)})).filter(({header:o})=>e.includes(o));return{result:r.map(({id:o})=>o||"").map(o=>Hn[o](t)).join(`
`),remaining_apis:e.filter(o=>!r.map(({header:s})=>s).includes(o))}};var St=({genLowerSnakePlural:e,camelName:t,genUpperCamel:r})=>(p({genLowerSnakePlural:e,camelName:t,genUpperCamel:r},"update_many_test"),`
  test "update_${e}/1 updates multiple ${e}" do
    {:ok, ${e}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs])
    ${e} = ${e} |> Enum.map(&Map.merge(@update_attrs, %{id: &1.id}))
    operation = ${t}.update_${e}(${e})
    assert {:ok, [%${r}{}, %${r}{}], []} = operation
    partial_operation = ${t}.update_${e}(${e} ++ [@fake_attrs])
    assert {:partial_success, [%${r}{}, %${r}{}], [_failed_attrs]} = partial_operation
  end
`),Tt=({genLowerSnakePlural:e,camelName:t})=>(p({genLowerSnakePlural:e,camelName:t},"update_single_test"),`
  test "update_${e}/1 updates a single ${e}" do
    {:ok, %{id: id}} = ${t}.create_${e}(@valid_attrs)
    operation = ${t}.update_${e}(Map.merge(@update_attrs, %{id: id}))
    assert {:ok, result_${e}} = operation
    assert new_${e} = ${t}.get_${e}!(result_${e})

    assert %{
             id: res_id,
             example1: example1,
             example2: example2,
             example3: example3,
             updated_at: _,
             inserted_at: _
           } = new_${e}

    assert [example1, example2, example3, res_id] == [
             @update_attrs.example1,
             @update_attrs.example2,
             @update_attrs.example3,
             id
           ]
  end
`),Zn=[{id:"update_many_test",fn:St,header:({genLowerSnake:e,genLowerSnakePlural:t})=>`update_${e}(${t}) when is_list(${t})`},{id:"update_single_test",fn:Tt,header:({genLowerSnake:e})=>`update_${e}(attrs) when is_map(attrs)`}],Kn={update_many_test:St,update_single_test:Tt},Pt=(e,t)=>{let r=Zn.map(({id:s,fn:i,header:a})=>({id:s,def:i(t),header:a(t)})).filter(({header:s})=>e.includes(s));return{result:r.map(({id:s})=>s||"").map(s=>Kn[s](t)).join(`
`),remaining_apis:e.filter(s=>!r.map(({header:i})=>i).includes(s))}};var Yn=({header:e})=>(p({header:e},"custom"),`
    test "${e}" do
        # TODO: Provide test definition here
    end
`),Gt={id:"custom",fn:Yn,header:({header:e})=>e};var Qn=(e,t)=>{u({level:7},"Requested Apis: ",e);let r=[yt,It,At,wt,Pt],{computed:n,remaining_apis:o}=r.reduce((i,a)=>{u({level:8},"APIFN REDUCER",i,a);let{computed:c,remaining_apis:l}=i;u({level:8},"APIFN COM",c),u({level:8},"APIFN REM",l),u({level:8},"APIFN RES",a(l,t));let{result:m,remaining_apis:g}=a(l,t);return{computed:c+m,remaining_apis:g}},{computed:"",remaining_apis:e});u({level:7},"Computed Apis: ",n);let s=o.map(i=>Gt.fn({header:i})).join(`
`);return n+`
`+s},Ct=async(e,t)=>{let{AppNameCamel:r,LibDir:n,generate:o,name:s}=e,{singleSnake:i,singleUpperCamel:a,pluralUpperCamel:c,pluralSnake:l}=s,{name:m,apiFunctions:g}=o.context,f=(0,qt.join)(n||"","/test/"),d=m.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g,"$1_$2").replace(/^_/,"").toLowerCase(),$=`
  defmodule ${r}.${m}Test do
  use ${r}.DataCase

  alias ${r}.${a}
  alias ${r}.${m}

  @valid_attrs %{example1: 1, example2: "1", example3: 1.0}
  @update_attrs %{example1: 2, example2: "2", example3: 2.0}
  @invalid_attrs %{example1: "1", example2: "1"}
  @fake_id "601d74e4-a8d3-4b6e-8365-eddb4c893327"
  @fake_attrs Map.put(@valid_attrs, :id, @fake_id)

${Qn(g,{camelName:m,genLowerSnake:i||"",genUpperCamel:a||"",genLowerSnakePlural:l||""})}

end
`;return b({dir:f,filename:`${d}_test.exs`,content:$},"gen_phx_contex_test")};var Ft=A(require("path"));var Ee=A(require("fs"));var W=async({file:e,injections:t},r=null)=>(u({level:3},`Injecting into ${e}....`),new Promise(async(n,o)=>{We(e,r);let i=Ee.default.readFileSync(e,"utf8");t.forEach(([a,c,l])=>{switch(u({level:7},`Injecting ${l} into ${e}`),u({level:9},"File: ",i),a){case"REPLACE":let m=i.replace(c,l);if(m==i||m==""){Dt(c,e,o);return}else u({level:8},`Found ${c} in ${e}`),i=m;break;default:i=Vn(i,e,[a,c,l])||Dt(c,e,o)}}),i.length?(Ee.default.writeFileSync(e,i,"utf8"),await j(e),n([e])):o(new Error(`Insertion failed for ${e}`))})),Dt=(e,t,r)=>(console.error(`${e} not found in the ${t} file.`),r(new Error(`Insertion failed for ${t}`)),""),Vn=(e,t,[r,n,o])=>{let s=e.match(n);if(!s)return null;let i=s.index;if(u({level:8},`Found ${n} at ${i} in ${t}`),r==="AFTER")i+=s[0].length;else if(r!="BEFORE")return null;return e.slice(0,i)+o+e.slice(i)};var jt=async e=>{let{WebDir:t,generate:r,AppNameSnake:n,name:o}=e||{},{singleSnake:s}=o||{},{http_controller:i}=r||{},{name:a}=i||{},c=Ft.default.join(t||".",`lib/${n}_web/router.ex`),l=[["AFTER",/pipe_through[\s\(]{1,3}:api\){0,1}/,`
resources "/${s}", ${a}
put "/${s}", ${a}, :update
delete "/${s}", ${a}, :delete`]];return W({file:c,injections:l},"inject_router")};var rr=require("path");var Ut=({pluralNameSnake:e,context:t,genName:r})=>(p({pluralNameSnake:e,context:t,genName:r},"show_list"),`
    def show(conn, ${r}_list) when is_list(${r}_list) do
      ${e} = ${t}.get_${r}!(${r}_list)
      render(conn, :show, ${e}: ${e})
    end
  `),Wt=({genName:e,context:t})=>(p({genName:e,context:t},"show"),`
    def show(conn, %{"id" => id}) do
        ${e} = ${t}.get_${e}!(id)
        render(conn, :show, ${e}: ${e})
    end
`),Lt=[{id:"show_list",fn:Ut,header:e=>h(e,Ut)},{id:"show",fn:Wt,header:e=>h(e,Wt)}];var kt=({pluralNameSnake:e,context:t})=>(p({pluralNameSnake:e,context:t},"index_standard"),`
    defp routed_index(conn, entity_queries, page_queries) when entity_queries == %{} do
      with {:ok, ${e}, query_data} <- ${t}.list_${e}(page_queries) do
        render(conn, :show, ${e}: ${e}, query_data: query_data)
      end
    end
  `),zt=({pluralNameSnake:e,context:t})=>(p({pluralNameSnake:e,context:t},"index_dynamic"),`
    defp routed_index(conn, entity_queries, page_queries) when entity_queries != %{} do
      with {:ok, ${e}, query_data} <- ${t}.list_${e}_by(entity_queries, page_queries) do
        render(conn, :show, ${e}: ${e}, query_data: query_data)
      end
    end
  `),Bt=[{id:"index_standard",fn:kt,header:e=>h(e,kt)},{id:"index_dynamic",fn:zt,header:e=>h(e,zt)}];var Ht=({genName:e,context:t,pluralNameSnake:r,AppNameCamel:n})=>(p({genName:e,context:t,pluralNameSnake:r,AppNameCamel:n},"create_list"),`
    def create(conn, ${e}_list) when is_list(${e}_list) do
      with {:ok, ${r}, []} <- ${t}.create_${e}(${e}_list) do
        conn
        |> put_status(:created)
        |> put_resp_header("location", ~p"/api/${e}")
        |> render(:show, ${r}: ${r})
      else
        {:partial_success, created_${r}, failed_${r}} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeeded: created_${r}, failed: failed_${r}, query_data: ${e}_list)
  
        error ->
          ${n}Web.FallbackController.call(conn, error)
      end
    end
    `),Zt=({genName:e,camelUpperName:t,context:r,pluralNameSnake:n})=>(p({genName:e,camelUpperName:t,context:r,pluralNameSnake:n},"create"),`
    def create(conn, ${e}_params) do
      with {:ok, %${t}{} = ${e}} <- ${e}_params |> MapUtil.str_to_atom() |> ${r}.create_${e}() do
        conn
        |> put_status(:created)
        |> put_resp_header("location", ~p"/api/${e}/#{${e}.id}")
        |> render(:show, ${e}: ${e})
      end
    end
    `),Kt=[{id:"create_list",fn:Ht,header:e=>h(e,Ht)},{id:"create",fn:Zt,header:e=>h(e,Zt)}];var Yt=({pluralNameSnake:e,context:t,genName:r,AppNameCamel:n})=>(p({pluralNameSnake:e,context:t,genName:r,AppNameCamel:n},"update_list"),`
    def update(conn, ${r}_list) when is_list(${r}_list) do
      with {:ok, ${e}, []} <- ${t}.update_${r}(${r}_list) do
        render(conn, :show, ${e}: ${e})
      else
        {:partial_success, updated_${e}, failed_${e}} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeeded: updated_${e}, failed: failed_${e}, query_data: ${r}_list)
  
        error ->
          ${n}Web.FallbackController.call(conn, error)
      end
    end
    `),Qt=({genName:e,context:t,camelName:r})=>(p({genName:e,context:t,camelName:r},"update"),`
    def update(conn, ${e}_params) when is_map(${e}_params) do
      with {:ok, %${r}{} = ${e}} <- ${t}.update_${e}(${e}_params) do
        render(conn, :show, ${e}: ${e})
      end
    end
  `),Vt=[{id:"update_list",fn:Yt,header:e=>h(e,Yt)},{id:"update",fn:Qt,header:e=>h(e,Qt)}];var Xt=({context:e,genName:t,AppNameCamel:r})=>(p({context:e,genName:t,AppNameCamel:r},"delete_list"),`
    def delete(conn, ${t}_list) when is_list(${t}_list) do
      with {:ok, count, _} <- ${e}.delete_${t}(${t}_list) do
        render(conn, :show, count: count)
      else
        {:partial_success, success_count, fail_count} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeess_count: success_count, fail_count: fail_count, query_data: ${t}_list)
  
        e ->
          ${r}Web.FallbackController.call(conn, e)
      end
    end
  `),Jt=({genName:e,context:t,camelUpperName:r})=>`
    def delete(conn, %{"id" => id}) do
      with %${r}{} = ${e} <- ${t}.delete_${e}(id) do
        conn
        |> put_status(:ok)
        |> render(:show, ${e}: ${e})
      end
    end 
  `,Nt=[{id:"delete_list",fn:Xt,header:e=>h(e,Xt)},{id:"delete",fn:Jt,header:e=>h(e,Jt)}];var Jn=({header:e})=>(p({header:e},"custom"),`
    def ${e} do
        # TODO: Provide function definition here
    end
`),er={id:"custom",fn:Jn,header:({header:e})=>e};var tr=require("path");var we=async(e,t)=>{let{WebDir:r,AppNameCamel:n,AppNameSnake:o,generate:s,name:i}=e,{http_controller:a}=s,{singleUpperCamel:c,pluralSnake:l,singleSnake:m}=i,{ImmutableGlobal:g,Schema:f}=t,d=(0,tr.join)(r||".",`lib/${o}_web/controllers`),_=(g||f)?.ex,$=Object.keys(_||{}).map(v=>`${v}: Map.get(${m}, :${v})`).join(`,
      `),y=`
defmodule ${n}Web.${c}JSON do
  alias ${n}Web.FallbackController

  @doc """
  Renders a ${m} or list of ${l}.

  ## Examples
      iex> render(conn, :show, ${l}: ${l})
      {:ok, %{data: [%${c}{}]}

      iex> render(conn, :show, ${m}: ${m})
      {:ok, %{data: %${c}{}}}
  """
  def show(%{${l}: ${l}, query_data: q}) when is_list(${l}) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.merge(%{data: transform(${l}), count: length(${l})})
  end

  def show(%{${m}: ${m}, query_data: q}) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.put(:data, transform(${m}))
  end

  def show(%{count: c}), do: %{success_count: c, fail_count: 0}

  def show(params), do: Map.merge(%{query_data: %{}}, params) |> show

  @doc """
  Renders ${l} from batch operations

  ## Examples
      iex> render(conn, :show_partial, succeeded: ${m}_maps, failed: ${m}_changesets)
      {:partial_success, [%${c}{}], [%Changeset{}]}
  """
  def show_partial(params \\\\ %{query_data: %{}, succeeded: [], failed: []})

  def show_partial(%{succeeded: succeeded_${l}, failed: failed_changesets, query_data: q})
      when is_list(succeeded_${l}) and is_list(failed_changesets) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.merge(%{
      success_count: length(succeeded_${l}),
      fail_count: length(failed_changesets),
      data: transform(succeeded_${l}),
      failed: FallbackController.error_transform(failed_changesets)
    })
  end

  def show_partial(%{success_count: s_count, fail_count: f_count}), do: %{success_count: s_count, failed_count: f_count}

  defp transform(${l}) when is_list(${l}), do: Enum.map(${l}, &transform/1)

  defp transform(${m}) when is_map(${m}) do
    %{
      id: Map.get(${m}, :id),
      ${$}
    }
  end
end
`;return a?b({dir:d,filename:`${m}_json.ex`,content:y},"gen_json_handler"):null};var Nn=[Lt,Bt,Kt,Vt,Nt].flat(),ei=(e,t,r)=>{u({level:7},"Requested Routes: ",e);let n=t.reduce((o,s)=>({...o,[s.header(r)]:s.fn(r)}),{});return u({level:7},"Route Data Computed: ",n),e.map(o=>(u({level:7},"Header: ",o),n[o]||er.fn({header:o}))).join(`

`)},nr=async(e,t)=>{let{AppNameSnake:r,AppNameCamel:n,WebDir:o,generate:s,name:i}=e,{singleSnake:a,singleUpperCamel:c,pluralSnake:l}=i,{name:m,routes:g}=s.http_controller,{name:f}=s.context,d=(0,rr.join)(o||"",`/lib/${r}_web/controllers/`),_=m.replace(/([a-z0-9])([A-Z])/g,"$1_$2").toLowerCase(),$={camelName:c||"",genName:a,context:f,pluralNameSnake:l||"",AppNameCamel:n||"",camelUpperName:c||""};u({level:7},"Generating controller: ",m,_,$);let y=`
defmodule ${n}Web.${m} do
use ${n}Web, :controller
plug ${n}.Plugs.ListAsJSON
plug ${n}.Plugs.ValidateBinaryId, fallback: ${n}Web.FallbackController

alias ${n}.Utils.Paginate
alias ${n}.Utils.MapUtil

alias ${n}.${f}
alias ${n}.${c}

action_fallback ${n}Web.FallbackController

def index(conn, params) do
    {entity_queries, page_queries} = Paginate.split_page_opts(params)
    routed_index(conn, entity_queries, page_queries)
end

${ei(g,Nn,$)}

end
`;return b({dir:d,filename:`${_}.ex`,content:y},"gen_phx_controller")};var ir=async(e,t)=>{let r=e.generate,n=[];return r.schema&&n.push(await ot(e,t)),r.context&&(n.push(await $t(e,t)),r.test&&n.push(await Ct(e,t))),r.http_controller&&n.push(Promise.all([nr(e,t),we(e,t),jt(e)])),n};var Sr=require("path"),S=A(me());var Er=A(Rr()),Ha=new Er.LoremIpsum,zi={number:"Math.floor(Math.random() * 100)",string:"Lorem.generateWords(3)",boolean:"Math.random() > 0.5",object:"({ lorem: Lorem.generateWords(1), ipsum: Lorem.generateWords(2) })",array:'Lorem.generateWords(3).split(" ")',any:"Lorem.generateSentences(1)"};var wr=e=>zi[e];var Tr=async(e,t)=>{u({level:7},"GEN ENTITY STORE",e),u({level:7},"TYPE DICT",t);let{name:r,generate:n,LibDir:o}=e,{singleUpperCamel:s}=r,{tstype:i,appstate:a,factory:c}=n,l=n.stateSlice?.name,m=(0,Sr.join)(o,"lib/typescript/state/"),g=(t.TsType||t.ImmutableGlobal).ts,f=(t.AppState||t.ImmutableGlobal).ts,d=t.InitialAppState?.ts||{},_=`id: number;
`+Object.keys(g).map(O=>`${O}: ${g[O]}`).join(`;
`),$=`type ${i} = {${_}}`,y=Object.keys(f).map(O=>`${O}: ${f[O]}`).join(`;
`),v=`interface ${a} {${y}}`,M=Object.keys(g).map(O=>`${O}: ${wr(g[O])}`).join(`,
`),F=`const ${i}Factory = (params: object): ${i} => {
    const ${s} = {${M}};
    return Object.assign(${s}, params) as ${i};
}`,te=Object.keys(d).map(O=>`${O}: ${d[O]}`).join(`,
`),re=`const initial${a}State: ${s}StoreState = {${te}}`,q=`
const ${l} = createSlice({
      name: "${s}",
      initialState: initial${a}State,
      reducers: {
        set${i}(state: ${a}, action: PayloadAction<${i}>) {
          state.${i?.toLowerCase()} = action.payload;
        },
        set${(0,S.default)(i)}(state: ${a}, action: PayloadAction<${i}[]>) {
          state.${(0,S.default)(i)?.toLowerCase()} = action.payload;
        },
      },
    });
const ${s}Reducer = ${l}.reducer;

const select${i} = (state: GenericAppState) => state.${`${s}Store`}.${i?.toLowerCase()};
const select${(0,S.default)(i)} = (state: GenericAppState) => state.${`${s}Store`}.${(0,S.default)(i)?.toLowerCase()};
`,Yr=[a?`initial${a}State`:null,c?`${i}Factory`:null,l?`${s}Reducer`:null,l?`select${i}`:null,l?`select${(0,S.default)(i)}`:null].filter(O=>!!O).join(", "),Qr=[l?`const { set${i}, set${(0,S.default)(i)} } = ${l}.actions
export { set${i}, set${(0,S.default)(i)} }`:null,i||a?`export type { ${[i,a,"GenericAppState"].join(", ")} }`:null,`export { ${Yr} }`,l?`export default ${l}`:null].filter(O=>!!O).join(`
`),Vr=`
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import Lorem from "../utils/lorem";

${i?`
${$}
`:""}
${a?`
${v}
`:""}
${a?`
${re}
`:""}
${c?`
${F}
`:""}
${l?`
${q}
`:""}

interface GenericAppState {
    ${s}Store: ${s}StoreState;
    [key: string]: any;
}

${Qr}
`;return b({dir:m,filename:`${s}.tsx`,content:Vr},"gen_entity_store")};var Pr=A(require("path"));var Gr=async e=>{let{name:t,generate:r,UiDir:n}=e,{singleUpperCamel:o}=t,{appstate:s}=r,i=Pr.default.join(n,"src/store/index.tsx"),a=[["AFTER",/reducer\:\scombineReducers\(\{/,`
${o}Store: ${o}Reducer,`],["AFTER",/import\s.*/,`
import { ${o}Reducer, ${s} } from '@state/${o}';`],["AFTER",/type\s+[A-Za-z0-9_]+State\s+\=\s+\{/,`
  ${o}Store: ${s};`]];return W({file:i,injections:a},"addReducerToGlobal")};var qr=require("path");var Cr=async(e,t)=>{let{name:r,generate:n,AppNameCaps:o,LibDir:s}=e,{singleUpperCamel:i,singleLowerCamel:a,pluralUpperCamel:c,singleSnake:l}=r,{requests:m}=n,g=(0,qr.join)(s||"","lib/typescript/requests/"),f=`
import { Dispatch } from "redux";
import { Request } from "./index";
import { ${i}, set${i}, set${c} } from "../state/${i}";

const request${i} = (id: string, dispatch: Dispatch) => 
  Request.API({
    name: "fetch${i}",
    api_url_key: "${o}_API_URL",
    route: \`${l}/\${id}\`,
    callback: (res: any) => dispatch(set${i}(res.data))
  }, dispatch);


const request${c} = (dispatch: Dispatch) => 
  Request.API({
    name: "fetch${c}",
    api_url_key: "${o}_API_URL",
    route: \`${l}\`,
    callback: (res: any) => dispatch(set${c}(res.data)),
  }, dispatch);


const update${i} = (${a}: ${i}, dispatch: Dispatch) => 
  Request.API({
    name: "update${i}",
    api_url_key: "${o}_API_URL",
    route: "${l}",
    options: {
      method: "PUT",
      body: JSON.stringify(${a}),
    },
    callback: (_data: any) => null,
  }, dispatch);


const delete${i} = (id: string, dispatch: Dispatch) => 
  Request.API({
    name: "delete${i}",
    api_url_key: "${o}_API_URL",
    route: \`${l}/\${id}\`,
    options: {
      method: "DELETE",
    },
  }, dispatch);


export { request${i}, request${c}, update${i}, delete${i} };
`;return m?b({dir:g,filename:`${i}.tsx`,content:f},"gen_entity_requests"):null};var Dr=require("path");var Fr=(i=>(i.string="text",i.number="number",i.boolean="checkbox",i.date="date",i.email="email",i.password="password",i))(Fr||{}),Bi=(e,t,r)=>` 
  <input
    type="${Fr[t]||"text"}"
    name="${e}"
    value={${r}?.${e} ?? ""}
    onChange={onChange}
  />
  `,jr=async(e,t)=>{let{name:r,LibDir:n}=e,{singleUpperCamel:o,singleLowerCamel:s}=r||{},a=(t.TsType||t.ImmutableGlobal)?.ts||{},c=(0,Dr.join)(n||"",`lib/typescript/components/${s}/`),l=Object.keys(a).map(g=>Bi(g,a[g],s)).join(`
`),m=`
  import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { Dispatch } from "redux";
import { ${o} as ${o}T } from "../../state/${o}";

interface CreateProps {
  onSubmit?: (
    e: React.FormEvent<HTMLFormElement>,
    f: ${o}T | null,
    d: Dispatch
  ) => void;
}

export const ${o}Form = ({ onSubmit }: CreateProps) => {
  const dispatch = useDispatch();
  const [${s}, set${o}] = useState<${o}T | null>(null);

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    set${o}((prev${o}) => {
      return { ...prev${o}, [name]: value } as ${o}T;
    });
  };

  return (
    <form
      onSubmit={(e: React.FormEvent<HTMLFormElement>) =>
        onSubmit && onSubmit(e, ${s}, dispatch)
      }
    >

    ${l}
      
      <button type="submit">Submit</button>
    </form>
  );
};

export const Create${o} = ({ onSubmit }: CreateProps) => (
  <div>
    <h4>Create a ${o}</h4>
    <${o}Form onSubmit={onSubmit} />
  </div>
);
  `;return b({dir:c,filename:"create.tsx",content:m},"gen_create_demo_component")};var Ur=require("path");var Wr=async(e,t)=>{let{name:r,LibDir:n}=e,{singleUpperCamel:o,singleLowerCamel:s,pluralLowerCamel:i,pluralUpperCamel:a}=r||{},c=(0,Ur.join)(n||"",`lib/typescript/components/${s}/`),l=`
import React from "react";
import { useSelector } from "react-redux";
import { Dispatch } from "redux";
import { pipe } from "mincurrypipe";
import { ${o} as ${o}T, select${o}, select${a}, setFrog } from "../../state/${o}";
import { request${a}, update${o} } from "../../requests/${s}";
import { Create${o} } from "./create";
import { ${a} } from "./list";
import { ${o} } from "./show";

export const prevtDef = (e: React.FormEvent<HTMLFormElement>) =>
  e.preventDefault();

export const ${o}Demo = () => {
  const ${s} = useSelector(select${o});
  const ${i} = useSelector(select${a});

  return (
    <div>
      <h1>${o} Demo</h1>
      <p>This is a demo of ${s} components.</p>
      <h2>My ${o}</h2>
      <${o} ${s}={${s}} />
      <h2>New ${o}</h2>
      <CreateFrog
        onSubmit={(
          e: React.FormEvent<HTMLFormElement>,
          f: FrogT | null,
          d: Dispatch
        ) =>
          pipe(
            prevtDef(e),
            () => f && updateFrog(f, d),
            setFrog,
            d,
            () => requestFrogs(d)
          )
        }
      />
      <h2>All ${a}</h2>
      <${a} ${i}={${i}} effect={request${a}} />
    </div>
  );
};
  `;return b({dir:c,filename:"index.tsx",content:l},"gen_full_demo_component")};var Lr=require("path");var kr=async(e,t)=>{let{name:r,LibDir:n}=e,{singleUpperCamel:o,singleLowerCamel:s,pluralLowerCamel:i,pluralUpperCamel:a}=r||{},c=(0,Lr.join)(n||"",`lib/typescript/components/${s}/`),l=`
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { Dispatch } from "redux";
import {
  ${o} as ${o}T,
} from "../../state/${o}";
import { ${o} } from "./show";

interface ${o}Props {
  ${i}?: ${o}T[];
  effect?: (d: Dispatch) => void;
}

export const ${a}Render = ({ ${i} }: ${o}Props) => (
  <div>
    <ul>
      {${i}?.map((${s}) => (
        <${o} ${s}={${s}} key={\`${s}-\${${s}?.id}\`} />
      ))}
    </ul>
  </div>
);

export const ${a} = ({ ${i}, effect }: ${o}Props) => {
  const dispatch = useDispatch(); // Generate a redux dispatch for this component

  useEffect(() => {
    // By passing the effect function through props, we can defer the decision whether this function requests data
    //      or merely renders existing data to the parent component
    if (effect) effect(dispatch as Dispatch);
  }, [dispatch]); // This will fire the effect once on component mount and again if dispatch changes

  return (
    <div>
      <h3>${a}</h3>
      <${a}Render ${i}={${i}} />
    </div>
  );
};
  `;return b({dir:c,filename:"list.tsx",content:l},"gen_list_demo_component")};var zr=require("path");var Hi=(e,t)=>`\${${t}?.${e}}`,Br=async(e,t)=>{let{name:r,LibDir:n}=e,{singleUpperCamel:o,singleLowerCamel:s}=r||{},a=(t.TsType||t.ImmutableGlobal)?.ts||{},c=(0,zr.join)(n||"",`lib/typescript/components/${s}/`),l=Object.keys(a||{}).map(g=>Hi(g,s)).join(" "),m=`
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { Dispatch } from "redux";
import { ${o} as ${o}T } from "../../state/${o}";

interface ${o}Props {
  ${s}?: ${o}T | null;
  effect?: (d: Dispatch) => void;
}

export const ${o}Render = ({ ${s} }: ${o}Props) => (
  <div>
    <h4>${o}:</h4>
    <p>
      {\`${l}\`}
    </p>
  </div>
);

export const ${o} = (props: ${o}Props) => {
  const { ${s}, effect } = props;
  const dispatch =useDispatch(); // Generate a redux dispatch for this component

  useEffect(() => {
    // By passing the effect function through props, we can defer the decision whether this function requests data
    //      or merely renders existing data to the parent component
    if (effect) effect(dispatch as Dispatch);
  }, [dispatch]); // This will fire the effect once on component mount

  return (
    <div>{${s} ? <${o}Render ${s}={${s}} /> : <p> No ${o} selected</p>}</div>
  );
};
  `;return b({dir:c,filename:"show.tsx",content:m},"gen_show_demo_component")};var Hr=async(e,t)=>{let{generate:r}=e;return r?Promise.all([jr(e,t),kr(e,t),Br(e,t),Wr(e,t)]):null};var Zr=async(e,t)=>Promise.all([Gr(e),Hr(e,t),await Tr(e,t),await Cr(e,t)]);ke(5);var Zi=async()=>{let e=process.argv.slice(2),t=Kr.resolve(e[0]);e.length<1&&(console.error("Please provide the input file path as an argument."),process.exit(1)),u({level:1,color:"GREEN"},`

 Generating from genfile...

`);let{generator:r,genTypes:n}=await et(t);Le(r.UmbrellaDir||"./"),u({level:2,color:"BLUE"},`
Generating server components...`),await ir(r,n),u({level:2,color:"BLUE"},`
Generating front end components...`),await Zr(r,n),Ue(r.UmbrellaDir||"./",`generate_${r.name.singleSnake}`)};Zi().catch(console.error);
