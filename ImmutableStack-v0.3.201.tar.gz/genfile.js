"use strict";var L=Object.create;var x=Object.defineProperty;var P=Object.getOwnPropertyDescriptor;var j=Object.getOwnPropertyNames;var A=Object.getPrototypeOf,E=Object.prototype.hasOwnProperty;var U=(e,a)=>()=>(a||e((a={exports:{}}).exports,a),a.exports);var z=(e,a,r,i)=>{if(a&&typeof a=="object"||typeof a=="function")for(let l of j(a))!E.call(e,l)&&l!==r&&x(e,l,{get:()=>a[l],enumerable:!(i=P(a,l))||i.enumerable});return e};var C=(e,a,r)=>(r=e!=null?L(A(e)):{},z(a||!e||!e.__esModule?x(r,"default",{value:e,enumerable:!0}):r,e));var S=U((w,v)=>{(function(e,a){typeof require=="function"&&typeof w=="object"&&typeof v=="object"?v.exports=a():typeof define=="function"&&define.amd?define(function(){return a()}):e.pluralize=a()})(w,function(){var e=[],a=[],r={},i={},l={};function d(t){return typeof t=="string"?new RegExp("^"+t+"$","i"):t}function $(t,s){return t===s?s:t===t.toLowerCase()?s.toLowerCase():t===t.toUpperCase()?s.toUpperCase():t[0]===t[0].toUpperCase()?s.charAt(0).toUpperCase()+s.substr(1).toLowerCase():s.toLowerCase()}function m(t,s){return t.replace(/\$(\d{1,2})/g,function(p,u){return s[u]||""})}function h(t,s){return t.replace(s[0],function(p,u){var c=m(s[1],arguments);return $(p===""?t[u-1]:p,c)})}function y(t,s,p){if(!t.length||r.hasOwnProperty(t))return s;for(var u=p.length;u--;){var c=p[u];if(c[0].test(s))return h(s,c)}return s}function f(t,s,p){return function(u){var c=u.toLowerCase();return s.hasOwnProperty(c)?$(u,c):t.hasOwnProperty(c)?$(u,t[c]):y(c,u,p)}}function g(t,s,p,u){return function(c){var _=c.toLowerCase();return s.hasOwnProperty(_)?!0:t.hasOwnProperty(_)?!1:y(_,_,p)===_}}function o(t,s,p){var u=s===1?o.singular(t):o.plural(t);return(p?s+" ":"")+u}return o.plural=f(l,i,e),o.isPlural=g(l,i,e),o.singular=f(i,l,a),o.isSingular=g(i,l,a),o.addPluralRule=function(t,s){e.push([d(t),s])},o.addSingularRule=function(t,s){a.push([d(t),s])},o.addUncountableRule=function(t){if(typeof t=="string"){r[t.toLowerCase()]=!0;return}o.addPluralRule(t,"$0"),o.addSingularRule(t,"$0")},o.addIrregularRule=function(t,s){s=s.toLowerCase(),t=t.toLowerCase(),l[t]=s,i[s]=t},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(t){return o.addIrregularRule(t[0],t[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(t){return o.addPluralRule(t[0],t[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(t){return o.addSingularRule(t[0],t[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(o.addUncountableRule),o})});var b=C(require("fs")),k=require("path");var q=C(S()),R=e=>{let a=N(e),r=I(e),i=T(r),l=I(a),d=T(l),$=e[0];return{singleSnake:e,pluralSnake:a,singleLowerCamel:i,singleUpperCamel:r,pluralLowerCamel:d,pluralUpperCamel:l,singleChar:$}},N=e=>{let a=e.split("_"),r=(0,q.default)(a.pop()||"");return[...a,r].join("_")},I=e=>e.split("_").map(a=>a.charAt(0).toUpperCase()+a.slice(1)).join(""),T=e=>e.replace(e[0],e[0].toLowerCase());var[,,n]=process.argv,G=(0,k.join)(process.cwd(),`.genfile_${n}.ts`);n||(console.error("Please provide a name as an argument."),process.exit(1));var D=()=>b.default.existsSync(G)?O():F(),F=()=>{let{singleUpperCamel:e,singleLowerCamel:a,pluralUpperCamel:r,pluralLowerCamel:i}=R(n),l=`
/*
                    *****************************
                *** APPLICATION TYPE DECLARATIONS ***

  Specify properties for ${a} types.

     Global will be used when other types are not specified. If all types are specified, Global will be ignored. 
       If genfile is run again with the same name argument, global will be propagated to all other types which can then be customized.

                    *****************************
*/

interface ImmutableGlobal
  extends GenType<{
//    * ${e} * 
    example1: integer;
    example2: string;
    example3: float;
  }> {}

interface AppState
  extends GenType<{
    ${a}: ${e} | null;
    ${i}: ${e}[];
  }> {}
interface InitialAppState extends AppState {
  ${a}: null;
  ${i}: [];
}
interface Schema extends GenType<{
  // Schema here or use Global
}> {}
interface DatabaseTable extends GenType<{
  // DatabaseTable here or use Global
}> {}
interface TsType extends GenType<{
  // TsType here or use Global
}> {}

/*
                    ****************************
                        *** GENERATOR ***

  Comment out unwanted functionality or add new functionality for generation.

                    ****************************
*/
const Immutable: ImmutableGenerator = {
  name: "${n}",
  generate: {
    // BACK END
    http_controller: {
      name: "${e}Controller",
      routes: [
        "routed_index(conn, entity_queries, page_queries) when entity_queries == %{}",
        "routed_index(conn, entity_queries, page_queries) when entity_queries != %{}",
        "create(conn, ${n}_list) when is_list(${n}_list)",
        "create(conn, ${n}_params)",
        "show(conn, ${n}_list) when is_list(${n}_list)",
        'show(conn, %{"id" => id})',
        "update(conn, ${n}_list) when is_list(${n}_list)",
        "update(conn, ${n}_params) when is_map(${n}_params)",
        "delete(conn, ${n}_list) when is_list(${n}_list)",
        'delete(conn, %{"id" => id})',
        // "custom_route(conn, %{destructured: params})"
      ],
    },
    channel_controller: "${n}_channel",
    context: {
      name: "${e}Context",
      apiFunctions: [
        "create_${n}(attrs) when is_list(attrs)",
        "create_${n}(${n}_params) when is_map(${n}_params)",
        "delete_${n}(${i}) when is_list(${i})",
        "delete_${n}(${n}_params) when is_map(${n}_params)",
        "delete_${n}(id) when is_binary(id)",
        "get_${n}!(${i}) when is_list(${i})",
        "get_${n}!(${n}_params) when is_map(${n}_params)",
        "get_${n}!(id) when is_binary(id)",
        "list_${i}(page_query \\ %{})",
        "list_${i}_by(entity_queries, page_queries \\ %{})",
        "update_${n}(${i}) when is_list(${i})",
        "update_${n}(attrs) when is_map(attrs)",
        // "custom_api_function(\${key: _value}) when is_binary('guard_clause')",
      ],
    },
    schema: "${e}",
    databaseTable: "${i}",

    // FRONT END
    requests: {
      requestFunctions: [
        "request${e} = (${i}: ${e}[], dispatch: Dispatch)",
        "create${e} = (${i}: ${e}[], dispatch: Dispatch)",
        "update${e} = (${a}: ${e}[], dispatch: Dispatch)",
        "delete${e} = (${a}: ${e}[], dispatch: Dispatch)",
        // "customRequest = (%{key: _value}, dispatch: Dispatch)",
      ],
    },
    stateSlice: {
      name: "${a}Slice",
      reducers: [
        "set${e} = (state, action)",
        "set${r} = (state, action)",
        // "customReducer = (state, {payload: {key: _value}})",
      ],
      selectors: [
        "select${e} = (state)",
        "select${r} = (state)",
        // "customSelector = (%{key: _value})",
      ],
    },
    appstate: "${e}StoreState",
    tstype: "${e}",
    factory: true,
    demoComponents: true,
    test: true,
  },
};


/*
                    ****************************
                        *** PRIMITIVES ***

  View and adjust primitive type associations between Elixir and Typescript

            type ex_type = ts_type & { __brand: 'ex_type'  };
                    ****************************
*/
type integer = number & { __brand: "integer" };
type float = number & { __brand: "float" };
type decimal = number & { __brand: "decimal" };
// type string = string & { __brand: 'string'  };
// type boolean = boolean & { __brand: 'boolean'  };
type date = string & { __brand: "date" };
type time = string & { __brand: "time" };
type naive_datetime = string & { __brand: "naive_datetime" };
type utc_datetime = string & { __brand: "utc_datetime" };
type binary = string & { __brand: "binary" };
type array = any[] & { __brand: "array" };
type map = object & { __brand: "map" };
type json = object & { __brand: "json" };
type id = string & { __brand: "id" };
type uuid = string & { __brand: "uuid" };
type binary_id = string & { __brand: "binary_id" };

/*




















                    ****************************
                        *** INTERNAL USE ***

  The following types are unused other than to provide in-editor type checking for the fields above

                    ****************************
*/

interface AllowedTypes {
  [key: string]:
    | integer
    | float
    | decimal
    | string
    | boolean
    | date
    | time
    | naive_datetime
    | utc_datetime
    | binary
    | array
    | map
    | json
    | id
    | uuid
    | binary_id
    // unique types for appstate only
    | ${e}
    | ${e}[]
    | null;
}
interface ${e} {}
type GenType<T extends AllowedTypes> = T;

interface ImmutableGenerator {
  name: string;
  generate: {
    requests?: ImmutableRequests;
    stateSlice?: ImmutableStateSlice;
    http_controller?: ImmutableController;
    channel_controller?: string;
    context?: ImmutableContext;
    databaseTable?: string;
    schema?: string;
    tstype?: string;
    appstate?: string;
    factory?: boolean;
    demoComponents?: boolean;
    test?: boolean;
  };
}

interface ImmutableController {
  name: string;
  routes: string[];
}

interface ImmutableContext {
  name: string;
  apiFunctions: string[];
}

interface ImmutableStateSlice {
  name: string;
  reducers?: string[];
  selectors?: string[];
}

interface ImmutableRequests {
  requestFunctions: string[];
}

export { Immutable };
export type {
  ImmutableGenerator,
  ImmutableGlobal,
  AppState,
  InitialAppState,
  Schema,
  DatabaseTable,
  TsType,
  ImmutableContext,
  ImmutableController,
  ImmutableRequests,
  ImmutableStateSlice,
};
`;b.default.writeFileSync(`.genfile_${n}.ts`,l,"utf8"),console.log(`Created .genfile_${n}.ts`)},O=()=>{let e=b.default.readFileSync(G,"utf8"),a=e,r=e.match(/interface \w+.*?extends GenType<.*?> \{\}/gs),i=r?.map(m=>W(m)),[l,d]=i?.find(([m,h])=>m==="ImmutableGlobal")||[];i?.map(([m,h,y],f)=>{if(h.length===0&&d){let g="";return r?.[f].replace(/interface\s(\w+).*?extends\sGenType<\{(.*?)\}?> \{\}/gs,(o,t,s)=>(g=`interface ${o} extends GenType<{${d}}> {}`,g)),g}else return r?.[f]})?.forEach((m,h)=>{m&&(a=a.replace(r?.[h]||"",m))}),b.default.writeFileSync(`.genfile_${n}.ts`,a,"utf8"),console.log(`Updated .genfile_${n}.ts`)};D();var W=e=>{let a=e.match(/interface\s(\w+)/)?.[1]||"",r=e.match(/\w+\:\s\w+/gs)?.join(`
`)||"";return[a,r,e]};
