"use strict";var G=Object.create;var _=Object.defineProperty;var L=Object.getOwnPropertyDescriptor;var k=Object.getOwnPropertyNames;var B=Object.getPrototypeOf,O=Object.prototype.hasOwnProperty;var W=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let i of k(t))!O.call(e,i)&&i!==r&&_(e,i,{get:()=>t[i],enumerable:!(n=L(t,i))||n.enumerable});return e};var u=(e,t,r)=>(r=e!=null?G(B(e)):{},W(t||!e||!e.__esModule?_(r,"default",{value:e,enumerable:!0}):r,e));var l=require("child_process"),g=u(require("fs")),m=u(require("path"));var b=require("path");var d=require("fs"),x=require("path");var K=9;var p=(e,...t)=>{e<=K&&console.log(...t)};var R=async({filename:e,dir:t,content:r})=>{let n=(0,x.resolve)(t),i=(0,x.join)(t,e);return p(3,`Generating ${e} ...`),p(9,r),new Promise((o,c)=>{(0,d.mkdirSync)(n,{recursive:!0}),(0,d.writeFile)(i,r,"utf8",a=>a?c(a):o([i]))})};var v=async(e,t)=>{let r=(0,b.join)(t,"/src/store"),n=`
import { configureStore, combineReducers } from "@reduxjs/toolkit";

type ${e}State = {
    // AppState here Key: Value
};

const ${e}Store = configureStore({
  reducer: combineReducers({
    // Reducers here Key: Value
  }),
});

export { ${e}Store };
export type { ${e}State };
        `;return R({dir:r,filename:"index.ts",content:n})};var w=u(require("path"));var h=u(require("fs")),$=require("child_process");var I=async({file:e,injections:t})=>(p(5,`Injecting into ${e}....`),new Promise(async(r,n)=>{let o=h.default.readFileSync(e,"utf8");t.forEach(([c,a,j])=>{switch(p(7,`Injecting ${j} into ${e}`),p(9,"File: ",o),c){case"REPLACE":let E=o.replace(a,j);E==o?S(a,e,n):(p(8,`Found ${a} in ${e}`),o=E);break;default:o=V(o,e,[c,a,j])||S(a,e,n)}}),h.default.writeFileSync(e,o,"utf8"),await U(e),r([e])})),U=async e=>new Promise((t,r)=>{let n=e.endsWith(".tsx")||e.endsWith(".ts"),i=e.endsWith(".ex")||e.endsWith(".exs");n&&(0,$.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),i&&(0,$.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)}),S=(e,t,r)=>(console.error(`${e} not found in the ${t} file.`),r(null),""),V=(e,t,[r,n,i])=>{let o=e.match(n);if(!o)return null;let c=o.index;if(p(8,`Found ${n} at ${c} in ${t}`),r==="AFTER")c+=o[0].length;else if(r!="BEFORE")return null;return e.slice(0,c)+i+e.slice(c)};var P=async(e,t)=>{let r=w.default.join(t,"src/App.tsx"),n=[["AFTER",/import\s+['"]\.\/App\.css['"]/,`
import { Provider } from 'react-redux';
 import { ${e}Store } from './store';`],["BEFORE",/<div\s+className=["']App["']\s*>/,`<Provider store={${e}Store}>
`],["AFTER",/<\/div>/,`
</Provider>`]];return I({file:r,injections:n})};var A=process.argv.slice(2);A.length<1&&(console.error("Usage: node init_proj.js <project_name>"),process.exit(1));var s=A[0];s=s.toLowerCase().replace(/[\s-]/g,"_").replace(/[^a-z0-9_]/g,"");var C=s.split("_").map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(""),z=`${s}_umbrella`,F=m.join(z,"apps"),f=m.join(F,`${s}_ui`),ie=m.join(F,`${s}_web`);console.log(`
Generating Phoenix apps...`);(0,l.execSync)(`mix phx.new ${s} --no-live --no-html --no-assets --binary-id --umbrella --install`,{stdio:"inherit"});var T=m.join(`${s}_umbrella`,"mix.exs"),y=g.readFileSync(T,"utf8");y=y.replace(/apps_path: "apps"/,`apps_path: "apps",
  apps: [:${s}, :${s}_web]`);g.writeFileSync(T,y,"utf8");(0,l.execSync)(`cd ${s}_umbrella && mix format mix.exs`,{stdio:"inherit"});console.log(`
Generating React app...`);(0,l.execSync)(`cd ${F} && npx create-react-app ${s}_ui --template typescript`,{stdio:"inherit"});console.log(`
Installing Redux...`);(0,l.execSync)(`cd ${f} && npm install @reduxjs/toolkit react-redux @types/react-redux`,{stdio:"inherit"});(0,l.execSync)(`cd ${f} && npm install --save-dev @babel/plugin-proposal-private-property-in-object`,{stdio:"inherit"});v(C,f);P(C,f);
