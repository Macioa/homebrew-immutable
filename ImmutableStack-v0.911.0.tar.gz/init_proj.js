"use strict";var Zt=Object.create;var oe=Object.defineProperty;var eo=Object.getOwnPropertyDescriptor;var to=Object.getOwnPropertyNames;var oo=Object.getPrototypeOf,ro=Object.prototype.hasOwnProperty;var no=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var io=(e,t,o,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let n of to(t))!ro.call(e,n)&&n!==o&&oe(e,n,{get:()=>t[n],enumerable:!(r=eo(t,n))||r.enumerable});return e};var _=(e,t,o)=>(o=e!=null?Zt(oo(e)):{},io(t||!e||!e.__esModule?oe(o,"default",{value:e,enumerable:!0}):o,e));var Fe=no((Q,Z)=>{(function(e,t){typeof require=="function"&&typeof Q=="object"&&typeof Z=="object"?Z.exports=t():typeof define=="function"&&define.amd?define(function(){return t()}):e.pluralize=t()})(Q,function(){var e=[],t=[],o={},r={},n={};function a(c){return typeof c=="string"?new RegExp("^"+c+"$","i"):c}function m(c,d){return c===d?d:c===c.toLowerCase()?d.toLowerCase():c===c.toUpperCase()?d.toUpperCase():c[0]===c[0].toUpperCase()?d.charAt(0).toUpperCase()+d.substr(1).toLowerCase():d.toLowerCase()}function g(c,d){return c.replace(/\$(\d{1,2})/g,function(k,x){return d[x]||""})}function y(c,d){return c.replace(d[0],function(k,x){var f=g(d[1],arguments);return m(k===""?c[x-1]:k,f)})}function b(c,d,k){if(!c.length||o.hasOwnProperty(c))return d;for(var x=k.length;x--;){var f=k[x];if(f[0].test(d))return y(d,f)}return d}function v(c,d,k){return function(x){var f=x.toLowerCase();return d.hasOwnProperty(f)?m(x,f):c.hasOwnProperty(f)?m(x,c[f]):b(f,x,k)}}function w(c,d,k,x){return function(f){var R=f.toLowerCase();return d.hasOwnProperty(R)?!0:c.hasOwnProperty(R)?!1:b(R,R,k)===R}}function u(c,d,k){var x=d===1?u.singular(c):u.plural(c);return(k?d+" ":"")+x}return u.plural=v(n,r,e),u.isPlural=w(n,r,e),u.singular=v(r,n,t),u.isSingular=w(r,n,t),u.addPluralRule=function(c,d){e.push([a(c),d])},u.addSingularRule=function(c,d){t.push([a(c),d])},u.addUncountableRule=function(c){if(typeof c=="string"){o[c.toLowerCase()]=!0;return}u.addPluralRule(c,"$0"),u.addSingularRule(c,"$0")},u.addIrregularRule=function(c,d){d=d.toLowerCase(),c=c.toLowerCase(),n[c]=d,r[d]=c},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(c){return u.addIrregularRule(c[0],c[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(c){return u.addPluralRule(c[0],c[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(c){return u.addSingularRule(c[0],c[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(u.addUncountableRule),u})});var N=_(require("fs")),ne=require("stream");var M=_(require("path")),re=(...e)=>{e.reduce((t,o)=>o?t:!1,!0)||console.error("Invalid Path",...e)},i=(...e)=>(re(...e),M.default.join(...e)),S=(...e)=>(re(...e),M.default.join(...e));var so="https://raw.githubusercontent.com/macioa/immutablestack/alpha/assets/",ao=["logo3.png"],co=ao.map(e=>({name:e,url:new URL(e,so).toString()}));async function ie({UiDir:e}){let t=i(e,"./src/assets/");await N.default.promises.mkdir(t,{recursive:!0});let o=co.map(async({name:r,url:n})=>{let a=await fetch(n);if(!a.ok)throw new Error(`Failed to fetch ${n}`);let m=ne.Readable.fromWeb(a.body),g=N.default.createWriteStream(i(t,r));return await new Promise((y,b)=>{m.pipe(g),g.on("finish",y),g.on("error",b)}),r});return Promise.all(o)}var $=require("fs");var B=3,po={GREEN:"\x1B[38;2;0;255;0m%s\x1B[0m",RED:"\x1B[38;2;255;0;0m%s\x1B[0m",YELLOW:"\x1B[38;2;255;255;0m%s\x1B[0m",BLUE:"\x1B[38;2;0;0;255m%s\x1B[0m",TEAL:"\x1B[38;2;0;255;255m%s\x1B[0m",PURPLE:"\x1B[38;2;255;0;255m%s\x1B[0m",TAN:"\x1B[38;2;210;180;140m%s\x1B[0m",PINK:"\x1B[38;2;255;0;127m%s\x1B[0m"},se=e=>(B=e,B),l=async({level:e,color:t},...o)=>{if(e<=B)return o=t?[po[t],...o]:o,e<4&&process.stdout.write(`
`),e===1&&(process.stdout.write(`
`),o=o.map(r=>typeof r=="string"?`\x1B[1m${r}\x1B[0m`:r)),console.log(...o),e<3&&process.stdout.write(`
`),await lo(e>=5?0:5-e)},lo=e=>new Promise(t=>setTimeout(t,e*1e3));var z=require("child_process"),L=async e=>new Promise((t,o)=>{let r=e.endsWith(".tsx")||e.endsWith(".ts"),n=e.endsWith(".ex")||e.endsWith(".exs");r&&(0,z.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),n&&(0,z.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)});var ce=require("fs");var ae=(e,t=null)=>(Object.keys(e).forEach(o=>{let r=e[o];if(r==null)throw console.error(`${o} in StringOnlyMap cannot be null or undefined.
     Caller: ${t}`),`${o} in StringOnlyMap cannot be null or undefined. Caller: ${t}`}),!0),W=(e,t)=>t.reduce((o,r)=>o?.[r],e);var G=(e,t,o)=>{let r=t.pop(),n=W(e,t);n&&typeof n=="object"?n[r]=o:G(e,t,{[r]:o})};var K=null,I={_name:null,commands:[],file_modifications:{}},pe=({command:e,dir:t},o=null)=>{I.commands.push({command:e,dir:t,caller:o||"unreferenced"})},Y=({filename:e,dir:t},o=null)=>{ae({filename:e,dir:t},o);let r=mo(t),{file_modifications:n}=I,a=r.split("/").filter(y=>y).concat([e]),g=(W(n,a)||[]).concat([o||"unreferenced"]);return G(I,["file_modifications",...a],g),I},le=(e,t)=>{I._name=t;let o=JSON.stringify(I,null,2);(0,ce.writeFileSync)(S(e,`.immutable_history_${t}.json`),o,"utf8")},me=(e,t=null)=>{let o=e.split("/").filter(a=>a),r=o.slice(-1)[0],n=o.slice(0,-1).join("/");return Y({filename:r,dir:n},t)},de=e=>{K=S(e).replace(/^[^\w]+/,"")},mo=e=>(e=e.replace(/^[^\w]+/,""),(K?e.replace(K,""):e).replace(/^[^\w]+/,""));var s=async({filename:e,dir:t,content:o},r=null)=>{try{Y({filename:e,dir:t},r);let n=S(t),a=i(t,e);return r&&l({level:5,color:"TAN"},r),l({level:5},`Generating ${e} ...`),l({level:9},o),(0,$.mkdirSync)(n,{recursive:!0}),(0,$.existsSync)(a)&&(0,$.unlinkSync)(a),(0,$.writeFileSync)(a,o,"utf8"),await L(a),[a]}catch(n){throw new Error(`Error in ${r}`,{cause:n})}};var ue=async({UmbrellaDir:e,AppNameSnake:t})=>{let o=e||"";o+="/docker";let r="compose.yaml",n=`services:
  ${t}_dev:
    build:
      context: ..
      dockerfile: docker/dev.dockerfile
    volumes:
      - ../:/app:cached
      - /app/_build
    working_dir: /app
    command: bash -c "iex -S mix phx.server"
    ports:
      - "4000:4000"
      - "5173-5183:5173-5183"
    environment:
      - MIX_ENV=docker
      - NODE_ENV=development
      - DATABASE_URL=ecto://postgres:postgres@db:5432/${t}_dev
    depends_on:
      - ${t}_db
    tty: true
    stdin_open: true

  ${t}_db:
    image: postgres:15-alpine
    restart: unless-stopped
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_DB=${t}_db
    volumes:
      - ./pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"`;return s({filename:r,dir:o,content:n},"gen_docker_compose")};var fe=async({UmbrellaDir:e})=>{let t=e;return t=i(t,"docker"),s({filename:"dev.dockerfile",dir:t,content:`FROM elixir:1.18-alpine

# Install Node.js and necessary build tools
RUN apk add --no-cache   build-base   git   npm   nodejs   inotify-tools   bash

# Install Hex and Rebar
RUN mix local.hex --force &&     mix local.rebar --force &&     mix archive.install hex phx_new --force

ENV PATH="$MIX_HOME/archives:$PATH"

# Set working directory
WORKDIR /app`},"gen_docker_dev")};var _e=async({UmbrellaDir:e,AppNameSnake:t})=>{let o=e||"";o+="/docker";let r=".env",n=`COMPOSE_PROJECT_NAME=${t}`;return s({filename:r,dir:o,content:n},"gen_docker_env")};var ge=async({UmbrellaDir:e})=>s({filename:".dockerignore",dir:e||"",content:`_build
deps
node_modules
*/node_modules
docker`},"gen_docker_ignore");var he=async({UmbrellaDir:e,AppNameSnake:t})=>{let o=e||"";o+="/docker";let r="prod.dockerfile",n=`# Stage 1: Build Elixir/Phoenix
FROM elixir:1.18-alpine AS builder

# Install OS dependencies
RUN apk add --no-cache build-base git npm nodejs postgresql-dev
RUN mix local.hex --force

# Set environment
ENV MIX_ENV=prod

# Set workdir
WORKDIR /app

# Copy umbrella root config + subapp definitions
COPY mix.exs mix.lock ./
COPY config config
COPY apps apps

# Install hex + rebar and fetch dependencies
RUN mix local.hex --force &&     mix local.rebar --force &&     mix deps.get

# Digest static assets from the Phoenix app
RUN mix phx.digest --priv=apps/${t}_web/priv

# Compile entire umbrella and build release
RUN mix compile && mix release

# Stage 2: Minimal Runtime
FROM alpine:3.18 AS app

# Install runtime dependencies
RUN apk add --no-cache libstdc++ openssl ncurses-libs

# Set workdir
WORKDIR /app

# Copy the release from the builder stage
COPY --from=builder /app/_build/prod/rel/your_release_name ./

# Run the release
CMD ["bin/YOUR_RELEASE_NAME", "start"]`;return s({filename:r,dir:o,content:n},"gen_docker_prod")};var H=_(require("fs"));var p=async({file:e,injections:t},o=null)=>{try{return o&&l({level:5,color:"TAN"},o),l({level:5},`Injecting into ${e} ...`),new Promise(async(r,n)=>{me(e,o);let m=H.default.readFileSync(e,"utf8");t.forEach(([g,y,b])=>{switch(l({level:7},`Injecting ${b} into ${e}`),l({level:9},"File: ",m),g){case"REPLACE":let v=typeof b=="function"?b(m):m.replace(y,b);if(b&&(v==m||v=="")){xe(y,e,n);return}else l({level:8},`Found ${y} in ${e}`),m=v;break;default:m=uo(m,e,[g,y,b])||xe(y,e,n)}}),m.length?(H.default.writeFileSync(e,m,"utf8"),await L(e),r([e])):n(new Error(`Insertion failed for ${e}`))})}catch(r){throw new Error(`Error in ${o}`,{cause:r})}},xe=(e,t,o)=>(console.error(`${e} not found in the ${t} file.`),o(new Error(`Insertion failed for ${t}`)),""),uo=(e,t,[o,r,n])=>{let a=new RegExp(r.source,r.flags).exec(e);if(!a)return null;let m=a.index;if(l({level:8},`Found ${r} at ${m} in ${t}`),o==="AFTER")m+=a[0].length;else if(o!="BEFORE")return null;return e.slice(0,m)+n+e.slice(m)};var ye=({UmbrellaDir:e,AppNameSnake:t})=>{let o=i(e||"","package.json"),r=`
"APP MAINTENANCE DOCKERIZED": "echo 'APP MAINTENANCE'",
    "d.deps": "m='Fetching Dependencies (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml run --rm ${t}_dev mix deps.get",
    "d.comp": "m='Compiling Apps (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml run --rm ${t}_dev mix compile",
    "d.mig": "m='Running Database Migrations (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml run --rm ${t}_dev mix ecto.migrate",
    "APP STARTUP DOCKERIZED": "echo 'APP STARTUP'",
    "d.test": "m='Running Tests (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml run --rm test mix test",
    "d.serv": "m='Starting Server (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml up -d",
    "SERVICE LOGS": "echo 'SERVICE LOGS'",
    "d.logs": "m='Fetching Logs (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml logs --follow",
    "COMPOSE UTILITIES": "echo 'COMPOSE UTILITIES'",
    "d.build": "m='Building Apps (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml build",
    "d.restart": "m='Restarting Apps (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml restart -d",
    "BUILD, RUN, STOP, DESTROY CONTAINERS": "echo 'BUILD, RUN, STOP, DESTROY CONTAINERS'",
    "d.up": "m='Starting Apps (** Docker **) ...' && echo $m && yarn d.kill && yarn d.deps && yarn d.comp && yarn d.serv && yarn d.logs",
    "d.down": "m='Stopping Apps (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml down",
    "d.db": "m='Starting Only the Database (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml up -d ${t}_db",
    "HOLD OR KILL CONTAINERS": "echo 'HOLD OR KILL CONTAINERS'",
    "d.hold": "m='Holding Containers (** Docker **) ...' && echo $m && yarn d.up && docker compose -f docker/compose.yaml exec ${t}_dev sleep 1000000",
    "d.kill": "m='Killing Apps (** Docker **) ...' && echo $m && docker compose -f docker/compose.yaml kill",
    "PRODUCTION BUILD": "echo 'PRODUCTION BUILD'",
    "p.build": "m='Building Production Container (** Docker **) ...' && echo $m && docker build -f docker/prod.dockerfile -t ${t}_prod .",
    "p.hold": "m='Holding Production Container (** Docker **) ...' && echo $m && docker run -it --rm -p 4000:4000 ${t}_prod bash",
`,n=[["AFTER",/"scripts"\s*:\s\{/g,r]];return p({file:o,injections:n},"inject_docker_scripts_package")};var Se=require("child_process"),Ie=require("fs"),Te=require("path");var be=require("fs/promises"),T=_(require("path"));var ve=require("fs"),ke=(e,t=!0)=>{let o=process.cwd(),r=t?o:T.default.join(o,`${e}_umbrella`),n=T.default.join(r,"apps"),a=T.default.join(n,e),m=T.default.join(n,`${e}_ui`),g=T.default.join(n,`${e}_web`);return{AppDir:n,LibDir:a,UiDir:m,WebDir:g,UmbrellaDir:r}},je=e=>{let t=e?.replace(/([A-Z])/g,"_$1")?.toLowerCase()?.slice(1),o=t.toUpperCase();return{AppNameSnake:t,AppNameCaps:o,AppNameCamel:e}},fo=e=>{let t=je(e),o=ke(t.AppNameSnake);return{...t,...o}},we=(e,t=!0)=>{let o=e?.replace(/_([a-z])/g,a=>a[1].toUpperCase())?.replace(/^./,a=>a.toUpperCase()),r=je(o),n=ke(r.AppNameSnake,t);return{...r,...n}},Ee=async function(){try{if(l({level:8},`Getting App Data from mix.exs in ${process.cwd()}`),!(0,ve.existsSync)("mix.exs"))return null;let t=(await(0,be.readFile)("mix.exs","utf-8")).match(/(?<=defmodule\s+)\w+(?=\.Umbrella\.MixProject)/)?.[0]||"";return fo(t)}catch(e){return console.error(`Could not get AppName from mix.exs
${e}`),null}},J=Ee(),$e=e=>{J=e},F=()=>J||Ee();var Ae=require("child_process"),P=require("crypto"),E=require("fs"),D=require("os");var O=".immutable",X=vo(),V=function(){return new Promise((e,t)=>(0,Ae.exec)("brew --prefix immutable",(o,r,n)=>e(r.trim())))}();async function _o(e){l({level:38},"Hashing file",{dir:await V});let t=(0,P.createHash)("sha256");l({level:38},"Hashing file",{filePath:e}),l({level:38},"Hashing file",{dir:i(await V,"bin/"+e)});let o=(0,E.createReadStream)(i(await V,"bin/"+e));return new Promise((r,n)=>{o.on("data",a=>t.update(a)),o.on("end",()=>{l({level:38},"Hashed file",{hash:t}),r(t.digest("hex"))}),o.on("error",a=>n(a))})}async function go(e,t=(0,P.createHash)("sha256").update(e).digest()){return{key:t.slice(0,32),iv:t.slice(16,32)}}async function ho(e){return Object.keys(e).forEach(async t=>e[t]=_o(e[t])),await Promise.all(Object.values(e)),l({level:38},"Salted files",e),JSON.stringify({home:(0,D.homedir)(),...e})}var Re=({key:e,iv:t},o,r=(0,P.createCipheriv)("aes-256-cbc",e,t))=>Buffer.concat([r.update(o),r.final()]).toString("hex"),xo=({key:e,iv:t},o,r=(0,P.createDecipheriv)("aes-256-cbc",e,t))=>{try{return Buffer.concat([r.update(Buffer.from(o,"hex")),r.final()]).toString()}catch(n){return l({level:1,color:"RED"},"Decryption error",{err:n,message:"Wrong user or source code has changed",action:"Clear settings with immutable -settings -clear"}),null}},A={};var yo=async()=>{if(l({level:37},"Reading settings",{home:(0,D.homedir)(),SETTINGS:O}),Object.keys(A).length)return A;if(!(0,E.existsSync)(i((0,D.homedir)(),O)))return await bo({}),{};let e=(0,E.readFileSync)(i((0,D.homedir)(),O),"utf8");return A=JSON.parse(xo(await X,e)||"{}"),A},bo=async e=>{l({level:37},"Writing settings"),A=e;let t=JSON.stringify(e);return l({level:38},"Write Data",{home:(0,D.homedir)(),SETTINGS:O,raw:t}),l({level:38},{SETTINGS_CACHE:A,body:Re(await X,t)}),(0,E.writeFileSync)(i((0,D.homedir)(),O),Re(await X,t),"utf8")};var C=async e=>yo().then(()=>A[e]);async function vo(){return await go(await ho({init:"init_proj.js",gen:"gen.js",repair:"repair.js",settings:"settings.js"}))}var ko=async(e,t)=>{if(await C("nomix")!="true")return e;let r=!!e.match(/\bmix\b/g),n=!!e.match(/\bphx.new\b/g),a="",m="docker/compose.yaml";return r&&l({level:2,color:"PINK"},"Running MIX in Docker..."),n&&(a=`mkdir -p ${t}_umbrella && cd ${t}_umbrella && `,e=`${e} && cp -rf ${t}_umbrella/* . && rm -rf ${t}_umbrella`,m="docker/compose.yaml"),r?`${a}docker compose -f ${m} run --rm ${t}_dev bash -c "shopt -s dotglob && ${e}"`:e},De=ko;var Pe={dir:"",command:"",options:{forceReturnOnPrompt:!0}};var j=async(e,t=null)=>{let{dir:o,command:r,env:n,options:a}={...Pe,...e},{timeoutResolve:m,timeoutReject:g,forceReturnOnPrompt:y,resolveOnErrorCode:b}={...Pe.options,...a},v=await De(r,(await F())?.AppNameSnake||"");return pe({command:v,dir:o},t),l({level:1,color:"PURPLE"},`Executing: ${v}`),l({level:1,color:"TEAL"},`      in ${o}...

`),new Promise((w,u)=>{let c=(0,Te.resolve)(o);(0,Ie.mkdirSync)(c,{recursive:!0});let[d,...k]=v.split(" "),x=(0,Se.spawn)(d,k,{cwd:c,shell:!0,env:n});x.stdout.on("data",f=>{l({level:5},f.toString()),a?.prompts&&a.prompts.forEach(([R,Xt])=>{if(f.toString().includes(R)){let Qt=Xt+(y?`
`:"");x.stdin.write(Qt)}})}),x.stderr.on("error",f=>{console.error(`Could not run ${v}:
      ${f}`),u(f||`Could not run ${v}`)}),x.on("close",f=>{!b&&f?(console.error(`Process exited with exit code ${f}:
       ${v}`),u(`Process exited with ${f}`)):w(o)}),m&&setTimeout(()=>w(o),m),g&&setTimeout(()=>u(new Error("Time out")),g)})};var jo=async({UmbrellaDir:e})=>j({dir:e,command:"npm init -y"},"init_package_json"),Ce=async e=>{let{UmbrellaDir:t}=e;await j({dir:t,command:"mkdir -p docker/pgdata"},"init_docker");let o=await Promise.all([ue(e),fe(e),he(e),_e(e),ge(e),jo(e)]),r=await ye(e);return o.concat(r)};var Oe=async({UmbrellaDir:e,AppNameCamel:t,AppNameSnake:o})=>{let r="dev.exs",n=e||"";n=i(n,"config");let a=`import Config

# Set UI variables
config :${o}, :ui,
  app_name: "${t}",
  API_URL: "http://localhost:4000/api/",
  SOCKET_URL: "ws://localhost:4000/socket"

# Configure your database
config :${o}, ${t}.Repo,
  username: "postgres",
  password: "postgres",
  hostname: "localhost",
  database: "${o}_db",
  stacktrace: true,
  show_sensitive_data_on_connection_error: true,
  pool_size: 10

# For development, we disable any cache and enable
# debugging and code reloading.
#
# The watchers configuration can be used to run external
# watchers to your application. For example, we can use it
# to bundle .js and .css sources.
config :${o}, CORSPlug, origin: "*"

config :${o}_web, ${t}Web.Endpoint,
  # Binding to loopback ipv4 address prevents access from other machines.
  # Change to \`ip: {0, 0, 0, 0}\` to allow access from other machines.
  http: [ip: {0, 0, 0, 0}, port: 4000],
  check_origin: false,
  code_reloader: true,
  debug_errors: true,
  secret_key_base: "gU20Dle/0HOrq6LTY4AdzGi8GZ9kGO28xbIEhQmGTKA0D9mJQwbtFbUxL5Y9Oyj6",
  watchers: []

# ## SSL Support
#
# In order to use HTTPS in development, a self-signed
# certificate can be generated by running the following
# Mix task:
#
#     mix phx.gen.cert
#
# Run \`mix help phx.gen.cert\` for more information.
#
# The \`http:\` config above can be replaced with:
#
#     https: [
#       port: 4001,
#       cipher_suite: :strong,
#       keyfile: "priv/cert/selfsigned_key.pem",
#       certfile: "priv/cert/selfsigned.pem"
#     ],
#
# If desired, both \`http:\` and \`https:\` keys can be
# configured to run both http and https servers on
# different ports.

# Enable dev routes for dashboard and mailbox
config :${o}_web, dev_routes: true

# Do not include metadata nor timestamps in development logs
config :logger, :console, format: "[$level] $message
"

# Initialize plugs at runtime for faster development compilation
config :phoenix, :plug_init_mode, :runtime

# Disable swoosh api client as it is only required for production adapters.
config :swoosh, :api_client, false

# Set a higher stacktrace during development. Avoid configuring such
# in production as building large stacktraces may be expensive.
config :phoenix, :stacktrace_depth, 20
`;return s({filename:r,dir:n,content:a},"gen_dev_config_env")};var Le=async({UmbrellaDir:e,AppNameCamel:t,AppNameSnake:o})=>{let r="docker.exs",n=e||"";n=i(n,"config");let a=`import Config

# Set UI variables
config :${o}, :ui,
  app_name: "${t}",
  API_URL: "http://localhost:4000/api/",
  SOCKET_URL: "ws://localhost:4000/socket"

# Configure your database
config :${o}, ${t}.Repo,
  username: "postgres",
  password: "postgres",
  hostname: "${o}_db",
  database: "${o}_db",
  stacktrace: true,
  show_sensitive_data_on_connection_error: true,
  pool_size: 10

# For development, we disable any cache and enable
# debugging and code reloading.
#
# The watchers configuration can be used to run external
# watchers to your application. For example, we can use it
# to bundle .js and .css sources.
config :${o}, CORSPlug, origin: "*"

config :${o}_web, ${t}Web.Endpoint,
  # Binding to loopback ipv4 address prevents access from other machines.
  # Change to \`ip: {0, 0, 0, 0}\` to allow access from other machines.
  http: [ip: {0, 0, 0, 0}, port: 4000],
  check_origin: false,
  code_reloader: true,
  debug_errors: true,
  secret_key_base: "gU20Dle/0HOrq6LTY4AdzGi8GZ9kGO28xbIEhQmGTKA0D9mJQwbtFbUxL5Y9Oyj6",
  watchers: []

# ## SSL Support
#
# In order to use HTTPS in development, a self-signed
# certificate can be generated by running the following
# Mix task:
#
#     mix phx.gen.cert
#
# Run \`mix help phx.gen.cert\` for more information.
#
# The \`http:\` config above can be replaced with:
#
#     https: [
#       port: 4001,
#       cipher_suite: :strong,
#       keyfile: "priv/cert/selfsigned_key.pem",
#       certfile: "priv/cert/selfsigned.pem"
#     ],
#
# If desired, both \`http:\` and \`https:\` keys can be
# configured to run both http and https servers on
# different ports.

# Enable dev routes for dashboard and mailbox
config :${o}_web, dev_routes: true

# Do not include metadata nor timestamps in development logs
config :logger, :console, format: "[$level] $message
"

# Initialize plugs at runtime for faster development compilation
config :phoenix, :plug_init_mode, :runtime

# Disable swoosh api client as it is only required for production adapters.
config :swoosh, :api_client, false

# Set a higher stacktrace during development. Avoid configuring such
# in production as building large stacktraces may be expensive.
config :phoenix, :stacktrace_depth, 20
`;return s({filename:r,dir:n,content:a},"gen_docker_config_env")};var wo=_(Fe());var qe="openai",Eo="https://api.openai.com/v1/chat/completions",$o={model:"gpt-3.5-turbo",temperature:.2},Ro=async({prompt:e,context:t,target:o,output:r})=>{let n={messages:[{role:"user",content:JSON.stringify({prompt:e}),name:"prompt"},{role:"user",content:JSON.stringify({target:o}),name:"target"},...t.map(w=>({role:"assistant",content:JSON.stringify(w),name:"associated_type_declarations$"})),...r.map((w,u)=>({role:"system",content:JSON.stringify({rule:w}),name:`output_rule_${u}`}))],...$o};l({level:5},"Request",{...n});let m=await(await fetch(Eo,{method:"POST",headers:{Authorization:`Bearer ${await C(qe)}`,"Content-Type":"application/json"},body:JSON.stringify(n)})).json();l({level:3},"Response:",m?.choices);let{id:g,model:y,usage:b}=m,v=m?.choices[0].message.content?.replace(/^```typescript/g,"")?.replace(/```$/g,"");return{id:g,model:y,result:v,usage:b,api:qe}},Ue=Ro;var Ao={openai:Ue},Me=Ao;var Do=async function(){return Me[await C("llm")]}();var yn=async function(){return await F()}();var Po={EX:"#",JS:"//",TS:"//"};var q=({str:e,type:t,entity:o=""},r="TS")=>{let n=crypto.randomUUID(),a=`${Po[r]} ** IMMUTABLE ${o} ${t} ${n} **`;return["",a,e,a,""].join(`
`)};var Ne=async({WebDir:e,AppNameCamel:t,AppNameSnake:o})=>{let r=i(e||".",`lib/${o}_web/controllers`),n=`
defmodule ${t}Web.FallbackController do
  @moduledoc """
  Translates controller action results into valid \`Plug.Conn\` responses.

  See \`Phoenix.Controller.action_fallback/1\` for more details.
  """
  use ${t}Web, :controller

  alias Ecto.Changeset

  # This clause handles errors returned by Ecto's insert/update/delete.
  def call(conn, {:error, %Ecto.Changeset{} = changeset}) do
    conn
    |> put_status(:unprocessable_entity)
    |> json(error_transform(changeset))
  end

  def call(conn, {:error, [], failed_changesets}) when is_list(failed_changesets) do
    conn
    |> put_status(:unprocessable_entity)
    |> json(%{errors: error_transform(failed_changesets)})
  end

  # This clause is an example of how to handle resources that cannot be found.
  def call(conn, {:error, :not_found}) do
    conn
    |> put_status(:not_found)
    |> put_view(html: ${t}Web.ErrorHTML, json: ${t}Web.ErrorJSON)
    |> render(:"404")
  end

  def call(conn, {:error, status, error}) when is_atom(error) do
    conn
    |> put_status(status)
    |> json(%{error: Atom.to_string(error)})
  end

  def call(%Plug.Conn{private: %{plug_error: %{status: status, message: message}}} = conn) do
    conn
    |> put_status(status)
    |> json(%{error: message})
  end

  def error_transform(changesets) when is_list(changesets),
    do: changesets |> Enum.map(&error_transform/1)

  def error_transform(%Changeset{} = cs) do
    errors =
      Enum.reduce(cs.errors, %{}, fn {key, {reason, _}}, acc -> Map.put(acc, key, reason) end)

    Map.put(cs.changes, :errors, errors)
  end
end
`,a=q({str:n,type:"FALLBACK_CONTROLLER"},"EX");return s({dir:r,filename:"fallback_controller.ex",content:a},"gen_fallback_controller")};var Be=async({AppNameCamel:e,LibDir:t})=>{let o=i(t,"/lib/mix/plugs/"),r=`
defmodule ${e}.Plugs.ValidateBinaryId do
  import Plug.Conn
  alias Ecto.UUID

  def init(opts) do
    case Keyword.get(opts, :fallback) do
      controller ->
        case Code.ensure_loaded?(controller) do
          true -> opts
          _ -> {:error, :validate_fallback_controller_not_loaded}
        end

      _ ->
        {:error, :validate_requires_fallback_controller}
    end
  end

  def call(conn, opts) do
    with id when not is_nil(id) <- Map.get(conn.params, "id"),
         {:ok, _} <- UUID.cast(id) do
      conn
    else
      nil -> conn
      _ ->
        controller = Keyword.get(opts, :fallback, ${e}Web.FallbackController)

        conn
        |> put_private(:plug_error, %{
          status: :bad_request,
          message: "Unable to cast id as UUID"
        })
        |> controller.call
    end
  end
end
`;return s({dir:o,filename:"validate_uuid.ex",content:r},"gen_id_validation_plug")};var ze=async({WebDir:e,AppNameCamel:t})=>{let o="user_socket.ex",r=i(e||"","lib/channels"),n=`defmodule ${t}Web.UserSocket do
  use Phoenix.Socket

  def connect(_params, socket, _connect_info) do
    {:ok, socket}
  end

  def id(_socket), do: nil
end`;return s({filename:o,dir:r,content:n},"gen_user_socket")};var We=async({AppNameCamel:e,LibDir:t})=>{let o=i(t||"","/lib/utils"),r=`
defmodule ${e}.Utils.Chunk do
  @size 1000

  @doc """
  Applies a function to a list in chunks with specified or default chunk size.
  """
  def apply(list, fun, size \\\\ @size) do
    list
    |> Enum.chunk_every(size)
    |> Enum.map(&fun.(&1))
  end

  @doc """
  Given a chunked list of :ok, :partial_success, or :error tuples, in
  {:status, succeeded_list, failed_list} or
  {:status, success_count, fail_count} format,
  reduce the result lists, counts, and status to summarize the entire operation.
  """
  def flat_reduce(chunked_tuples) do
    case List.first(chunked_tuples) do
      {status, s, f} when is_atom(status) and is_list(s) and is_list(f) ->
        chunked_tuples
        |> Enum.reduce({:ok, [], []}, fn
          # {:status, created [], invalid []}
          # destructured chunk, destructured accumulator -> accumulated result
          {:ok, c, []}, {:ok, csum, []} -> {:ok, csum ++ c, []}
          {:ok, c, []}, {_, csum, isum} -> {:partial_success, csum ++ c, isum}
          {:partial_success, c, i}, {_, csum, isum} -> {:partial_success, csum ++ c, isum ++ i}
          {:error, [], i}, {_, [], isum} -> {:error, [], isum ++ i}
          {:error, [], i}, {_, csum, isum} -> {:partial_success, csum, isum ++ i}
        end)

      {status, s, f} when is_atom(status) and is_integer(s) and is_integer(f) ->
        chunked_tuples
        |> Enum.reduce({:ok, 0, 0}, fn
          # {:status, succeeded 0, failed 0}
          # destructured chunk, destructured accumulator -> accumulated result
          {:ok, s, 0}, {:ok, ssum, 0} -> {:ok, ssum + s, 0}
          {:ok, s, 0}, {_, ssum, fsum} -> {:partial_success, ssum + s, fsum}
          {:partial_success, s, f}, {_, ssum, fsum} -> {:partial_success, ssum + s, fsum + f}
          {:error, 0, f}, {_, 0, fsum} -> {:error, 0, fsum + f}
          {:error, 0, f}, {_, ssum, fsum} -> {:partial_success, ssum, fsum + f}
        end)
    end
  end

  @doc """
  Given a list of records, prep the chunk for bulk db edits
  """
  def prep(changesets, opts \\\\ %{}) do
    def_opts = %{
      inserted_at?: true
    }

    %{inserted_at?: inserted} = Map.merge(def_opts, opts)
    timestamp = NaiveDateTime.utc_now() |> NaiveDateTime.truncate(:second)

    changesets
    |> Enum.map(& &1.changes)
    |> Enum.map(fn record ->
      new_properties =
        case [inserted] do
          [true] -> Map.merge(record, %{inserted_at: timestamp, updated_at: timestamp})
          [false] -> Map.delete(record, :inserted_at) |> Map.merge(%{updated_at: timestamp})
        end

      Map.merge(record, new_properties)
    end)
  end
end
`;return s({dir:o,filename:"chunk.ex",content:r},"gen_chunk_util")};var Ge=async({AppNameCamel:e,LibDir:t})=>{let o=i(t||"","/lib/utils"),r=`
defmodule ${e}.Utils.DynamicQuery do
  import Ecto.Query
  @moduledoc """
  A utility module for building dynamic queries based on controller level restful query params.
  Pass the params and schema to by_schema to convert the restful query to a database query.
  """

  @doc """
  Given a map of controller level restful query params and a schema module,
      cast controller parameters to schema types for dynamic Ecto query construction.
  """
  def by_schema(controller_params, schema_module) do
    field_types = get_schema_field_types(schema_module)

    case validate_params(controller_params, field_types) do
      {:ok, parsed_params} ->
        query = Enum.reduce(parsed_params, from(s in schema_module), &apply_filter/2)

        opts =
          Enum.reduce(parsed_params, %{}, fn {key, op, value}, acc ->
            Map.put(acc, key, "#{op} #{value}")
          end)

        {:ok, query, opts}

      error_forward ->
        error_forward
    end
  end

  @doc """
  Given a schema module, return a map of field names to their types.
  """
  def get_schema_field_types(schema_module) when is_atom(schema_module) do
    schema_module.__schema__(:fields)
    |> Enum.map(fn field ->
      {field, schema_module.__schema__(:type, field)}
    end)
    |> Enum.into(%{})
  end

  @doc """
  Given controller level params and designated field types, validate the mathmatical operator and return a list of parsed params.
  """
  def validate_params(params, field_types) do
    Enum.reduce_while(params, {:ok, []}, fn {key, value}, {:ok, acc} ->
      case parse_param(key, value, field_types) do
        {:ok, parsed_param} -> {:cont, {:ok, [parsed_param | acc]}}
        {:error, message} -> {:halt, {:error, message}}
      end
    end)
  end

  @doc """
  Build query with parsed params.
  """
  def apply_filter({field, operator, value}, query) do
    field_atom = String.to_atom(field)

    dynamic_clause =
      case operator do
        "<" -> dynamic([u], field(u, ^field_atom) < ^value)
        ">" -> dynamic([u], field(u, ^field_atom) > ^value)
        "<=" -> dynamic([u], field(u, ^field_atom) <= ^value)
        ">=" -> dynamic([u], field(u, ^field_atom) >= ^value)
        "=" -> dynamic([u], field(u, ^field_atom) == ^value)
        _ -> raise "Invalid operator: #{operator}"
      end

    where(query, ^dynamic_clause)
  end

  # Check type of each param and build where clauses
  defp parse_param(key, value, field_types) do
    reg =
      ~r/(?<key>[_a-zA-z0-9]+)(?<operator>[ =<>])(?<value>.*)/
      |> Regex.named_captures(key)

    case reg do
      nil ->
        {:ok, {key, "=", value}}

      %{"key" => k, "operator" => o, "value" => v} ->
        validate_param_type(k, o, v, field_types)
    end
  end

  # Validate type based on the schema's field types
  defp validate_param_type(key, operator, value, field_types) do
    expected_type = Map.get(field_types, String.to_atom(key))

    case {expected_type, parse_value(value, expected_type)} do
      {nil, _} -> {:error, "Unknown field #{key}"}
      {_, :error} -> {:error, "Invalid value for #{key}. Expected a #{expected_type}."}
      {_, parsed_value} -> {:ok, {key, operator, parsed_value}}
    end
  end

  # Parse the value based on expected type
  defp parse_value(value, :integer) do
    case Integer.parse(value) do
      {v, ""} -> v
      _ -> :error
    end
  end

  defp parse_value(value, :string), do: value
end

defmodule ${e}.Plugs.ListAsJSON do
  @moduledoc """
  A plug for controllers that allows lists to be sent as top-level JSON arrays
  without needing to wrap them in an object. It detects the "_json" param and
  elevates it to the top level.
  """

  def init(options), do: options

  def call(%Plug.Conn{params: %{"_json" => json_data}} = conn, _opts) do
    %{conn | params: json_data}
  end

  def call(conn, _opts), do: conn
end
`;return s({dir:o,filename:"dynamic_query.ex",content:r},"gen_dynamic_query_util")};var Ke=async({AppNameCamel:e,LibDir:t})=>{let o=i(t||"","/lib/utils"),r=`
defmodule ${e}.Utils.MapUtil do
  def get(map, key, default \\\\ nil),
    do: Map.get(map, key, false) || Map.get(map, Atom.to_string(key), default)

  def str_to_atom(map),
    do:
      Map.keys(map)
      |> Enum.reduce(%{}, fn key, acc -> Map.put(acc, to_atom(key), Map.get(map, key)) end)

  defp to_atom(string) when is_binary(string), do: String.to_atom(string)
  defp to_atom(atom) when is_atom(atom), do: atom

  def id_list_from(list) when is_list(list) do
    Enum.map(list, fn 
      s when is_binary(s) -> s; 
      m when is_map(m) -> get(m, :id);
    end)
  end
end
`;return s({dir:o,filename:"map.ex",content:r},"gen_map_util")};var Ye=async({AppNameCamel:e,LibDir:t})=>{let o=i(t||"","/lib/utils"),r=`
defmodule ${e}.Utils.Paginate do
  @doc """
  Utility functions for pagination with Scriniver Lib.
  """

  def apply(query, repo, pagination_options \\\\ %{}) do
    page = repo.paginate(query, default(pagination_options))
    res = page |> Map.get(:entries)
    params = Map.drop(page, [:entries])

    {:ok, res, Map.from_struct(params)}
  end

  def default(opts) do
    %{
      page: 1,
      page_size: 100,
      max_page_size: 1000
    }
    |> Map.merge(opts)
  end

  def split_page_opts(opts) do
    page_opts = ["page", "page_size", "max_page_size", "filter", "select", "sort"]

    {Map.drop(opts, page_opts), Map.take(opts, page_opts)}
  end
end
`;return s({dir:o,filename:"paginate.ex",content:r},"gen_paginate_util")};var He=async e=>Promise.all([We(e),Ge(e),Ye(e),Ke(e)]);var Je=_(require("path"));var Ve=async({AppNameSnake:e,UmbrellaDir:t})=>{let o=Je.default.join(t,"mix.exs"),r=[["AFTER",/apps_path\:\s\"apps\"\,/,`
  apps: [:${e}, :${e}_web],`]];return p({file:o,injections:r},"inject_app_declarations")};var Xe=_(require("path"));var Qe=async({AppNameSnake:e,UmbrellaDir:t})=>{let o=Xe.default.join(t,"mix.exs"),r=[["BEFORE",/defp\s+aliases\s+do[\s\n]+\[/,`
  defp npm_install(_) do
    Mix.shell().cmd("npm install", cd: "apps/${e}_ui")
  end


`],["AFTER",/defp\s+aliases\s+do[\s\n]+\[/,`
"deps.get": ["deps.get", &npm_install/1],`]];return p({file:o,injections:r},"inject_deps_get_aliases_to_mix_exs")};var Ze=_(require("path"));var et=async({AppNameSnake:e,UmbrellaDir:t})=>{let o=Ze.default.join(t,"config/dev.exs"),r=[["BEFORE",/config\s*:\w+\s*,\s*\w+\.\s*Endpoint\s*,/,`config :${e}, CORSPlug, origin: "*"
`],["REPLACE",/(?<=config\s+:\w+,\s+\w+\.Repo,(\n\s+\w+:\s+[^\n]+){0,10}\n\s+database:\s+\")[^\n]+(?=\",)/,"postgres"]];return p({file:o,injections:r},"inject_dev_config")};var U=_(require("path"));var So=async({WebDir:e})=>{let t=U.default.join(e,"mix.exs"),o=[["AFTER",/defp\sdeps\sdo\s*\n{0,5}\s*\[/,`
      {:cors_plug, "~> 2.0"},
`]];return p({file:t,injections:o},"inject_web_app_deps")},Io=async({UmbrellaDir:e})=>{let t=U.default.join(e,"mix.exs");return p({file:t,injections:[]},"inject_app_deps")},To=async({LibDir:e})=>{let t=U.default.join(e,"mix.exs"),o=[["AFTER",/defp\sdeps\sdo\s*\n{0,5}\s*\[/,`
{:scrivener, "~> 2.7"}, {:scrivener_ecto, "~> 3.0"}, {:phoenix, "~> 1.7.14"}, {:jason, "~> 1.2"}, {:dns_cluster, "~> 0.1.1"}, {:phoenix_pubsub, "~> 2.1"}, 
`]];return p({file:t,injections:o},"inject_app_deps")},tt=async e=>Promise.all([So(e),To(e),Io(e)]);var ot=_(require("path"));var rt=async({LibDir:e,AppNameSnake:t})=>{let o=ot.default.join(e||".",`lib/${t}/repo.ex`),r=[["BEFORE",/end[\s\n]*$/,`  use Scrivener
`]];return p({file:o,injections:r},"inject_scrinever")};var nt=async({WebDir:e,AppNameCamel:t,AppNameSnake:o})=>{let r=i(e||"",`lib/${o}_web/endpoint.ex`),n=[["AFTER",/\s*use\sPhoenix.Endpoint,\sotp_app:\s:\w+_web/gm,`
socket "/socket", ${t}Web.UserSocket,
  websocket: true,
  longpoll: false
`]];return p({file:r,injections:n},"inject_socket_to_endpoint")};var it=_(require("path"));var st=async({AppNameSnake:e,WebDir:t})=>{let o=it.default.join(t,`lib/${e}_web/endpoint.ex`),r=[["BEFORE",/plug\sPlug\.MethodOverride/,`plug CORSPlug, origin: Application.compile_env(:${e}, CORSPlug)[:origin]
`]];return p({file:o,injections:r},"inject_web_endpoint")};var at=_(require("path"));var ct=async({WebDir:e,AppNameSnake:t})=>{let o=at.default.join(e||".",`lib/${t}_web/router.ex`),r=[["REPLACE",/.*/gms,n=>q({str:n,type:"ROUTER"},"EX")]];return p({file:o,injections:r},"mark_router")};var pt=async({AppNameSnake:e,LibDir:t})=>{let o=i(t,"/lib/mix/tasks/"),r=`
defmodule Mix.Tasks.CustomFormatter do
  use Mix.Task

  def run(args \\\\ []) do
    IO.puts("Immutable Formatter")

    {js_paths, ex_paths} =
      Enum.split_with(args, fn path ->
        String.contains?(path, "apps/${e}_ui") || String.ends_with?(path, ".ts") ||
          String.ends_with?(path, ".tsx")
      end)

    js_paths = Enum.map(js_paths, &String.replace(&1, ~r/(.*){0,1}apps\\/${e}_ui\\//, ""))

    IO.puts("Formatting Elixir files...")
    Mix.Task.run("format", ex_paths)

    IO.puts("Formatting TS files...")
    format_react_files(js_paths)

    IO.puts("Complete.")
  end

  defp format_react_files(paths) do
    js_paths = Enum.join(paths, " ")

    {_result, 0} =
      System.cmd("bash", ["-c", "npm run format #{js_paths}"], cd: "./apps/${e}_ui")

    # IO.puts(result)
  end
end
`;return s({dir:o,filename:"custom_formatter.ex",content:r},"gen_custom_formatter")};var lt=_(require("path"));var mt=async({LibDir:e})=>{let t=lt.default.join(e,"mix.exs"),o=[["AFTER",/defp\s+aliases\s+do[\s\n]+\[/s,`
format: "custom_formatter",`]];return p({file:t,injections:o},"inject_custom_format_to_mix_exs")};var dt=async e=>{let t=pt(e),o=mt(e);return[t,o].flat()};var ut=async({AppNameCamel:e,AppNameSnake:t,LibDir:o})=>{let r=i(o,"/lib/mix/tasks"),n=`defmodule ${e}.Tasks.ExportConfig do
  # Values in these config groups will be passed to React as environment variables
  @configs [:ui]


  def generate_env_file(env_path) do
    env_path = env_path |> Path.join(".env")
    env_path |> Path.dirname() |> File.mkdir_p!()

    configs = @configs |> Enum.map(fn c ->
        (Application.get_env(:${t}, c) || [])
        |> Enum.map(fn {k, v} -> {c, k, v} end)
    end)
    |> List.flatten()

    env_content =
      configs
      |> Enum.map(fn {group, key, value} ->
        name_key = [group, key] |> Enum.map(fn s -> to_string(s) |> String.upcase() end) |> Enum.join("_")
        env_key = ("VITE_" <> name_key)
        env_value = encode_value(value)
        "#{env_key}=#{env_value}"
      end)
      |> Enum.join("
")

    File.write!(env_path, env_content <> "\\n")
  end

  defp encode_value(value) when is_binary(value), do: value
  defp encode_value(value) when is_atom(value), do: Atom.to_string(value)
  defp encode_value(value) when is_map(value), do: Jason.encode!(value)
  defp encode_value(value), do: to_string(value)
end`;return s({dir:r,filename:"export_config.ex",content:n},"gen_config_export")};var ft=async({AppNameSnake:e,AppNameCamel:t,LibDir:o})=>{let r=i(o,"/lib/mix/tasks"),n=`
defmodule Mix.Tasks.Compile.CustomCompiler do
  use Mix.Task.Compiler

  @impl Mix.Task.Compiler
  def run(_args) do
    %{${e}: app_path} = Mix.Project.deps_paths()

    ui_path =
      Path.join([app_path, "./..", "${e}_ui"])
      |> Path.expand()

    ${t}.Tasks.ExportConfig.generate_env_file(ui_path)

    case System.cmd("npm", ["run", "build", "--emptyOutDir"], stderr_to_stdout: true, cd: ui_path) do
      {output, 0} ->
        IO.puts(output)
        {:ok, []}
      {output, _exit_code} ->
        IO.puts(:stderr, output)
        {:error, []}
    end
  end

  @impl Mix.Task.Compiler
  def manifests, do: []
end
`;return s({dir:r,filename:"custom_compiler.ex",content:n},"gen_custom_compiler")};var _t=async({AppNameSnake:e,AppNameCamel:t,WebDir:o})=>{let r=i(o,`/lib/${e}_web/controllers`),n=`
defmodule ${t}Web.PageController do
  use ${t}Web, :controller

  def index(conn, _params) do
    # Serve the static index.html file
    conn
    |> put_resp_content_type("text/html")
    |> send_file(200, Path.join([:code.priv_dir(:${e}_web), "static", "index.html"]))
  end
end

`;return s({dir:r,filename:"page_controller.ex",content:n},"gen_page_controller")};var ee=_(require("path"));var Co=async({WebDir:e})=>{let t=ee.default.join(e,"mix.exs"),o=[["AFTER",/def\sproject\s+do[\s\n]+\[/,`compilers: Mix.compilers() ++ [:custom_compiler],
`]];return p({file:t,injections:o},"inject_custom_compile_to_web_mix_exs")},Oo=async({UmbrellaDir:e})=>{let t=ee.default.join(e,"mix.exs"),o=[["AFTER",/def\sproject\s+do[\s\n]+\[/,`compilers: Mix.compilers() ++ [:custom_compiler],
`]];return p({file:t,injections:o},"inject_custom_compile_to_mix_exs")},gt=async e=>Promise.all([Oo(e),Co(e)]);var ht=_(require("path"));var xt=async({AppNameSnake:e,AppNameCamel:t,WebDir:o})=>{let r=ht.default.join(o,`lib/${e}_web/router.ex`),n=[["BEFORE",/pipeline\s+\:api\s+do/,`
  scope "/", ${t}Web do
    get "/", PageController, :index
  end
`]];return p({file:r,injections:n},"inject_page_to_router")};var yt=_(require("path"));var bt=async({AppNameSnake:e,WebDir:t})=>{let o=yt.default.join(t,`lib/${e}_web/endpoint.ex`),r=[["REPLACE",/(?<=plug\(Plug\.Static\,.*only:\s)[^\n]*/s,"~w(assets fonts images js css vite.svg index.html)"]];return p({file:o,injections:r},"inject_static_output_to_endpoint")};var vt=async e=>{let t=await _t(e),o=await bt(e),r=await xt(e),n=await ft(e),a=await ut(e),m=await gt(e);return[t,o,r,n,a,m].flat()};var kt=async e=>{let{AppNameSnake:t,UmbrellaDir:o}=e;l({level:2,color:"BLUE"},`
Generating Phoenix project...`);let r=await j({command:`yes | mix phx.new ${t} --no-live --no-html --no-assets --binary-id --umbrella --no-install`,dir:i(o,"..")},"init_phoenix_umbrella_app"),n=await Ve(e),a=await Promise.all([tt(e),st(e),et(e),rt(e),He(e),Be(e),Ne(e),ct(e),Le(e),Oe(e)]),m=await vt(e),g=await dt(e),y=await Qe(e),b=await ze(e),v=await nt(e);return[r,n,a,m,g,y,v,b].flat()};var jt=({LibDir:e})=>{let t="styles.css",o=i(e,"lib/typescript/components");return s({filename:t,dir:o,content:`.form-container {
  max-width: 400px;
  margin: 2rem auto;
  padding: 2rem;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.12);
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
}

.form-container form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  flex: 1;
}
.form-container h4,
.form-container label {
  color: #000;
}

.form-container input,
.form-container textarea,
.form-container select {
  padding: 0.7rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 1rem;
}

.form-submit-btn {
  align-self: center;
  padding: 0.9rem 2.5rem;
  background: linear-gradient(90deg, #4f8cff 0%, #235390 100%);
  color: #000;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(79,140,255,0.15);
  cursor: pointer;
  transition: background 0.2s, transform 0.2s;
  margin-top: 1.5rem;
}

.form-submit-btn:hover {
  background: linear-gradient(90deg, #235390 0%, #4f8cff 100%);
  transform: translateY(-2px) scale(1.03);
}

.styled-list {
  width: 100%;
  max-width: 400px;
  margin: 2rem auto;
  padding: 0;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.08);
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  list-style: none;
}

.styled-list-item {
  padding: 0.7rem 1rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 1rem;
  margin: 0 0.5rem;
  transition: box-shadow 0.2s, border-color 0.2s;
  box-shadow: 0 1px 4px rgba(79,140,255,0.07);
  display: flex;
  align-items: center;
}

.styled-list-item:hover {
  border-color: #4f8cff;
  box-shadow: 0 2px 8px rgba(79,140,255,0.15);
}

.channel-status-container {
  max-width: 400px;
  margin: 2rem auto;
  padding: 2rem;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.12);
  font-size: 1.1rem;
  font-weight: 500;
  text-align: center;
  color: #000;
  transition: background 0.2s, border 0.2s, box-shadow 0.2s;
}

.channel-status-connected {
  background: #7fffaf;
  border: 2px solid #137a2b;
  box-shadow: 0 4px 24px rgba(19, 122, 43, 0.18);
}

.channel-status-disconnected {
  background: #a9002a;
  border: 2px solid #ff4d6d;
  box-shadow: 0 4px 24px rgba(255, 77, 109, 0.18);
  color: #fff;
}`})};var wt=async({UiDir:e,AppNameCaps:t})=>{let o="index.html",r=`<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/react.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${t} - Immutable Project</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`;return s({filename:o,dir:e,content:r},"gen_index_html")};var Et=async({AppNameSnake:e,UiDir:t})=>{let o=`
export default {
    globals: {
        "ts-jest": {
        tsconfig: "<rootDir>/../${e}_ui/tsconfig.app.json",
        },
    },
    preset: "ts-jest",
    testEnvironment: "jsdom",
    moduleNameMapper: {
      "^@utils/(.*)$": "<rootDir>/../${e}/lib/typescript/utils/$1",
      "^@state/(.*)$": "<rootDir>/../${e}/lib/typescript/state/$1",
      "^@requests/(.*)$": "<rootDir>/../${e}/lib/typescript/requests/$1",
      "^@components/(.*)$": "<rootDir>/../${e}/lib/typescript/components/$1",
    },
    setupFilesAfterEnv: ["<rootDir>/jest.setup.js"],
    roots: ["<rootDir>", "../${e}/lib/typescript/state"],
  };
        `;return s({dir:t,filename:"jest.config.js",content:o},"gen_jest_config")},$t=async({UiDir:e})=>s({dir:e,filename:"jest.setup.js",content:`
require("@testing-library/jest-dom");
            `},"gen_jest_setup");var Rt=async({LibDir:e})=>{let t=i(e,"/lib/typescript/utils/");return s({dir:t,filename:"lorem.ts",content:`
import { LoremIpsum } from "lorem-ipsum";

const Lorem = new LoremIpsum();
export default Lorem;
`},"gen_lorem_utils")};var At=async({LibDir:e})=>{let t=i(e,"lib/typescript/requests");return s({dir:t,filename:"index.tsx",content:`
import type { Dispatch } from "redux";
import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import merge from "deepmerge";

const API_URL = (import.meta as any).env["VITE_UI_API_URL"] || "http://localhost:4000/api/"

interface GenericAppState {
  RequestsStore: RequestsStoreState;
  [key: string]: any;
}

type AppRequest = {
  name: string;
  request: Promise<any>;
  details: requestAPIinterface;
};

interface RequestsStoreState {
  activeRequests: {
    [key: string]: object;
  };
}

const initialRequestsState: RequestsStoreState = {
  activeRequests: {},
};

const requestSlice = createSlice({
  name: "requests",
  initialState: initialRequestsState,
  reducers: {
    addRequest(
      state: RequestsStoreState,
      { payload }: PayloadAction<AppRequest>
    ) {
      state.activeRequests = {
        ...state.activeRequests,
        [payload.name]: payload.request,
      };
    },
    completeRequest(
      state: RequestsStoreState,
      { payload }: PayloadAction<string>
    ) {
      delete state.activeRequests[payload];
    },
  },
});
const requestReducer = requestSlice.reducer;

const isLoading = (state: GenericAppState, key: string | null = null) => {
  const requests = state.requestsStore.activeRequests;
  return key ? !!requests[key] : !!Object.keys(requests).length;
};

type requestAPIinterface = {
  name: string;
  route: string;
  options?: RequestInit;
  callback?: Function;
};
const defaultOptions = {
  method: "GET",
  headers: {
    "Content-Type": "application/json",
  },
};

const API = async (details: requestAPIinterface, dispatch: Dispatch) => {
  const { name, route, options, callback } = details;
  const FULL_URL = new URL(route, API_URL)
  const req = new Promise<any>(async (resolve, reject) => {

    const handleError = (err: string, rej: Function) => {
      console.error(err);
      rej(err);
      dispatch(completeRequest(name));
    };
    const handleSuccess = (data: any, res: Function) => {
      if (callback) callback(data);
      res(data);
      dispatch(completeRequest(name));
    };

    try {
      const reqOptions = merge(defaultOptions, options || {});

      const res = await fetch(FULL_URL, reqOptions)
        .catch((err) => handleError(String(err), reject));

      if (!res?.ok)
        handleError(
          \`\${FULL_URL} request failed: \${res?.status}\\n\${res?.statusText}\`,
          reject
        );

      handleSuccess(await res?.json(), resolve);
    } catch (error) {
      handleError(String(error), reject);
    }
  });

  dispatch(addRequest({ name, details, request: req }));
  return (await req).data;
};

const Request = { API };

export const { addRequest, completeRequest } = requestSlice.actions;
export type { AppRequest, RequestsStoreState, requestAPIinterface, GenericAppState };
export {
  initialRequestsState,
  requestReducer,
  isLoading,
  Request,
};
export default requestSlice;
`},"gen_request_lib")};var Dt=async({LibDir:e,AppNameSnake:t})=>{let o=i(e,"lib/typescript/utils");return s({filename:"PhoenixSocketContext.tsx",dir:o,content:`import { createContext, useContext, useEffect, useState } from "react";
import { Socket } from "phoenix";

const SOCKET_URL =
  (import.meta as any).env["VITE_UI_SOCKET_URL"] ||
  "ws://localhost:4000/socket";
const TOKEN = "";

type PhoenixSocketContextType = {
  socket: Socket | null;
  connected: boolean;
};

const PhoenixSocketContext = createContext<PhoenixSocketContextType>({
  socket: null,
  connected: false,
});

export const usePhoenixSocket = () => useContext(PhoenixSocketContext);

type Props = {
  children: React.ReactNode;
};

export const PhoenixSocketProvider = ({ children }: Props) => {
  const [connected, setConnected] = useState(false);
  const [socket, setSocket] = useState<Socket | null>(null);

  useEffect(() => {
    const socketInstance = new Socket(SOCKET_URL, {
      params: { TOKEN },
    });

    socketInstance.connect();
    setSocket(socketInstance);

    socketInstance.onOpen(() => setConnected(true));
    socketInstance.onClose(() => setConnected(false));
    socketInstance.onError(() => setConnected(false));

    return () => {
      socketInstance.disconnect();
    };
  }, []);

  return (
    <PhoenixSocketContext.Provider value={{ socket, connected }}>
      {children}
    </PhoenixSocketContext.Provider>
  );
};`},"gen_socket_context")};var Pt=async({AppNameCamel:e,UiDir:t})=>{let o=i(t,"/src/store"),r=`
import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { requestReducer } from "@requests/index"; 
import type { RequestsStoreState } from "@requests/index";


type ${e}State = {
    requestsStore: RequestsStoreState;
};

const ${e}Store = configureStore({
  reducer: combineReducers({
    requestsStore: requestReducer,
  }),
      middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoredActionPaths: ['payload.details.callback', 'payload.request'],
      ignoredPaths: ["requestsStore.activeRequests"],
    },
  }),
    // devTools: {
    // actionsDenylist: ['add_request', 'complete_request'],
    // },
});

export { ${e}Store };
export type { ${e}State };
        `;return s({dir:o,filename:"index.tsx",content:r},"gen_store")};var St=_(require("path"));var It=async({AppNameSnake:e,UiDir:t})=>{let o=St.default.join(t,"package.json"),r=[["AFTER",/\"scripts\":\s+\{/,`
    "postinstall": "ln -sf $(pwd)/node_modules ../${e}/lib/typescript/node_modules",`]];return p({file:o,injections:r},"inject_package_scripts")};var Tt=_(require("path"));var Ct=async({UiDir:e})=>{let t=Tt.default.join(e,"package.json"),o=[["AFTER",/\"scripts\":\s+\{/,'"test": "jest",'],["AFTER",/\"dependencies\":\s+\{/,`
    "@reduxjs/toolkit": "^2.3.0",
    "@types/react-redux": "^7.1.34",
    "deepmerge": "^4.3.1",
    "react-redux": "^9.1.2",
    "mincurrypipe": "^3.0.0",
    "phoenix": "^1.7.21",`],["AFTER",/\"devDependencies\":\s+\{/,`
    "@babel/plugin-transform-private-property-in-object": "^7.25.9",
    "@types/node": "^22.10.0",
    "lorem-ipsum": "^2.0.8",
    "@types/phoenix": "^1.6.6",
    "@testing-library/jest-dom": "^6.6.3",
    "@testing-library/react": "^16.3.0",
    "@testing-library/user-event": "^14.6.1",
    "@types/jest": "^29.5.14",
    "jest": "^29.7.0",
    "jest-environment-jsdom": "^29.7.0",
    "ts-jest": "^29.3.2",`]];return p({file:t,injections:o},"inject_react_deps")};var Ot=_(require("path"));var Lt=async({AppNameCamel:e,UiDir:t})=>{let o=Ot.default.join(t,"src/App.tsx"),r=[["BEFORE",/import\s+['"]\.\/App\.css['"]/,`
import { Provider } from 'react-redux';
 import { ${e}Store } from './store';
`],["AFTER",/return \(/,`
<Provider store={${e}Store}>
`],["BEFORE",/\)\s*;\s*\}\s*export default App/m,`
</Provider>
`]];return p({file:o,injections:r},"inject_redux_provider")};var Ft=_(require("path"));var qt=async({AppNameCamel:e,UiDir:t})=>{let o=Ft.default.join(t,"src/App.tsx"),r=[["BEFORE",/import\s+['"]\.\/App\.css['"]/,`
import { PhoenixSocketProvider } from "@utils/PhoenixSocketContext";
`],["AFTER",/return \(/,`
<PhoenixSocketProvider>
`],["BEFORE",/\)\s*;\s*\}\s*export default App/m,`
</PhoenixSocketProvider>
`]];return p({file:o,injections:r},"inject_socket_provider")};var Ut=async e=>[await Promise.all([Pt(e),await Lt(e),qt(e),Rt(e),At(e),It(e),Ct(e),Et(e),$t(e),Dt(e),wt(e),jt(e)]).catch(console.error)].flat();var Mt=async({AppNameSnake:e,AppNameCamel:t,LibDir:o})=>{let r=i(o,"/lib/mix/processes/"),n=`
defmodule ${t}.ViteDevSupervisor do
  use GenServer

  @vite_dev_cmd ["run", "dev", "--prefix", "apps/${e}_ui/"]
  @timeout_sec 5
  @type state :: %{
          vite_server: nil | Port.t(),
          existing_vite_pids: [Integer.t()],
          timeout: nil | PID.t()
        }
  @init_state %{vite_server: nil, existing_vite_pids: [], timeout: nil}

  def init_state(map) when is_map(map), do: Map.merge(@init_state, map)

  def start_link(_), do: GenServer.start(__MODULE__, nil, name: __MODULE__)

  @impl true
  def init(_) do
    existing_vite_pids = get_vite_processes()
    Process.flag(:trap_exit, true)
    Process.link(self())

    Process.whereis(:vite_server) |> kill

    state =
      %{existing_vite_pids: existing_vite_pids}
      |> init_state()
      |> restart_timeout()

    Process.send_after(self(), :restart, @timeout_sec * 1000)
    {:ok, state}
  end

  @impl true
  # Polling mechanism
  def handle_info(:restart, state) do
    Process.send_after(self(), :restart, @timeout_sec * 1000)
    {:noreply, restart_timeout(state)}
  end

  @impl true
  # Forward Vite console output
  def handle_info({_port, {:data, msg}}, state) do
    IO.puts(msg)
    {:noreply, state}
  end

  @impl true
  # Ignore Process exit
  def handle_info({:EXIT, _port, :normal}, state), do: {:noreply, state}

  @impl true
  # Catch all unhandled info, print, and force error
  def handle_info(msg, state) do
    IO.inspect({msg, state}, label: :error_unhandled_info)
    {:error, :unhandled_info}
  end

  defp restart_timeout(state = %{vite_server: port, timeout: timeout}) do
    case [port, timeout] do
      [nil, nil] ->
        state
        |> start_dev_server()
        |> start_timeout()

      [nil, _] ->
        state
        |> cancel_timeout()
        |> start_dev_server()
        |> start_timeout()

      [_, nil] ->
        state
        |> start_timeout()

      [_, _] ->
        state
        |> cancel_timeout()
        |> start_timeout()
    end
  end

  defp start_dev_server(state) do
    port =
      {:spawn_executable, System.find_executable("npm")}
      |> Port.open([:binary, args: @vite_dev_cmd])

    Process.register(port, :vite_server)
    Process.link(port)

    %{state | vite_server: port}
  end

  defp start_timeout(state = %{existing_vite_pids: pids}) do
    spawned_vite_pids =
      get_vite_processes()
      |> Enum.filter(fn pid -> pid not in pids end)

    kill_cmd = fn pid -> "kill -9 #{pid}" end
    kill_vite_pids = spawned_vite_pids |> Enum.map(&kill_cmd.(&1)) |> Enum.join(" & ")

    full_cmd =
      "sleep #{@timeout_sec + 0.15} ; #{kill_vite_pids} #ViteTimeout"

    %{state | timeout: Task.async(fn -> {_, 0} = System.cmd("bash", ["-c", full_cmd]) end)}
  end

  defp cancel_timeout(state = %{timeout: timeout}) do
    Task.shutdown(timeout)

    case System.cmd("bash", [
           "-c",
           "ps aux | grep 'ViteTimeout' | grep -v grep | awk '{print $2}'"
         ]) do
      {timeout_pids, 0} ->
        timeout_pids
        |> String.split("
")
        |> Enum.filter(fn s -> s not in ["", nil] end)
        |> Enum.each(&kill/1)

      _ ->
        :ok
    end

    %{state | timeout: nil}
  end

  defp get_vite_processes do
    case System.cmd("pgrep", ["-af", "vite"]) do
      {output, 0} ->
        output
        |> String.split("
")
        |> Enum.map(&String.trim/1)
        |> Enum.filter(fn string -> string != "" end)

      _ ->
        []
    end
  end

  defp get_pid(nil), do: {:error, :cannot_be_nil}
  defp get_pid(port) when is_port(port), do: Port.info(port)[:os_pid]
  defp get_pid(key) when is_atom(key), do: Process.whereis(key)

  defp kill(nil), do: {:error, :cannot_be_nil}
  defp kill(pid) when is_integer(pid) or is_binary(pid), do: System.cmd("kill", ["-9", pid])
  defp kill(port) when is_port(port), do: port |> get_pid |> kill
  defp kill(pid) when is_pid(pid), do: Process.exit(pid, :kill)
end
`;return s({dir:r,filename:"vite_dev_supervisor.ex",content:n},"gen_vite_supervisor")};var Nt=async({UiDir:e})=>{let t="App.css",o=i(e,"/src/");return s({filename:t,dir:o,content:`#root {
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;
  text-align: center;
  font-family: Copperplate, "Copperplate Gothic Bold",
    "Copperplate Gothic Light", "Arial Black", Arial, sans-serif;
  color: #fff;
}

.banner {
  height: 400px;
}

h1 {
  background: linear-gradient(90deg, #ff4500, #61dafb);
  background-clip: border-box;
  background-clip: border-box;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-shadow: 1px 1px 2px #b300ff, 0 0 2px #61dafb;
  font-size: 110px;
}

.logo {
  will-change: filter, transform;
  transition: filter 300ms, transform 300ms;
}

.logo.react:hover {
  filter: drop-shadow(0 0 4em #61dafbaa);
}

.logo.phoenix:hover {
  filter: drop-shadow(0 0 6em #ff4500);
  animation: logo-spin-reverse 1s linear infinite;
}

@keyframes logo-spin {
  from {
    transform: translate(-50%, -50%) rotate(0deg);
  }
  to {
    transform: translate(-50%, -50%) rotate(360deg);
  }
}

@keyframes logo-spin-reverse {
  from {
    transform: translate(-50%, -50%) rotate(0deg);
  }
  to {
    transform: translate(-50%, -50%) rotate(-360deg);
  }
}

@keyframes logo-shadow-pulse {
  0% {
    filter: drop-shadow(0 0 2em #61dafbaa);
  }
  50% {
    filter: drop-shadow(0 0 2em #ff4500);
  }
  100% {
    filter: drop-shadow(0 0 2em #61dafbaa);
  }
}

@media (prefers-reduced-motion: no-preference) {
  .logo.react {
    animation: logo-spin 20s linear infinite,
      logo-shadow-pulse 5s ease-in-out infinite;
  }
}

.logo-overlay-container {
  position: absolute;
  width: 300px;
  height: 300px;
  display: block;
  top: 110%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.logo.react,
.logo.phoenix {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  max-width: 100%;
  max-height: 100%;
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  object-fit: contain;
}

.logo.react {
  z-index: 1;
  width: 65%;
  height: 65%;
}

.logo.phoenix {
  z-index: 2;
}`},"gen_app_css")};var Bt=async({UiDir:e})=>{let t="App.tsx",o=i(e,"/src/");return s({filename:t,dir:o,content:`import reactLogo from "./assets/react.svg";
import immutablelogo from "./assets/logo3.png";
import "./App.css";

function App() {
  return (
    <a href="https://github.com/macioa/immutablestack" target="_blank" className="banner">
      <h1>Immutable Stack</h1>
      <span className="logo-overlay-container">
        <img src={reactLogo} className="logo react" alt="React logo" />
        <img
          src={immutablelogo}
          className="logo phoenix"
          alt="Immutable logo"
        />
      </span>
    </a>
  );
}

export default App;`},"gen_app_tsx")};var zt=_(require("path"));var Wt=async({AppNameSnake:e,AppNameCamel:t,WebDir:o})=>{let r=zt.default.join(o,`lib/${e}_web/application.ex`),n=[["REPLACE",new RegExp(`${t}Web\\.Endpoint\\n\\s+\\]`),`
      ${t}Web.Endpoint,
      (if (Mix.env() == :dev), do: {${t}.ViteDevSupervisor, []})
    ]
    |> Enum.filter(&(&1 != nil))
`]];return p({file:r,injections:n},"inject_vite_supervisor_to_application_ex")};var te=_(require("path"));var Lo=async(e,t)=>{let o=te.default.join(t,"vite.config.ts"),r=[["AFTER",/export\s+default\s+defineConfig\(\{[\s\n]+plugins\:\s+\[react\(\)\]\,/,`

  resolve: {
    alias: {
      '@utils': path.resolve(__dirname, '../${e}/lib/typescript/utils'),
      '@state': path.resolve(__dirname, '../${e}/lib/typescript/state'),
      '@requests': path.resolve(__dirname, '../${e}/lib/typescript/requests'),
      '@components': path.resolve(__dirname, '../${e}/lib/typescript/components'),
      '@test': path.resolve(__dirname, 'src/test')
    }
  },
`],["BEFORE",/import\s+react/,`import path from 'path';
`]];return p({file:o,injections:r},"inject_viteconfig")},Fo=async(e,t)=>{let o=te.default.join(t,"tsconfig.app.json"),r=[["AFTER",/"compilerOptions":\s+\{/,`

  "baseUrl": "../../",
  "paths": {
    "@utils/*": ["apps/${e}/lib/typescript/utils/*"],
    "@state/*": ["apps/${e}/lib/typescript/state/*"],
    "@requests/*": ["apps/${e}/lib/typescript/requests/*"],
    "@components/*": ["apps/${e}/lib/typescript/components/*"]
  },
`]];return p({file:o,injections:r},"inject_tsconfig")},Gt=async({AppNameSnake:e,UiDir:t})=>Promise.all([Lo(e,t),Fo(e,t)]);var Kt=_(require("path"));var Yt=async({AppNameSnake:e,UiDir:t})=>{let o=Kt.default.join(t,"vite.config.ts"),r=[["AFTER",/export\s+default\s+defineConfig\(\{/,`

  build: {
    outDir: '../${e}_web/priv/static', // Output the build to priv/static/assets
    assetsDir: 'assets', 
  },
`]];return p({file:o,injections:r},"inject_vite_build_output")};var Ht=async e=>{let{AppNameSnake:t,AppDir:o}=e;l({level:1,color:"BLUE"},`
Generating React App: ${t}_ui with Vite ...`);let r=await j({command:`y | npx create-vite@6.5.0 ${t}_ui --template react-ts --no-install`,dir:o},"init_react_app_with_vite");return l({level:1,color:"BLUE"},`
Configuring Vite build output and aliases...`),[await Gt(e),await Yt(e),await Mt(e),await Wt(e),await Bt(e),await Nt(e)].flat()};var Jt=async({UmbrellaDir:e,AppNameSnake:t})=>{let o=i(e||"","mix.exs"),r=`
      releases: [
        your_release_name: [
          applications: [${t}_web: :permanent, ${t}: :permanent],
          include_erts: true,
          include_src: false
        ]
      ],
`,n=[["AFTER",/\s*def\s+project\s+do\s+\[/gm,r]];return p({file:o,injections:n},"inject_sample_release_mix")};se(5);var Vt=process.argv.slice(2);async function qo(){Vt.length<1&&(console.error(`Usage: node init_proj.js <project_name>
   Or: immutable -init <project_name>`),process.exit(1));let e=Vt[0].toLowerCase().replace(/[\s-]/g,"_").replace(/[^a-z0-9_]/g,""),t=we(e,!1);$e(t);let{AppNameSnake:o,UmbrellaDir:r}=t;l({level:1,color:"GREEN"},`

 Generating ${o} App with Immutable Stack

`),de(r);let n=await j({command:`mkdir -p ${o}_umbrella`,dir:r},"init_proj"),a=await Ce(t),m=await kt(t),g=await Ht(t),y=await ie(t),b=await Ut(t),v=await Jt(t);le(r,`init_project_${e}`),l({level:1,color:"BLUE"},`

 Retreiving dependencies for React and Phoenix...

`);let w=await j({command:"mix deps.get",dir:r},"init_proj");l({level:1,color:"BLUE"},`

 Compiling React and Phoenix...

`);let u=await j({command:"mix compile",dir:r},"init_proj");l({level:1,color:"GREEN"},`

Initialization Complete.

Generated ${e}_umbrella`)}qo().catch(console.error);
