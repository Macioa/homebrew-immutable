"use strict";var u=Object.create;var r=Object.defineProperty;var D=Object.getOwnPropertyDescriptor;var g=Object.getOwnPropertyNames;var f=Object.getPrototypeOf,d=Object.prototype.hasOwnProperty;var w=(m,t,e,p)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of g(t))!d.call(m,s)&&s!==e&&r(m,s,{get:()=>t[s],enumerable:!(p=D(t,s))||p.enumerable});return m};var y=(m,t,e)=>(e=m!=null?u(f(m)):{},w(t||!m||!m.__esModule?r(e,"default",{value:m,enumerable:!0}):e,m));var n=require("fs/promises"),b=y(require("path"));var N=3,_={GREEN:"\x1B[38;2;0;255;0m%s\x1B[0m",RED:"\x1B[38;2;255;0;0m%s\x1B[0m",YELLOW:"\x1B[38;2;255;255;0m%s\x1B[0m",BLUE:"\x1B[38;2;0;0;255m%s\x1B[0m",TEAL:"\x1B[38;2;0;255;255m%s\x1B[0m",PURPLE:"\x1B[38;2;255;0;255m%s\x1B[0m",TAN:"\x1B[38;2;210;180;140m%s\x1B[0m",PINK:"\x1B[38;2;255;0;127m%s\x1B[0m"};var x=async({level:m,color:t},...e)=>{if(m<=N)return e=t?[_[t],...e]:e,m<4&&process.stdout.write(`
`),m===1&&(process.stdout.write(`
`),e=e.map(p=>typeof p=="string"?`\x1B[1m${p}\x1B[0m`:p)),console.log(...e),m<3&&process.stdout.write(`
`),await C(m>=5?0:5-m)},C=m=>new Promise(t=>setTimeout(t,m*1e3));var a=require("fs"),L=(m,t=!0)=>{let e=process.cwd(),p=t?e:b.default.join(e,`${m}_umbrella`),s=b.default.join(p,"apps"),l=b.default.join(s,m),$=b.default.join(s,`${m}_ui`),A=b.default.join(s,`${m}_web`);return{AppDir:s,LibDir:l,UiDir:$,WebDir:A,UmbrellaDir:p}},U=m=>{let t=m?.replace(/([A-Z])/g,"_$1")?.toLowerCase()?.slice(1),e=t.toUpperCase();return{AppNameSnake:t,AppNameCaps:e,AppNameCamel:m}},E=m=>{let t=U(m),e=L(t.AppNameSnake);return{...t,...e}};var i=async function(){try{if(x({level:8},`Getting App Data from mix.exs in ${process.cwd()}`),!(0,a.existsSync)("mix.exs"))return null;let t=(await(0,n.readFile)("mix.exs","utf-8")).match(/(?<=defmodule\s+)\w+(?=\.Umbrella\.MixProject)/)?.[0]||"";return E(t)}catch(m){return console.error(`Could not get AppName from mix.exs
${m}`),null}},o=i();var c=()=>o||i();var P=async()=>{let{AppNameCamel:m,UmbrellaDir:t}=await c()||{},e=m,p=`${t}/`,s=`## back end folders:

* \x1B[33m\x1B[1mmigrations\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}/priv/repo/migrations\x1B[0m
* \x1B[33m\x1B[1mschemas\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}/lib/${e}\x1B[0m
* \x1B[33m\x1B[1mcontext\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}/lib\x1B[0m

## back end files:

* \x1B[33m\x1B[1mMix.Exs\x1B[0m\x1B[0m - \x1B[34m${p}/mix.exs\x1B[0m
* \x1B[33m\x1B[1mApplication.ex\x1B[0m\x1B[0m
  - \x1B[34m${p}apps/${e}/lib/${e}/application.ex\x1B[0m
  - \x1B[34m${p}apps/${e}_web/lib/${e}_web/application.ex\x1B[0m
* \x1B[33m\x1B[1mEndpoint.Exs\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}_web/lib/${e}_web/endpoint.ex\x1B[0m
* \x1B[33m\x1B[1mRouter.ex\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}_web/lib/${e}_web/router.ex\x1B[0m

## front end folders:

* \x1B[33m\x1B[1mcomponents\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}/lib/typescript/components\x1B[0m
* \x1B[33m\x1B[1mstate\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}/lib/typescript/state\x1B[0m
* \x1B[33m\x1B[1mrequest api\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}/lib/typescript/requests\x1B[0m

## front end files:

* \x1B[33m\x1B[1mpackage.json\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}_ui/package.json\x1B[0m
* \x1B[33m\x1B[1mApp.ts\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}_ui/src/App.tsx\x1B[0m
* \x1B[33m\x1B[1mStore\x1B[0m\x1B[0m - \x1B[34m${p}apps/${e}_ui/src/store/index.ts\x1B[0m`;console.log(s)};P().catch(console.error);
