"use strict";var le=Object.create;var I=Object.defineProperty;var ce=Object.getOwnPropertyDescriptor;var ue=Object.getOwnPropertyNames;var pe=Object.getPrototypeOf,me=Object.prototype.hasOwnProperty;var fe=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports);var he=(e,n,t,r)=>{if(n&&typeof n=="object"||typeof n=="function")for(let i of ue(n))!me.call(e,i)&&i!==t&&I(e,i,{get:()=>n[i],enumerable:!(r=ce(n,i))||r.enumerable});return e};var w=(e,n,t)=>(t=e!=null?le(pe(e)):{},he(n||!e||!e.__esModule?I(t,"default",{value:e,enumerable:!0}):t,e));var re=fe((S,O)=>{(function(e,n){typeof require=="function"&&typeof S=="object"&&typeof O=="object"?O.exports=n():typeof define=="function"&&define.amd?define(function(){return n()}):e.pluralize=n()})(S,function(){var e=[],n=[],t={},r={},i={};function a(o){return typeof o=="string"?new RegExp("^"+o+"$","i"):o}function l(o,s){return o===s?s:o===o.toLowerCase()?s.toLowerCase():o===o.toUpperCase()?s.toUpperCase():o[0]===o[0].toUpperCase()?s.charAt(0).toUpperCase()+s.substr(1).toLowerCase():s.toLowerCase()}function h(o,s){return o.replace(/\$(\d{1,2})/g,function(f,p){return s[p]||""})}function d(o,s){return o.replace(s[0],function(f,p){var m=h(s[1],arguments);return l(f===""?o[p-1]:f,m)})}function $(o,s,f){if(!o.length||t.hasOwnProperty(o))return s;for(var p=f.length;p--;){var m=f[p];if(m[0].test(s))return d(s,m)}return s}function b(o,s,f){return function(p){var m=p.toLowerCase();return s.hasOwnProperty(m)?l(p,m):o.hasOwnProperty(m)?l(p,o[m]):$(m,p,f)}}function U(o,s,f,p){return function(m){var C=m.toLowerCase();return s.hasOwnProperty(C)?!0:o.hasOwnProperty(C)?!1:$(C,C,f)===C}}function c(o,s,f){var p=s===1?c.singular(o):c.plural(o);return(f?s+" ":"")+p}return c.plural=b(i,r,e),c.isPlural=U(i,r,e),c.singular=b(r,i,n),c.isSingular=U(r,i,n),c.addPluralRule=function(o,s){e.push([a(o),s])},c.addSingularRule=function(o,s){n.push([a(o),s])},c.addUncountableRule=function(o){if(typeof o=="string"){t[o.toLowerCase()]=!0;return}c.addPluralRule(o,"$0"),c.addSingularRule(o,"$0")},c.addIrregularRule=function(o,s){s=s.toLowerCase(),o=o.toLowerCase(),i[o]=s,r[s]=o},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(o){return c.addIrregularRule(o[0],o[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(o){return c.addPluralRule(o[0],o[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(o){return c.addSingularRule(o[0],o[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(c.addUncountableRule),c})});var L=w(require("path")),z=(...e)=>{e.reduce((n,t)=>t?n:!1,!0)||console.error("Invalid Path",...e)},g=(...e)=>(z(...e),L.default.join(...e)),j=(...e)=>(z(...e),L.default.join(...e));var y=require("fs");var D=3,ge={GREEN:"\x1B[38;2;0;255;0m%s\x1B[0m",RED:"\x1B[38;2;255;0;0m%s\x1B[0m",YELLOW:"\x1B[38;2;255;255;0m%s\x1B[0m",BLUE:"\x1B[38;2;0;0;255m%s\x1B[0m",TEAL:"\x1B[38;2;0;255;255m%s\x1B[0m",PURPLE:"\x1B[38;2;255;0;255m%s\x1B[0m",TAN:"\x1B[38;2;210;180;140m%s\x1B[0m",PINK:"\x1B[38;2;255;0;127m%s\x1B[0m"},W=e=>(D=e,D),u=async({level:e,color:n},...t)=>{if(e<=D)return t=n?[ge[n],...t]:t,e<4&&process.stdout.write(`
`),e===1&&(process.stdout.write(`
`),t=t.map(r=>typeof r=="string"?`\x1B[1m${r}\x1B[0m`:r)),console.log(...t),e<3&&process.stdout.write(`
`),await de(e>=5?0:5-e)},de=e=>new Promise(n=>setTimeout(n,e*1e3));var E=require("child_process"),A=async e=>new Promise((n,t)=>{let r=e.endsWith(".tsx")||e.endsWith(".ts"),i=e.endsWith(".ex")||e.endsWith(".exs");r&&(0,E.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),i&&(0,E.execSync)(`mix format ${e}`,{stdio:"inherit"}),n(!0)});var q=require("fs");var T=(e,n=null)=>(Object.keys(e).forEach(t=>{let r=e[t];if(r==null)throw console.error(`${t} in StringOnlyMap cannot be null or undefined.
     Caller: ${n}`),`${t} in StringOnlyMap cannot be null or undefined. Caller: ${n}`}),!0),R=(e,n)=>n.reduce((t,r)=>t?.[r],e);var k=(e,n,t)=>{let r=n.pop(),i=R(e,n);i&&typeof i=="object"?i[r]=t:k(e,n,{[r]:t})};var P=null,_={_name:null,commands:[],file_modifications:{}};var F=({filename:e,dir:n},t=null)=>{T({filename:e,dir:n},t);let r=$e(n),{file_modifications:i}=_,a=r.split("/").filter(d=>d).concat([e]),h=(R(i,a)||[]).concat([t||"unreferenced"]);return k(_,["file_modifications",...a],h),_},G=(e,n)=>{_._name=n;let t=JSON.stringify(_,null,2);(0,q.writeFileSync)(j(e,`.immutable_history_${n}.json`),t,"utf8")},M=(e,n=null)=>{let t=e.split("/").filter(a=>a),r=t.slice(-1)[0],i=t.slice(0,-1).join("/");return F({filename:r,dir:i},n)},B=e=>{P=j(e).replace(/^[^\w]+/,"")},$e=e=>(e=e.replace(/^[^\w]+/,""),(P?e.replace(P,""):e).replace(/^[^\w]+/,""));var v=async({filename:e,dir:n,content:t},r=null)=>{try{F({filename:e,dir:n},r);let i=j(n),a=g(n,e);return r&&u({level:5,color:"TAN"},r),u({level:5},`Generating ${e} ...`),u({level:9},t),(0,y.mkdirSync)(i,{recursive:!0}),(0,y.existsSync)(a)&&(0,y.unlinkSync)(a),(0,y.writeFileSync)(a,t,"utf8"),await A(a),[a]}catch(i){throw new Error(`Error in ${r}`,{cause:i})}};var J=({singleUpperCamel:e,singleSnake:n},{LibDir:t})=>{let r=`${e}Channel.tsx`,i=g(t,"lib/typescript/components"),a=`import use${e}Channel from "../requests/${e}Channel"; // adjust path as needed
import { useEffect } from "react";
import "./styles.css";

export default function ${e}ChannelComponent() {
  const { channel, joined, error, push, on, off } =
    use${e}Channel("${n}:lobby");

  useEffect(() => {
    if (!joined || !channel) return;

    // Listen for a message
    on("quack", (payload) => {
      console.log("Received:", payload);
    });

    // Push a message to the channel
    push("croak", { frog: "Kermit" });

    // Clean up listener
    return () => {
      off("ribbit");
    };
  }, [joined, channel]);

  if (error) return <div>Error - {error}</div>;
  if (!joined) return <div>Joining channel...</div>;

  const statusClass = joined
    ? "channel-status-connected"
    : "channel-status-disconnected";

  return (
    <div className={\`channel-status-container \${statusClass}\`}>
      {error && <div>Error - {error}</div>}
      {!joined && !error && <div>Joining channel...</div>}
      {joined && !error && <div>${e} channel joined!</div>}
    </div>
  );
}`;return v({filename:r,dir:i,content:a},"gen_channel_demo_component")};var K=({singleSnake:e,singleUpperCamel:n},{WebDir:t,AppNameCamel:r})=>{let i=`${e}_channel.ex`,a=g(t,"lib/channels"),l=`defmodule ${r}Web.${n}Channel do
  use ${r}Web, :channel

  def join("${e}:" <> _room_id, _params, socket) do
    {:ok, socket}
  end

  def handle_in("message", %{"body" => body}, socket) do
    broadcast!(socket, "message", %{
      body: body,
    })

    {:noreply, socket}
  end
end`;return v({filename:i,dir:a,content:l},"gen_phx_channel")};var Y=({singleUpperCamel:e},{LibDir:n})=>{let t=`${e}Channel.ts`,r=g(n,"lib/typescript/requests"),i=`import { useEffect, useRef, useState } from "react";
import { Channel } from "phoenix";
import { usePhoenixSocket } from "../utils/PhoenixSocketContext";

export default function use${e}Channel(topic: string, params = {}) {
  const { socket, connected } = usePhoenixSocket();
  const [channel, setChannel] = useState<Channel | null>(null);
  const [joined, setJoined] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const channelRef = useRef<Channel | null>(null);

  useEffect(() => {
    if (!socket || !connected) return;

    const chan = socket.channel(topic, params);
    channelRef.current = chan;
    setChannel(chan);

    chan
      .join()
      .receive("ok", () => {
        console.log(\`[Phoenix] Channel joined: \${topic}\`);
        setJoined(true);
        setError(null);
      })
      .receive("error", (e) => {
        console.log(\`[Phoenix] Channel join error: \${topic}\`, e);
        setJoined(false);
        setError(e?.reason || "join error");
      });

    return () => {
      chan.leave();
    };
  }, [socket, connected, topic]);

  return {
    channel,
    joined,
    error,
    push: (event: string, payload: any) => channel?.push(event, payload),
    on: (event: string, callback: (payload: any) => void) =>
      channel?.on(event, callback),
    off: (event: string) => channel?.off(event),
  };
};`;return v({filename:t,dir:r,content:i},"gen_react_channel")};var N=w(require("fs"));var H=async({file:e,injections:n},t=null)=>{try{return t&&u({level:5,color:"TAN"},t),u({level:5},`Injecting into ${e} ...`),new Promise(async(r,i)=>{M(e,t);let l=N.default.readFileSync(e,"utf8");n.forEach(([h,d,$])=>{switch(u({level:7},`Injecting ${$} into ${e}`),u({level:9},"File: ",l),h){case"REPLACE":let b=typeof $=="function"?$(l):l.replace(d,$);if($&&(b==l||b=="")){Z(d,e,i);return}else u({level:8},`Found ${d} in ${e}`),l=b;break;default:l=ye(l,e,[h,d,$])||Z(d,e,i)}}),l.length?(N.default.writeFileSync(e,l,"utf8"),await A(e),r([e])):i(new Error(`Insertion failed for ${e}`))})}catch(r){throw new Error(`Error in ${t}`,{cause:r})}},Z=(e,n,t)=>(console.error(`${e} not found in the ${n} file.`),t(new Error(`Insertion failed for ${n}`)),""),ye=(e,n,[t,r,i])=>{let a=new RegExp(r.source,r.flags).exec(e);if(!a)return null;let l=a.index;if(u({level:8},`Found ${r} at ${l} in ${n}`),t==="AFTER")l+=a[0].length;else if(t!="BEFORE")return null;return e.slice(0,l)+i+e.slice(l)};var Q=async({singleUpperCamel:e,singleSnake:n},{WebDir:t,AppNameCamel:r})=>{let i=g(t||"","lib/channels/user_socket.ex"),a=`
channel "${n}:*", ${r}Web.${e}Channel
`,l=[["AFTER",/use\sPhoenix.Socket/gm,a]];return H({file:i,injections:l},"inject_channel_to_socket")};var X=require("fs/promises"),x=w(require("path"));var ee=require("fs"),be=(e,n=!0)=>{let t=process.cwd(),r=n?t:x.default.join(t,`${e}_umbrella`),i=x.default.join(r,"apps"),a=x.default.join(i,e),l=x.default.join(i,`${e}_ui`),h=x.default.join(i,`${e}_web`);return{AppDir:i,LibDir:a,UiDir:l,WebDir:h,UmbrellaDir:r}},ve=e=>{let n=e?.replace(/([A-Z])/g,"_$1")?.toLowerCase()?.slice(1),t=n.toUpperCase();return{AppNameSnake:n,AppNameCaps:t,AppNameCamel:e}},xe=e=>{let n=ve(e),t=be(n.AppNameSnake);return{...n,...t}};var ne=async function(){try{if(u({level:8},`Getting App Data from mix.exs in ${process.cwd()}`),!(0,ee.existsSync)("mix.exs"))return null;let n=(await(0,X.readFile)("mix.exs","utf-8")).match(/(?<=defmodule\s+)\w+(?=\.Umbrella\.MixProject)/)?.[0]||"";return xe(n)}catch(e){return console.error(`Could not get AppName from mix.exs
${e}`),null}},V=ne();var te=()=>V||ne();var se=w(re()),ae=e=>{if(!e)return null;let n=Ce(e),t=oe(e),r=ie(t),i=oe(n),a=ie(i),l=e[0],h=e.toUpperCase();return{singleSnake:e,pluralSnake:n,singleLowerCamel:r,singleUpperCamel:t,singleCAPS:h,pluralLowerCamel:a,pluralUpperCamel:i,singleChar:l}},Ce=e=>{let n=e.split("_"),t=(0,se.default)(n.pop()||"");return[...n,t].join("_")},oe=e=>e.split("_").map(n=>n.charAt(0).toUpperCase()+n.slice(1)).join(""),ie=e=>e.replace(e[0],e[0].toLowerCase());W(5);var je=async()=>{let e=process.argv.slice(2),n=ae(e[0]),t=await te();e.length<1&&(console.error("Please provide a channel name as an argument."),process.exit(1)),B(t.UmbrellaDir),u({level:1,color:"GREEN"},`

 Generating ${n.singleSnake} Channel...

`);let r=await Promise.all([K(n,t),Y(n,t),Q(n,t),J(n,t)]);G(t.UmbrellaDir,`generate_${n.singleSnake}_channel`),u({level:1,color:"GREEN"},`

 ${n.singleUpperCamel} Channel Complete

`)};je().catch(console.error);
