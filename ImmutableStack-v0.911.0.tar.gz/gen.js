"use strict";var En=Object.create;var ue=Object.defineProperty;var An=Object.getOwnPropertyDescriptor;var On=Object.getOwnPropertyNames;var In=Object.getPrototypeOf,Sn=Object.prototype.hasOwnProperty;var A=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Qe=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let i of On(t))!Sn.call(e,i)&&i!==r&&ue(e,i,{get:()=>t[i],enumerable:!(n=An(t,i))||n.enumerable});return e};var S=(e,t,r)=>(r=e!=null?En(In(e)):{},Qe(t||!e||!e.__esModule?ue(r,"default",{value:e,enumerable:!0}):r,e)),Tn=e=>Qe(ue({},"__esModule",{value:!0}),e);var lt=A((Ee,Ae)=>{(function(e,t){typeof require=="function"&&typeof Ee=="object"&&typeof Ae=="object"?Ae.exports=t():typeof define=="function"&&define.amd?define(function(){return t()}):e.pluralize=t()})(Ee,function(){var e=[],t=[],r={},n={},i={};function s(m){return typeof m=="string"?new RegExp("^"+m+"$","i"):m}function o(m,_){return m===_?_:m===m.toLowerCase()?_.toLowerCase():m===m.toUpperCase()?_.toUpperCase():m[0]===m[0].toUpperCase()?_.charAt(0).toUpperCase()+_.substr(1).toLowerCase():_.toLowerCase()}function a(m,_){return m.replace(/\$(\d{1,2})/g,function(b,v){return _[v]||""})}function c(m,_){return m.replace(_[0],function(b,v){var h=a(_[1],arguments);return o(b===""?m[v-1]:b,h)})}function l(m,_,b){if(!m.length||r.hasOwnProperty(m))return _;for(var v=b.length;v--;){var h=b[v];if(h[0].test(_))return c(_,h)}return _}function d(m,_,b){return function(v){var h=v.toLowerCase();return _.hasOwnProperty(h)?o(v,h):m.hasOwnProperty(h)?o(v,m[h]):l(h,v,b)}}function $(m,_,b,v){return function(h){var I=h.toLowerCase();return _.hasOwnProperty(I)?!0:m.hasOwnProperty(I)?!1:l(I,I,b)===I}}function f(m,_,b){var v=_===1?f.singular(m):f.plural(m);return(b?_+" ":"")+v}return f.plural=d(i,n,e),f.isPlural=$(i,n,e),f.singular=d(n,i,t),f.isSingular=$(n,i,t),f.addPluralRule=function(m,_){e.push([s(m),_])},f.addSingularRule=function(m,_){t.push([s(m),_])},f.addUncountableRule=function(m){if(typeof m=="string"){r[m.toLowerCase()]=!0;return}f.addPluralRule(m,"$0"),f.addSingularRule(m,"$0")},f.addIrregularRule=function(m,_){_=_.toLowerCase(),m=m.toLowerCase(),i[m]=_,n[_]=m},[["I","we"],["me","us"],["he","they"],["she","they"],["them","them"],["myself","ourselves"],["yourself","yourselves"],["itself","themselves"],["herself","themselves"],["himself","themselves"],["themself","themselves"],["is","are"],["was","were"],["has","have"],["this","these"],["that","those"],["echo","echoes"],["dingo","dingoes"],["volcano","volcanoes"],["tornado","tornadoes"],["torpedo","torpedoes"],["genus","genera"],["viscus","viscera"],["stigma","stigmata"],["stoma","stomata"],["dogma","dogmata"],["lemma","lemmata"],["schema","schemata"],["anathema","anathemata"],["ox","oxen"],["axe","axes"],["die","dice"],["yes","yeses"],["foot","feet"],["eave","eaves"],["goose","geese"],["tooth","teeth"],["quiz","quizzes"],["human","humans"],["proof","proofs"],["carve","carves"],["valve","valves"],["looey","looies"],["thief","thieves"],["groove","grooves"],["pickaxe","pickaxes"],["passerby","passersby"]].forEach(function(m){return f.addIrregularRule(m[0],m[1])}),[[/s?$/i,"s"],[/[^\u0000-\u007F]$/i,"$0"],[/([^aeiou]ese)$/i,"$1"],[/(ax|test)is$/i,"$1es"],[/(alias|[^aou]us|t[lm]as|gas|ris)$/i,"$1es"],[/(e[mn]u)s?$/i,"$1s"],[/([^l]ias|[aeiou]las|[ejzr]as|[iu]am)$/i,"$1"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1i"],[/(alumn|alg|vertebr)(?:a|ae)$/i,"$1ae"],[/(seraph|cherub)(?:im)?$/i,"$1im"],[/(her|at|gr)o$/i,"$1oes"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|automat|quor)(?:a|um)$/i,"$1a"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)(?:a|on)$/i,"$1a"],[/sis$/i,"ses"],[/(?:(kni|wi|li)fe|(ar|l|ea|eo|oa|hoo)f)$/i,"$1$2ves"],[/([^aeiouy]|qu)y$/i,"$1ies"],[/([^ch][ieo][ln])ey$/i,"$1ies"],[/(x|ch|ss|sh|zz)$/i,"$1es"],[/(matr|cod|mur|sil|vert|ind|append)(?:ix|ex)$/i,"$1ices"],[/\b((?:tit)?m|l)(?:ice|ouse)$/i,"$1ice"],[/(pe)(?:rson|ople)$/i,"$1ople"],[/(child)(?:ren)?$/i,"$1ren"],[/eaux$/i,"$0"],[/m[ae]n$/i,"men"],["thou","you"]].forEach(function(m){return f.addPluralRule(m[0],m[1])}),[[/s$/i,""],[/(ss)$/i,"$1"],[/(wi|kni|(?:after|half|high|low|mid|non|night|[^\w]|^)li)ves$/i,"$1fe"],[/(ar|(?:wo|[ae])l|[eo][ao])ves$/i,"$1f"],[/ies$/i,"y"],[/\b([pl]|zomb|(?:neck|cross)?t|coll|faer|food|gen|goon|group|lass|talk|goal|cut)ies$/i,"$1ie"],[/\b(mon|smil)ies$/i,"$1ey"],[/\b((?:tit)?m|l)ice$/i,"$1ouse"],[/(seraph|cherub)im$/i,"$1"],[/(x|ch|ss|sh|zz|tto|go|cho|alias|[^aou]us|t[lm]as|gas|(?:her|at|gr)o|[aeiou]ris)(?:es)?$/i,"$1"],[/(analy|diagno|parenthe|progno|synop|the|empha|cri|ne)(?:sis|ses)$/i,"$1sis"],[/(movie|twelve|abuse|e[mn]u)s$/i,"$1"],[/(test)(?:is|es)$/i,"$1is"],[/(alumn|syllab|vir|radi|nucle|fung|cact|stimul|termin|bacill|foc|uter|loc|strat)(?:us|i)$/i,"$1us"],[/(agend|addend|millenni|dat|extrem|bacteri|desiderat|strat|candelabr|errat|ov|symposi|curricul|quor)a$/i,"$1um"],[/(apheli|hyperbat|periheli|asyndet|noumen|phenomen|criteri|organ|prolegomen|hedr|automat)a$/i,"$1on"],[/(alumn|alg|vertebr)ae$/i,"$1a"],[/(cod|mur|sil|vert|ind)ices$/i,"$1ex"],[/(matr|append)ices$/i,"$1ix"],[/(pe)(rson|ople)$/i,"$1rson"],[/(child)ren$/i,"$1"],[/(eau)x?$/i,"$1"],[/men$/i,"man"]].forEach(function(m){return f.addSingularRule(m[0],m[1])}),["adulthood","advice","agenda","aid","aircraft","alcohol","ammo","analytics","anime","athletics","audio","bison","blood","bream","buffalo","butter","carp","cash","chassis","chess","clothing","cod","commerce","cooperation","corps","debris","diabetes","digestion","elk","energy","equipment","excretion","expertise","firmware","flounder","fun","gallows","garbage","graffiti","hardware","headquarters","health","herpes","highjinks","homework","housework","information","jeans","justice","kudos","labour","literature","machinery","mackerel","mail","media","mews","moose","music","mud","manga","news","only","personnel","pike","plankton","pliers","police","pollution","premises","rain","research","rice","salmon","scissors","series","sewage","shambles","shrimp","software","species","staff","swine","tennis","traffic","transportation","trout","tuna","wealth","welfare","whiting","wildebeest","wildlife","you",/pok[eé]mon$/i,/[^aeiou]ese$/i,/deer$/i,/fish$/i,/measles$/i,/o[iu]s$/i,/pox$/i,/sheep$/i].forEach(f.addUncountableRule),f})});var ke=A(P=>{"use strict";Object.defineProperty(P,"__esModule",{value:!0});P.FORMAT_PLAIN=P.FORMAT_HTML=P.FORMATS=void 0;var vr="html";P.FORMAT_HTML=vr;var xr="plain";P.FORMAT_PLAIN=xr;var Ws=[vr,xr];P.FORMATS=Ws});var Tr=A(O=>{"use strict";Object.defineProperty(O,"__esModule",{value:!0});O.UNIT_WORDS=O.UNIT_WORD=O.UNIT_SENTENCES=O.UNIT_SENTENCE=O.UNIT_PARAGRAPHS=O.UNIT_PARAGRAPH=O.UNITS=void 0;var Rr="words";O.UNIT_WORDS=Rr;var Er="word";O.UNIT_WORD=Er;var Ar="sentences";O.UNIT_SENTENCES=Ar;var Or="sentence";O.UNIT_SENTENCE=Or;var Ir="paragraphs";O.UNIT_PARAGRAPHS=Ir;var Sr="paragraph";O.UNIT_PARAGRAPH=Sr;var ks=[Rr,Er,Ar,Or,Ir,Sr];O.UNITS=ks});var Be=A(Q=>{"use strict";Object.defineProperty(Q,"__esModule",{value:!0});Q.WORDS=void 0;var Bs=["ad","adipisicing","aliqua","aliquip","amet","anim","aute","cillum","commodo","consectetur","consequat","culpa","cupidatat","deserunt","do","dolor","dolore","duis","ea","eiusmod","elit","enim","esse","est","et","eu","ex","excepteur","exercitation","fugiat","id","in","incididunt","ipsum","irure","labore","laboris","laborum","Lorem","magna","minim","mollit","nisi","non","nostrud","nulla","occaecat","officia","pariatur","proident","qui","quis","reprehenderit","sint","sit","sunt","tempor","ullamco","ut","velit","veniam","voluptate"];Q.WORDS=Bs});var Mr=A(Z=>{"use strict";Object.defineProperty(Z,"__esModule",{value:!0});Z.LINE_ENDINGS=void 0;var Hs={POSIX:`
`,WIN32:`\r
`};Z.LINE_ENDINGS=Hs});var Pr=A(V=>{"use strict";Object.defineProperty(V,"__esModule",{value:!0});V.default=void 0;var zs=function(t){var r=t.trim();return r.charAt(0).toUpperCase()+r.slice(1)},Xs=zs;V.default=Xs});var wr=A((N,He)=>{"use strict";Object.defineProperty(N,"__esModule",{value:!0});N.default=void 0;var Ys=function(){return typeof He<"u"&&!!He.exports},Js=Ys;N.default=Js});var Dr=A(ee=>{"use strict";Object.defineProperty(ee,"__esModule",{value:!0});ee.default=void 0;var Ks=function(){var t=!1;try{t=navigator.product==="ReactNative"}catch{t=!1}return t},Qs=Ks;ee.default=Qs});var Cr=A(te=>{"use strict";Object.defineProperty(te,"__esModule",{value:!0});te.SUPPORTED_PLATFORMS=void 0;var Zs={DARWIN:"darwin",LINUX:"linux",WIN32:"win32"};te.SUPPORTED_PLATFORMS=Zs});var Fr=A(re=>{"use strict";Object.defineProperty(re,"__esModule",{value:!0});re.default=void 0;var Vs=Cr(),Ns=function(){var t=!1;try{t=process.platform===Vs.SUPPORTED_PLATFORMS.WIN32}catch{t=!1}return t},ei=Ns;re.default=ei});var ze=A(ne=>{"use strict";Object.defineProperty(ne,"__esModule",{value:!0});ne.default=void 0;var ti=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:0;return Array.apply(null,Array(t)).map(function(r,n){return n})},ri=ti;ne.default=ri});var qr=A(se=>{"use strict";Object.defineProperty(se,"__esModule",{value:!0});se.default=void 0;var ni=si(ze());function si(e){return e&&e.__esModule?e:{default:e}}var ii=function(t,r){var n=(0,ni.default)(t);return n.map(function(){return r()})},oi=ii;se.default=oi});var Xe=A(w=>{"use strict";Object.defineProperty(w,"__esModule",{value:!0});Object.defineProperty(w,"capitalize",{enumerable:!0,get:function(){return ai.default}});Object.defineProperty(w,"isNode",{enumerable:!0,get:function(){return ci.default}});Object.defineProperty(w,"isReactNative",{enumerable:!0,get:function(){return pi.default}});Object.defineProperty(w,"isWindows",{enumerable:!0,get:function(){return li.default}});Object.defineProperty(w,"makeArrayOfLength",{enumerable:!0,get:function(){return mi.default}});Object.defineProperty(w,"makeArrayOfStrings",{enumerable:!0,get:function(){return di.default}});var ai=H(Pr()),ci=H(wr()),pi=H(Dr()),li=H(Fr()),mi=H(ze()),di=H(qr());function H(e){return e&&e.__esModule?e:{default:e}}});var jr=A(oe=>{"use strict";Object.defineProperty(oe,"__esModule",{value:!0});oe.default=void 0;var ui=Be(),Ye=Xe();function _i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function Gr(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function fi(e,t,r){return t&&Gr(e.prototype,t),r&&Gr(e,r),Object.defineProperty(e,"prototype",{writable:!1}),e}function ie(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var $i=function(){function e(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=t.sentencesPerParagraph,n=r===void 0?{max:7,min:3}:r,i=t.wordsPerSentence,s=i===void 0?{max:15,min:5}:i,o=t.random,a=t.seed,c=t.words,l=c===void 0?ui.WORDS:c;if(_i(this,e),ie(this,"sentencesPerParagraph",void 0),ie(this,"wordsPerSentence",void 0),ie(this,"random",void 0),ie(this,"words",void 0),n.min>n.max)throw new Error("Minimum number of sentences per paragraph (".concat(n.min,") cannot exceed maximum (").concat(n.max,")."));if(s.min>s.max)throw new Error("Minimum number of words per sentence (".concat(s.min,") cannot exceed maximum (").concat(s.max,")."));this.sentencesPerParagraph=n,this.words=l,this.wordsPerSentence=s,this.random=o||Math.random}return fi(e,[{key:"generateRandomInteger",value:function(r,n){return Math.floor(this.random()*(n-r+1)+r)}},{key:"generateRandomWords",value:function(r){var n=this,i=this.wordsPerSentence,s=i.min,o=i.max,a=r||this.generateRandomInteger(s,o);return(0,Ye.makeArrayOfLength)(a).reduce(function(c,l){return"".concat(n.pluckRandomWord()," ").concat(c)},"").trim()}},{key:"generateRandomSentence",value:function(r){return"".concat((0,Ye.capitalize)(this.generateRandomWords(r)),".")}},{key:"generateRandomParagraph",value:function(r){var n=this,i=this.sentencesPerParagraph,s=i.min,o=i.max,a=r||this.generateRandomInteger(s,o);return(0,Ye.makeArrayOfLength)(a).reduce(function(c,l){return"".concat(n.generateRandomSentence()," ").concat(c)},"").trim()}},{key:"pluckRandomWord",value:function(){var r=0,n=this.words.length-1,i=this.generateRandomInteger(r,n);return this.words[i]}}]),e}(),gi=$i;oe.default=gi});var Wr=A(pe=>{"use strict";Object.defineProperty(pe,"__esModule",{value:!0});pe.default=void 0;var ae=ke(),Ur=Mr(),yi=hi(jr()),ce=Xe();function hi(e){return e&&e.__esModule?e:{default:e}}function bi(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function Lr(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function vi(e,t,r){return t&&Lr(e.prototype,t),r&&Lr(e,r),Object.defineProperty(e,"prototype",{writable:!1}),e}function xi(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var Ri=function(){function e(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:ae.FORMAT_PLAIN,n=arguments.length>2?arguments[2]:void 0;if(bi(this,e),this.format=r,this.suffix=n,xi(this,"generator",void 0),ae.FORMATS.indexOf(r.toLowerCase())===-1)throw new Error("".concat(r," is an invalid format. Please use ").concat(ae.FORMATS.join(" or "),"."));this.generator=new yi.default(t)}return vi(e,[{key:"getLineEnding",value:function(){return this.suffix?this.suffix:!(0,ce.isReactNative)()&&(0,ce.isNode)()&&(0,ce.isWindows)()?Ur.LINE_ENDINGS.WIN32:Ur.LINE_ENDINGS.POSIX}},{key:"formatString",value:function(r){return this.format===ae.FORMAT_HTML?"<p>".concat(r,"</p>"):r}},{key:"formatStrings",value:function(r){var n=this;return r.map(function(i){return n.formatString(i)})}},{key:"generateWords",value:function(r){return this.formatString(this.generator.generateRandomWords(r))}},{key:"generateSentences",value:function(r){return this.formatString(this.generator.generateRandomParagraph(r))}},{key:"generateParagraphs",value:function(r){var n=this.generator.generateRandomParagraph.bind(this.generator);return this.formatStrings((0,ce.makeArrayOfStrings)(r,n)).join(this.getLineEnding())}}]),e}(),Ei=Ri;pe.default=Ei});var Br=A(J=>{"use strict";Object.defineProperty(J,"__esModule",{value:!0});Object.defineProperty(J,"LoremIpsum",{enumerable:!0,get:function(){return kr.default}});J.loremIpsum=void 0;var Ai=ke(),q=Tr(),Oi=Be(),kr=Ii(Wr());function Ii(e){return e&&e.__esModule?e:{default:e}}var Si=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},r=t.count,n=r===void 0?1:r,i=t.format,s=i===void 0?Ai.FORMAT_PLAIN:i,o=t.paragraphLowerBound,a=o===void 0?3:o,c=t.paragraphUpperBound,l=c===void 0?7:c,d=t.random,$=t.sentenceLowerBound,f=$===void 0?5:$,m=t.sentenceUpperBound,_=m===void 0?15:m,b=t.units,v=b===void 0?q.UNIT_SENTENCES:b,h=t.words,I=h===void 0?Oi.WORDS:h,G=t.suffix,z=G===void 0?"":G,de={random:d,sentencesPerParagraph:{max:l,min:a},words:I,wordsPerSentence:{max:_,min:f}},X=new kr.default(de,s,z);switch(v){case q.UNIT_PARAGRAPHS:case q.UNIT_PARAGRAPH:return X.generateParagraphs(n);case q.UNIT_SENTENCES:case q.UNIT_SENTENCE:return X.generateSentences(n);case q.UNIT_WORDS:case q.UNIT_WORD:return X.generateWords(n);default:return""}};J.loremIpsum=Si});var Zi={};module.exports=Tn(Zi);var _n=S(require("path"));var M=require("fs");var _e=S(require("path")),Ze=(...e)=>{e.reduce((t,r)=>r?t:!1,!0)||console.error("Invalid Path",...e)},y=(...e)=>(Ze(...e),_e.default.join(...e)),j=(...e)=>(Ze(...e),_e.default.join(...e));var fe=3,Mn={GREEN:"\x1B[38;2;0;255;0m%s\x1B[0m",RED:"\x1B[38;2;255;0;0m%s\x1B[0m",YELLOW:"\x1B[38;2;255;255;0m%s\x1B[0m",BLUE:"\x1B[38;2;0;0;255m%s\x1B[0m",TEAL:"\x1B[38;2;0;255;255m%s\x1B[0m",PURPLE:"\x1B[38;2;255;0;255m%s\x1B[0m",TAN:"\x1B[38;2;210;180;140m%s\x1B[0m",PINK:"\x1B[38;2;255;0;127m%s\x1B[0m"},Ve=e=>(fe=e,fe),p=async({level:e,color:t},...r)=>{if(e<=fe)return r=t?[Mn[t],...r]:r,e<4&&process.stdout.write(`
`),e===1&&(process.stdout.write(`
`),r=r.map(n=>typeof n=="string"?`\x1B[1m${n}\x1B[0m`:n)),console.log(...r),e<3&&process.stdout.write(`
`),await $e(e>=5?0:5-e)},$e=e=>new Promise(t=>setTimeout(t,e*1e3));var ge=require("child_process"),K=async e=>new Promise((t,r)=>{let n=e.endsWith(".tsx")||e.endsWith(".ts"),i=e.endsWith(".ex")||e.endsWith(".exs");n&&(0,ge.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),i&&(0,ge.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)});var Ne=require("fs");var u=(e,t=null)=>(Object.keys(e).forEach(r=>{let n=e[r];if(n==null)throw console.error(`${r} in StringOnlyMap cannot be null or undefined.
     Caller: ${t}`),`${r} in StringOnlyMap cannot be null or undefined. Caller: ${t}`}),!0),ye=(e,t)=>t.reduce((r,n)=>r?.[n],e);var he=(e,t,r)=>{let n=t.pop(),i=ye(e,t);i&&typeof i=="object"?i[n]=r:he(e,t,{[n]:r})};var be=null,U={_name:null,commands:[],file_modifications:{}},et=({command:e,dir:t},r=null)=>{U.commands.push({command:e,dir:t,caller:r||"unreferenced"})},ve=({filename:e,dir:t},r=null)=>{u({filename:e,dir:t},r);let n=Pn(t),{file_modifications:i}=U,s=n.split("/").filter(c=>c).concat([e]),a=(ye(i,s)||[]).concat([r||"unreferenced"]);return he(U,["file_modifications",...s],a),U},tt=(e,t)=>{U._name=t;let r=JSON.stringify(U,null,2);(0,Ne.writeFileSync)(j(e,`.immutable_history_${t}.json`),r,"utf8")},rt=(e,t=null)=>{let r=e.split("/").filter(s=>s),n=r.slice(-1)[0],i=r.slice(0,-1).join("/");return ve({filename:n,dir:i},t)},nt=e=>{be=j(e).replace(/^[^\w]+/,"")},Pn=e=>(e=e.replace(/^[^\w]+/,""),(be?e.replace(be,""):e).replace(/^[^\w]+/,""));var R=async({filename:e,dir:t,content:r},n=null)=>{try{ve({filename:e,dir:t},n);let i=j(t),s=y(t,e);return n&&p({level:5,color:"TAN"},n),p({level:5},`Generating ${e} ...`),p({level:9},r),(0,M.mkdirSync)(i,{recursive:!0}),(0,M.existsSync)(s)&&(0,M.unlinkSync)(s),(0,M.writeFileSync)(s,r,"utf8"),await K(s),[s]}catch(i){throw new Error(`Error in ${n}`,{cause:i})}};var it=require("fs/promises"),L=S(require("path"));var ot=require("fs"),wn=(e,t=!0)=>{let r=process.cwd(),n=t?r:L.default.join(r,`${e}_umbrella`),i=L.default.join(n,"apps"),s=L.default.join(i,e),o=L.default.join(i,`${e}_ui`),a=L.default.join(i,`${e}_web`);return{AppDir:i,LibDir:s,UiDir:o,WebDir:a,UmbrellaDir:n}},Dn=e=>{let t=e?.replace(/([A-Z])/g,"_$1")?.toLowerCase()?.slice(1),r=t.toUpperCase();return{AppNameSnake:t,AppNameCaps:r,AppNameCamel:e}},Cn=e=>{let t=Dn(e),r=wn(t.AppNameSnake);return{...t,...r}};var at=async function(){try{if(p({level:8},`Getting App Data from mix.exs in ${process.cwd()}`),!(0,ot.existsSync)("mix.exs"))return null;let t=(await(0,it.readFile)("mix.exs","utf-8")).match(/(?<=defmodule\s+)\w+(?=\.Umbrella\.MixProject)/)?.[0]||"";return Cn(t)}catch(e){return console.error(`Could not get AppName from mix.exs
${e}`),null}},st=at();var W=()=>st||at();var pt=require("child_process"),F=require("crypto"),T=require("fs"),C=require("os");var Y=".immutable",Re=Wn(),xe=function(){return new Promise((e,t)=>(0,pt.exec)("brew --prefix immutable",(r,n,i)=>e(n.trim())))}();async function Fn(e){p({level:38},"Hashing file",{dir:await xe});let t=(0,F.createHash)("sha256");p({level:38},"Hashing file",{filePath:e}),p({level:38},"Hashing file",{dir:y(await xe,"bin/"+e)});let r=(0,T.createReadStream)(y(await xe,"bin/"+e));return new Promise((n,i)=>{r.on("data",s=>t.update(s)),r.on("end",()=>{p({level:38},"Hashed file",{hash:t}),n(t.digest("hex"))}),r.on("error",s=>i(s))})}async function qn(e,t=(0,F.createHash)("sha256").update(e).digest()){return{key:t.slice(0,32),iv:t.slice(16,32)}}async function Gn(e){return Object.keys(e).forEach(async t=>e[t]=Fn(e[t])),await Promise.all(Object.values(e)),p({level:38},"Salted files",e),JSON.stringify({home:(0,C.homedir)(),...e})}var ct=({key:e,iv:t},r,n=(0,F.createCipheriv)("aes-256-cbc",e,t))=>Buffer.concat([n.update(r),n.final()]).toString("hex"),jn=({key:e,iv:t},r,n=(0,F.createDecipheriv)("aes-256-cbc",e,t))=>{try{return Buffer.concat([n.update(Buffer.from(r,"hex")),n.final()]).toString()}catch(i){return p({level:1,color:"RED"},"Decryption error",{err:i,message:"Wrong user or source code has changed",action:"Clear settings with immutable -settings -clear"}),null}},D={};var Un=async()=>{if(p({level:37},"Reading settings",{home:(0,C.homedir)(),SETTINGS:Y}),Object.keys(D).length)return D;if(!(0,T.existsSync)(y((0,C.homedir)(),Y)))return await Ln({}),{};let e=(0,T.readFileSync)(y((0,C.homedir)(),Y),"utf8");return D=JSON.parse(jn(await Re,e)||"{}"),D},Ln=async e=>{p({level:37},"Writing settings"),D=e;let t=JSON.stringify(e);return p({level:38},"Write Data",{home:(0,C.homedir)(),SETTINGS:Y,raw:t}),p({level:38},{SETTINGS_CACHE:D,body:ct(await Re,t)}),(0,T.writeFileSync)(y((0,C.homedir)(),Y),ct(await Re,t),"utf8")};var k=async e=>Un().then(()=>D[e]);async function Wn(){return await qn(await Gn({init:"init_proj.js",gen:"gen.js",repair:"repair.js",settings:"settings.js"}))}var ut=S(lt()),Oe=e=>{if(!e)return null;let t=kn(e),r=mt(e),n=dt(r),i=mt(t),s=dt(i),o=e[0],a=e.toUpperCase();return{singleSnake:e,pluralSnake:t,singleLowerCamel:n,singleUpperCamel:r,singleCAPS:a,pluralLowerCamel:s,pluralUpperCamel:i,singleChar:o}},kn=e=>{let t=e.split("_"),r=(0,ut.default)(t.pop()||"");return[...t,r].join("_")},mt=e=>e.split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(""),dt=e=>e.replace(e[0],e[0].toLowerCase());var _t="openai",Bn="https://api.openai.com/v1/chat/completions",Hn={model:"gpt-3.5-turbo",temperature:.2},zn=async({prompt:e,context:t,target:r,output:n})=>{let i={messages:[{role:"user",content:JSON.stringify({prompt:e}),name:"prompt"},{role:"user",content:JSON.stringify({target:r}),name:"target"},...t.map($=>({role:"assistant",content:JSON.stringify($),name:"associated_type_declarations$"})),...n.map(($,f)=>({role:"system",content:JSON.stringify({rule:$}),name:`output_rule_${f}`}))],...Hn};p({level:5},"Request",{...i});let o=await(await fetch(Bn,{method:"POST",headers:{Authorization:`Bearer ${await k(_t)}`,"Content-Type":"application/json"},body:JSON.stringify(i)})).json();p({level:3},"Response:",o?.choices);let{id:a,model:c,usage:l}=o,d=o?.choices[0].message.content?.replace(/^```typescript/g,"")?.replace(/```$/g,"");return{id:a,model:c,result:d,usage:l,api:_t}},ft=zn;var Xn={openai:ft},$t=Xn;var Yn=async function(){return $t[await k("llm")]}();var Uo=async function(){return await W()}();var Jn={EX:"#",JS:"//",TS:"//"};var x=({str:e,type:t,entity:r=""},n="TS")=>{let i=crypto.randomUUID(),s=`${Jn[n]} ** IMMUTABLE ${r} ${t} ${i} **`;return["",s,e,s,""].join(`
`)};var g=(e,t)=>{let r=t(e);p({level:6},"Generating header for:",r);let n="";return r.split(/[ \n]+do/)[0].replace(/(defp{0,1})(.*)/s,(i,s,o)=>n=o),n=n.replace(/,{0,1}\s*(do){0,1}$/,"").trim(),p({level:6},"Generated header:",n),n};var Kn=({pluralNameSnake:e},t)=>(u({pluralNameSnake:e},"comment_main"),`
  @doc """
    Create ${e} by id.

    ## Examples
    ${t}
    """
`),Qn=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"comment_many"),`
create_${e}(attrs) when is_list attrs -> Creates ${t} from an array of attrs.

  ## Examples
      iex> create_${e}([%{field: value}, %{field: value}])
      {:ok, [%${r}{}, %${r}{}]}
`),Zn=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"comment_single"),`
 create_${e}(attrs \\ %{}) -> Creates a ${e}.

  ## Examples
      iex> create_${e}(%{field: value})
      {:ok, %${t}{}}
      iex> create_${e}(%{field: bad_value})
      {:error, %Ecto.Changeset{}}
`),Ie=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"create_many"),`
  def create_${e}(attrs) when is_list(attrs) do
    attrs
    |> Chunk.apply(fn attr_chunk ->
      changesets = change_${e}(attr_chunk)

      case Enum.split_with(changesets, & &1.valid?) do
        {valid, []} ->
          created = Chunk.prep(valid)
          {_, result} = Repo.insert_all(${r}, created, returning: true)
          {:ok, result, []}

        {[], invalid} ->
          {:error, [], invalid}

        {valid, invalid} ->
          created = Chunk.prep(valid)
          {_, result} = Repo.insert_all(${r}, created, returning: true)
          {:partial_success, result, invalid}
      end
    end)
    |> Chunk.flat_reduce()
  end
`),Se=({genName:e})=>(u({genName:e},"create_single"),`
  def create_${e}(${e}_params) when is_map(${e}_params) do
    changeset = change_${e}(${e}_params)
    if changeset.valid?, do: Repo.insert(changeset), else: {:error, changeset}
  end
`),Vn=[{id:"create_many",fn:Ie,header:e=>g(e,Ie)},{id:"create_single",fn:Se,header:e=>g(e,Se)}],Nn={create_many:Qn,create_single:Zn},es={create_many:Ie,create_single:Se},gt=(e,t)=>{let r=Vn.map(({id:c,fn:l,header:d})=>({id:c,def:l(t),header:d(t)}));p({level:7},"Gen Create APIS",r);let i=r.filter(({header:c})=>e.includes(c)).map(({id:c})=>c||""),s=i.map(c=>Nn[c](t)).join(`
`),o=Kn(t,s),a=i.map(c=>es[c](t)).join(`
`);return{result:o+`
`+a,remaining_apis:e.filter(c=>!r.map(({header:l})=>l).includes(c))}};var ts=({header:e})=>(u({header:e},"custom"),`
    def ${e} do
        # TODO: Provide function definition here
    end
`),yt={id:"custom",fn:ts,header:({header:e})=>e};var rs=({pluralNameSnake:e},t)=>(u({pluralNameSnake:e},"comment_main"),`
  @doc """
    Delete ${e} by id.

    ## Examples
    ${t}
    """
`),ns=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"comment_many"),`
  ## Examples
      iex> delete_${e}([${e}, ${e}])
      {:ok, [%${t}{}, %${t}{}]}
`),ht=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"comment_single"),`
  ## Examples
      iex> delete_${e}(${e})
      {:ok, %${t}{}}
      iex> delete_${e}(${e})
      {:error, %Ecto.Changeset{}}
`),Te=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"delete_many"),`
  def delete_${e}(${t}) when is_list(${t}) do
    result =
      ${t}
      |> Chunk.apply(fn ${e}_chunk ->
        ids =
          Enum.map(${e}_chunk, fn
            id when is_binary(id) -> id
            ${e} when is_map(${e}) -> MapUtil.get(${e}, :id)
          end)

        {count, _} =
          from(b in ${r}, where: b.id in ^ids)
          |> Repo.delete_all()

        case count do
          0 -> {:error, 0, length(ids)}
          count when count == length(ids) -> {:ok, count, 0}
          _ -> {:partial_success, count, length(ids) - count}
        end
      end)
      |> Chunk.flat_reduce()

    if elem(result, 0) == :error,
      do: {:error, :not_found},
      else: result
  end
`),Me=({genName:e})=>(u({genName:e},"delete_single"),`
  def delete_${e}(${e}_params) when is_map(${e}_params), do:  MapUtil.get(${e}_params, :id) |> delete_${e}
`),Pe=({genName:e})=>(u({genName:e},"delete_single_by_id"),`
    def delete_${e}(id) when is_binary(id), do: get_${e}!(id) |> Repo.delete!    
    `),ss=[{id:"delete_many",fn:Te,header:e=>g(e,Te)},{id:"delete_single",fn:Me,header:e=>g(e,Me)},{id:"delete_single_by_id",fn:Pe,header:e=>g(e,Pe)}],is={delete_many:ns,delete_single:ht,delete_single_by_id:ht},os={delete_many:Te,delete_single:Me,delete_single_by_id:Pe},bt=(e,t)=>{let r=ss.map(({id:a,fn:c,header:l})=>({id:a,def:c(t),header:l(t)})).filter(({header:a})=>e.includes(a)),n=r.map(({id:a})=>a||""),i=n.map(a=>is[a](t)).join(`
`),s=rs(t,i),o=n.map(a=>os[a](t)).join(`
`);return{result:s+`
`+o,remaining_apis:e.filter(a=>!r.map(({header:c})=>c).includes(a))}};var as=({pluralNameSnake:e},t)=>(u({pluralNameSnake:e},"comment_main"),`
@doc """
    Retrieve ${e} by id.

    ## Examples
  ${t}
"""
  `),cs=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"comment_many"),`
    get_${e}!(ids) when is_list(ids) -> Gets specified ${t}.
    
    iex> get_${e}!([123, 456])
      [%${r}{}, %${r}{}]
      %${r}{}
`),vt=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"comment_single"),`
  get_${e}!(id) -> Gets a single ${e}.
      Raises \`Ecto.NoResultsError\` if the ${t} does not exist.

  ## Examples
      iex> get_${e}!(123)
      %${t}{}
      iex> get_${e}!(456)
      ** (Ecto.NoResultsError)    
`),we=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"get_many"),`
  def get_${e}!(${t}) when is_list(${t}) do
    ids =
      Enum.map(${t}, fn
        id when is_binary(id) -> id
        ${e} when is_map(${e}) -> MapUtil.get(${e}, :id)
      end)

    from(b in ${r}, where: b.id in ^ids)
    |> Repo.all()
  end
`),De=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"get_single"),`
  def get_${e}!(${e}_params) when is_map(${e}_params) do
    id = MapUtil.get(${e}_params, :id) 
    Repo.get!(${t}, id)
  end
    `),Ce=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"get_single_by_id"),`
  def get_${e}!(id) when is_binary(id), do: Repo.get!(${t}, id)    
`),ps=[{id:"get_many",fn:we,header:e=>g(e,we)},{id:"get_single",fn:De,header:e=>g(e,De)},{id:"get_single_by_id",fn:Ce,header:e=>g(e,Ce)}],ls={get_many:cs,get_single:vt,get_single_by_id:vt},ms={get_many:we,get_single:De,get_single_by_id:Ce},xt=(e,t)=>{let r=ps.map(({id:a,fn:c,header:l})=>({id:a,def:c(t),header:l(t)})).filter(({header:a})=>e.includes(a)),n=r.map(({id:a})=>a||""),i=n.map(a=>ls[a](t)).join(`
`),s=as(t,i),o=n.map(a=>ms[a](t)).join(`
`);return{result:s+`
`+o,remaining_apis:e.filter(a=>!r.map(({header:c})=>c).includes(a))}};var ds=({pluralNameSnake:e,genCamelName:t})=>(u({pluralNameSnake:e,genCamelName:t},"comment_standard"),`
@doc """
Returns the list of ${e}.

## Examples
    iex> list_${e}()
    [%${t}{}, ...]

"""
    `),Fe=({pluralNameSnake:e,genCamelName:t})=>(u({pluralNameSnake:e,genCamelName:t},"list_standard"),`
    def list_${e}(page_query \\\\ %{}), do: Paginate.apply(${t}, Repo, page_query)
    `),us=({pluralNameSnake:e,genCamelName:t})=>(u({pluralNameSnake:e,genCamelName:t},"comment_dynamic"),`
@doc """
Use a Dynamic Query to get a list of ${e} with specific values for any directly queryable fields.
"""
    `),qe=({pluralNameSnake:e,genCamelName:t})=>(u({pluralNameSnake:e,genCamelName:t},"list_dynamic"),`
def list_${e}_by(entity_queries, page_queries \\\\ %{}) do
  with {:ok, query, entity_queries} <- DynamicQuery.by_schema(entity_queries, ${t}),
       {:ok, result, page_queries} <- Paginate.apply(query, Repo, page_queries) do
    {:ok, result, Map.put(entity_queries, :page, page_queries)}
  end
end
`),_s=[{id:"list_standard",fn:Fe,header:e=>g(e,Fe)},{id:"list_dynamic",fn:qe,header:e=>g(e,qe)}],fs={list_standard:ds,list_dynamic:us},$s={list_standard:Fe,list_dynamic:qe},Rt=(e,t)=>{let r=_s.map(({id:i,fn:s,header:o})=>({id:i,def:s(t),header:o(t)})).filter(({header:i})=>e.includes(i));return{result:r.map(({id:i})=>i||"").map(i=>fs[i](t)+`
`+$s[i](t)).join(`
`),remaining_apis:e.filter(i=>!r.map(({header:s})=>s).includes(i))}};var gs=({pluralNameSnake:e},t)=>(u({pluralNameSnake:e},"comment_main"),`
  @doc """
    Update ${e} records.

    ## Examples
    ${t}
    """
`),ys=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"comment_many"),`
update_${e}(${t}) when is_list ${t} -> Updates ${t} with an array of tuples [{${e}, attrs}].

## Examples
    iex> update_${e}([{%{field: new_value}}, {%{field: new_value}}])
    {:ok, [%${r}{}, %${r}{}]}
`),hs=({genName:e,genCamelName:t})=>(u({genName:e,genCamelName:t},"comment_single"),`
update_${e}(%${t}{} = ${e}, attrs) -> Updates a ${e}.

## Examples
    iex> update_${e}(${e}, %{field: new_value})
    {:ok, %${t}{}}
    iex> update_${e}(${e}, %{field: bad_value})
    {:error, %Ecto.Changeset{}}
`),Ge=({genName:e,pluralNameSnake:t,genCamelName:r})=>(u({genName:e,pluralNameSnake:t,genCamelName:r},"update_many"),`
def update_${e}(${t}) when is_list(${t}) do
  ${t}
  |> Chunk.apply(fn ${e}_chunk ->
    multi =
      Multi.new()
      |> Multi.run(:initial_query, fn repo, _ ->
        requested_ids = Enum.map(${e}_chunk, &MapUtil.get(&1, :id))

        found_${t} = from(b in ${r}, where: b.id in ^requested_ids) |> repo.all()
        found_ids = Enum.map(found_${t}, & &1.id)
        unfound_ids = requested_ids -- found_ids

        {matched_attrs, unmatched_attrs} =
          Enum.split_with(${e}_chunk, fn attrs -> MapUtil.get(attrs, :id) not in unfound_ids end)

        changesets =
          Enum.zip(found_${t}, matched_attrs)
          |> Enum.map(fn {${e}, attrs} -> change_${e}(${e}, attrs) end)
          |> Enum.filter(& &1.valid?)

        {:ok, %{changesets: changesets, unmatched: unmatched_attrs}}
      end)
      |> Multi.run(:updates, fn repo, %{initial_query: query_res} ->
        %{
          changesets: changesets,
          unmatched: unmatched_attrs
        } = query_res

        {succeeded, failed_updates} =
          changesets
          |> Enum.map(&repo.update/1)
          |> Enum.reduce({[], []}, fn
            {:ok, ${e}}, {s, f} -> {[${e} | s], f}
            {_, changeset}, {s, f} -> [s, changeset | f]
          end)

        {:ok, %{succeeded: succeeded, failed: failed_updates ++ unmatched_attrs}}
      end)

    {:ok, %{updates: updates}} = Repo.transaction(multi)
    %{succeeded: succeeded, failed: failed} = updates

    case {succeeded, failed} do
      {succeeded, []} -> {:ok, succeeded, []}
      {[], failed} -> {:error, [], failed}
      {succeeded, failed} -> {:partial_success, succeeded, failed}
    end
  end)
  |> Chunk.flat_reduce()
end
`),je=({genName:e})=>(u({genName:e},"update_single"),`
def update_${e}(attrs) when is_map(attrs) do
  id = MapUtil.get(attrs, :id)

  if id == nil do
    create_${e}(attrs)
  else
    changeset =
      MapUtil.get(attrs, :id)
      |> get_${e}!()
      |> change_${e}(attrs)

    if changeset.valid?, do: Repo.update(changeset)
  end
end
`),bs=[{id:"update_many",fn:Ge,header:e=>g(e,Ge)},{id:"update_single",fn:je,header:e=>g(e,je)}],vs={update_many:ys,update_single:hs},xs={update_many:Ge,update_single:je},Et=(e,t)=>{let r=bs.map(({id:a,fn:c,header:l})=>({id:a,def:c(t),header:l(t)})).filter(({header:a})=>e.includes(a)),n=r.map(({id:a})=>a||""),i=n.map(a=>vs[a](t)).join(`
`),s=gs(t,i),o=n.map(a=>xs[a](t)).join(`
`);return{result:s+`
`+o,remaining_apis:e.filter(a=>!r.map(({header:c})=>c).includes(a))}};var Rs=(e,t)=>{p({level:7},"Requested Apis: ",e);let r=[gt,bt,xt,Rt,Et],{computed:n,remaining_apis:i}=r.reduce((o,a)=>{p({level:8},"APIFN REDUCER",o,a);let{computed:c,remaining_apis:l}=o;p({level:8},"APIFN COM",c),p({level:8},"APIFN REM",l),p({level:8},"APIFN RES",a(l,t));let{result:d,remaining_apis:$}=a(l,t);return{computed:c+x({str:d,entity:t.genCamelName,type:"CONTEXT"},"EX"),remaining_apis:$}},{computed:"",remaining_apis:e});p({level:7},"Computed Apis: ",n);let s=i.map(o=>yt.fn({header:o})).map(o=>x({str:o,entity:t.genCamelName,type:"CONTEXT"},"EX")).join(`
`);return n+`
`+s},At=async(e,t)=>{let{AppData:{AppNameCamel:r,LibDir:n},generate:i,name:s}=e,{singleSnake:o,singleUpperCamel:a,pluralUpperCamel:c,pluralSnake:l}=s,{name:d,apiFunctions:$}=i.context,f=y(n,"/lib/"),m=d.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g,"$1_$2").replace(/^_/,"").toLowerCase(),b=`
defmodule ${r}.${d} do
  @moduledoc """
  The ${d} context.
  """

  import Ecto.Query, warn: false

  alias Ecto.Multi
  alias ${r}.Repo
  alias ${r}.Utils.DynamicQuery
  alias ${r}.Utils.Paginate
  alias ${r}.Utils.Chunk
  alias ${r}.Utils.MapUtil

  alias ${r}.${a}

  ${Rs($,{camelName:d||"",genName:o,context:d||"",pluralNameSnake:l||"",pluralNameCamel:c||"",AppNameCamel:r||"",genCamelName:a||""})}

  @doc """
  change_${o}(${l}) when is_list ${l} -> Returns a list of \`%Ecto.Changeset{}\` for tracking ${o} changes

  ## Examples
      iex> change_${o}([{${o}1, attrs1}, {${o}2, attrs2}])
      %Ecto.Changeset{data: [%${a}{}, %${a}{}]}

  change_${o}(%${a}{} = ${o}, attrs \\\\ %{}) -> Returns \`%Ecto.Changeset{}\` for tracking ${o} changes.

  ## Examples
      iex> change_${o}(${o})
      %Ecto.Changeset{data: %${a}{}}

  """
  def change_${o}(attrs \\\\ %{})
  def change_${o}(attrs) when is_map(attrs), do: change_${o}(%${a}{}, attrs)

  def change_${o}(${l}) when is_list(${l}),
    do:
      Enum.map(${l}, fn
        {${o}, attr} -> change_${o}(${o}, attr)
        attr when is_map(attr) -> change_${o}(attr)
      end)

  def change_${o}(%${a}{} = ${o}, attrs), do: ${a}.changeset(${o}, attrs)
end
`;return R({dir:f,filename:`${m}.ex`,content:b},"gen_phx_context")};var Ot=({camelName:e,genLowerSnakePlural:t,genLowerSnake:r,genUpperCamel:n})=>(u({camelName:e,genLowerSnakePlural:t,genLowerSnake:r,genUpperCamel:n},"create_many_test"),`
  test "create_${r}/1 creates multiple ${t}" do
    operation = ${e}.create_${r}([@valid_attrs, @valid_attrs])
    assert {:ok, [%${n}{}, %${n}{}], []} = operation
  end

  test "create_${r}/1 creates some ${t} with partial success" do
    operation = ${e}.create_${r}([@valid_attrs, @invalid_attrs])
    assert {:partial_success, [%${n}{}], [%Ecto.Changeset{}]} = operation
  end
`),It=({camelName:e,genLowerSnake:t,genUpperCamel:r})=>(u({camelName:e,genLowerSnake:t,genUpperCamel:r},"create_single_test"),`
 test "create_${t}/1 creates a single ${t}" do
    operation = ${e}.create_${t}(@valid_attrs)
    assert {:ok, %${r}{}} = operation
  end
`),Es=[{id:"create_many_test",fn:Ot,header:({genLowerSnake:e})=>`create_${e}(attrs) when is_list(attrs)`},{id:"create_single_test",fn:It,header:({genLowerSnake:e})=>`create_${e}(${e}_params) when is_map(${e}_params)`}],As={create_many_test:Ot,create_single_test:It},St=(e,t)=>{let r=Es.map(({id:o,fn:a,header:c})=>({id:o,def:a(t),header:c(t)}));return p({level:7},"Gen Create API tests",r),{result:r.filter(({header:o})=>e.includes(o)).map(({id:o})=>o||"").map(o=>As[o](t)).join(`
`),remaining_apis:e.filter(o=>!r.map(({header:a})=>a).includes(o))}};var Tt=({genLowerSnake:e,camelName:t,genLowerSnakePlural:r,genUpperCamel:n})=>(u({genLowerSnake:e,camelName:t,genLowerSnakePlural:r,genUpperCamel:n},"get_many_test"),`
  test "get_${e}!/1 returns the ${r} with given ${r}" do
    {:ok, ${r}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs])
    valid_operation = ${t}.get_${e}!(${r})
    assert [%${n}{}, %${n}{}] = valid_operation
    retreived = ${t}.get_${e}!(${r} ++ [@fake_attrs])
    # should have one less ${e} than number of ids, since one id does not exist
    assert [%${n}{}, %${n}{}] = retreived
  end

  test "get_${e}!/1 returns the ${r} with given ids" do
    {:ok, ${r}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs])
    ${r} = ${r} |> Enum.map(&Map.get(&1, :id))
    valid_operation = ${t}.get_${e}!(${r})
    assert [%${n}{}, %${n}{}] = valid_operation
    retreived = ${t}.get_${e}!(${r} ++ [@fake_id])
    # should have one less ${e} than number of ids, since one id does not exist
    assert [%${n}{}, %${n}{}] = retreived
  end
`),Mt=({genLowerSnake:e,camelName:t,genUpperCamel:r})=>(u({genLowerSnake:e,camelName:t,genUpperCamel:r},"get_single_test"),`
  test "get_${e}!/1 returns the ${e} with given ${e}" do
    {:ok, ${e}} = ${t}.create_${e}(@valid_attrs)
    valid_operation = ${t}.get_${e}!(${e})
    assert %${r}{} = valid_operation

    assert_raise Ecto.NoResultsError, fn ->
      ${t}.get_${e}!(@fake_attrs)
    end
  end
    `),Pt=({genLowerSnake:e,camelName:t,genUpperCamel:r})=>(u({genLowerSnake:e,camelName:t,genUpperCamel:r},"get_single_by_id_test"),`
  test "get_${e}!/1 returns the ${e} with given id" do
    {:ok, ${e}} = ${t}.create_${e}(@valid_attrs)
    valid_operation = ${t}.get_${e}!(${e}.id)
    assert %${r}{} = valid_operation

    assert_raise Ecto.NoResultsError, fn ->
      ${t}.get_${e}!(@fake_id)
    end
  end  
`),Os=[{id:"get_many_test",fn:Tt,header:({genLowerSnake:e,genLowerSnakePlural:t})=>`get_${e}!(${t}) when is_list(${t})`},{id:"get_single_test",fn:Mt,header:({genLowerSnake:e})=>`get_${e}!(${e}_params) when is_map(${e}_params)`},{id:"get_single_by_id_test",fn:Pt,header:({genLowerSnake:e})=>`get_${e}!(id) when is_binary(id)`}],Is={get_many_test:Tt,get_single_test:Mt,get_single_by_id_test:Pt},wt=(e,t)=>{let r=Os.map(({id:s,fn:o,header:a})=>({id:s,def:o(t),header:a(t)})).filter(({header:s})=>e.includes(s));return{result:r.map(({id:s})=>s||"").map(s=>Is[s](t)).join(`
`),remaining_apis:e.filter(s=>!r.map(({header:o})=>o).includes(s))}};var Ue=({camelName:e,genLowerSnakePlural:t,genLowerSnake:r})=>(u({camelName:e,genLowerSnakePlural:t,genLowerSnake:r},"delete_many_test"),`
  test "delete_${r}/1 deletes multiple ${t}" do
    {:ok, ${t}, []} = ${e}.create_${r}([@valid_attrs, @valid_attrs])
    operation = ${e}.delete_${r}(${t})
    assert {:ok, 2, 0} = operation
  end
`),Dt=({camelName:e,genLowerSnake:t})=>(u({camelName:e,genLowerSnake:t},"delete_single_test"),`
  test "delete_${t}/1 deletes a single ${t}" do
    {:ok, ${t}} = ${e}.create_${t}(@valid_attrs)
    ${e}.delete_${t}(${t})

    assert_raise Ecto.NoResultsError, fn ->
      ${e}.get_${t}!(${t}.id)
    end
  end
`),Ct=({camelName:e,genLowerSnake:t})=>(u({camelName:e,genLowerSnake:t},"delete_single_by_id_test"),`
  test "delete_${t}/1 deletes a single ${t} by id" do
    {:ok, ${t}} = ${e}.create_${t}(@valid_id)
    ${e}.delete_${t}(${t})

    assert_raise Ecto.NoResultsError, fn ->
      ${e}.get_${t}!(${t}.id)
    end
  end
    `),Ss=[{id:"delete_many_test",fn:Ue,header:e=>g(e,Ue)},{id:"delete_single_test",fn:Dt,header:({genLowerSnake:e,genLowerSnakePlural:t})=>`delete_${e}(${t}) when is_list(${t})`},{id:"delete_single_by_id_test",fn:Ct,header:({genLowerSnake:e})=>`delete_${e}(${e}_params) when is_map(${e}_params)`}],Ts={delete_many_test:Ue,delete_single_test:Dt,delete_single_by_id_test:Ct},Ft=(e,t)=>{let r=Ss.map(({id:s,fn:o,header:a})=>({id:s,def:o(t),header:a(t)})).filter(({header:s})=>e.includes(s));return{result:r.map(({id:s})=>s||"").map(s=>Ts[s](t)).join(`
`),remaining_apis:e.filter(s=>!r.map(({header:o})=>o).includes(s))}};var qt=({genLowerSnakePlural:e,camelName:t,genUpperCamel:r})=>(u({genLowerSnakePlural:e,camelName:t,genUpperCamel:r},"list_standard_test"),`
  test "list_${e}/0 returns all ${e}" do
    {:ok, _${e}} = ${t}.create_${e}(@valid_attrs)
    operation = ${t}.list_${e}()

    assert {:ok, [%${r}{}],
            %{page_size: 100, page_number: 1, total_entries: 1, total_pages: 1}} = operation
  end
    `),Gt=({genLowerSnakePlural:e,camelName:t,genUpperCamel:r})=>(u({genLowerSnakePlural:e,camelName:t,genUpperCamel:r},"list_dynamic_test"),`
  test "list_${e}_by/2 returns all ${e} by field" do
    {:ok, _${e}} = ${t}.create_${e}(@valid_attrs)
    operation = ${t}.list_${e}_by(%{"example1" => "1"}, %{})

    assert {:ok, [%${r}{}],
            %{
              "example1" => "= 1",
              page: %{page_size: 100, page_number: 1, total_entries: 1, total_pages: 1}
            }} = operation
  end

  test "list_${e}_by/2 returns all ${e} by field with pagination" do
    {:ok, _${e}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs, @valid_attrs])
    operation = ${t}.list_${e}_by(%{"example1" => "1"}, %{page_size: 2})
    {:ok, ${e}, page} = operation
    assert [%${r}{}, %${r}{}] = ${e}

    assert %{
             :page => %{page_size: 2, page_number: 1, total_entries: 3, total_pages: 2},
             "example1" => "= 1"
           } = page
  end
`),Ms=[{id:"list_standard_test",fn:qt,header:({genLowerSnakePlural:e})=>`list_${e}(page_query \\\\ %{})`},{id:"list_dynamic_test",fn:Gt,header:({genLowerSnakePlural:e})=>`list_${e}_by(entity_queries, page_queries \\\\ %{})`}],Ps={list_standard_test:qt,list_dynamic_test:Gt},jt=(e,t)=>{let r=Ms.map(({id:i,fn:s,header:o})=>({id:i,def:s(t),header:o(t)})).filter(({header:i})=>e.includes(i));return{result:r.map(({id:i})=>i||"").map(i=>Ps[i](t)).join(`
`),remaining_apis:e.filter(i=>!r.map(({header:s})=>s).includes(i))}};var Ut=({genLowerSnakePlural:e,camelName:t,genUpperCamel:r})=>(u({genLowerSnakePlural:e,camelName:t,genUpperCamel:r},"update_many_test"),`
  test "update_${e}/1 updates multiple ${e}" do
    {:ok, ${e}, []} = ${t}.create_${e}([@valid_attrs, @valid_attrs])
    ${e} = ${e} |> Enum.map(&Map.merge(@update_attrs, %{id: &1.id}))
    operation = ${t}.update_${e}(${e})
    assert {:ok, [%${r}{}, %${r}{}], []} = operation
    partial_operation = ${t}.update_${e}(${e} ++ [@fake_attrs])
    assert {:partial_success, [%${r}{}, %${r}{}], [_failed_attrs]} = partial_operation
  end
`),Lt=({genLowerSnakePlural:e,camelName:t})=>(u({genLowerSnakePlural:e,camelName:t},"update_single_test"),`
  test "update_${e}/1 updates a single ${e}" do
    {:ok, %{id: id}} = ${t}.create_${e}(@valid_attrs)
    operation = ${t}.update_${e}(Map.merge(@update_attrs, %{id: id}))
    assert {:ok, result_${e}} = operation
    assert new_${e} = ${t}.get_${e}!(result_${e})

    assert %{
             id: res_id,
             example1: example1,
             example2: example2,
             example3: example3,
             updated_at: _,
             inserted_at: _
           } = new_${e}

    assert [example1, example2, example3, res_id] == [
             @update_attrs.example1,
             @update_attrs.example2,
             @update_attrs.example3,
             id
           ]
  end
`),ws=[{id:"update_many_test",fn:Ut,header:({genLowerSnake:e,genLowerSnakePlural:t})=>`update_${e}(${t}) when is_list(${t})`},{id:"update_single_test",fn:Lt,header:({genLowerSnake:e})=>`update_${e}(attrs) when is_map(attrs)`}],Ds={update_many_test:Ut,update_single_test:Lt},Wt=(e,t)=>{let r=ws.map(({id:s,fn:o,header:a})=>({id:s,def:o(t),header:a(t)})).filter(({header:s})=>e.includes(s));return{result:r.map(({id:s})=>s||"").map(s=>Ds[s](t)).join(`
`),remaining_apis:e.filter(s=>!r.map(({header:o})=>o).includes(s))}};var Cs=({header:e})=>(u({header:e},"custom"),`
    test "${e}" do
        # TODO: Provide test definition here
    end
`),kt={id:"custom",fn:Cs,header:({header:e})=>e};var Fs=(e,t)=>{p({level:7},"Requested Apis: ",e);let r=[St,wt,Ft,jt,Wt],{computed:n,remaining_apis:i}=r.reduce((o,a)=>{p({level:8},"APIFN REDUCER",o,a);let{computed:c,remaining_apis:l}=o;p({level:8},"APIFN COM",c),p({level:8},"APIFN REM",l),p({level:8},"APIFN RES",a(l,t));let{result:d,remaining_apis:$}=a(l,t);return{computed:c+x({str:d,entity:t.genCamelName,type:"CONTEXT"},"EX"),remaining_apis:$}},{computed:"",remaining_apis:e});p({level:7},"Computed Apis: ",n);let s=i.map(o=>kt.fn({header:o})).map(o=>x({str:o,entity:t.genCamelName,type:"CONTEXT"},"EX")).join(`
`);return n+`
`+s},Bt=async(e,t)=>{let{AppData:{AppNameCamel:r,LibDir:n},generate:i,name:s}=e,{singleSnake:o,singleUpperCamel:a,pluralUpperCamel:c,pluralSnake:l}=s,{name:d,apiFunctions:$}=i.context,f=y(n||"","/test/"),m=d.replace(/([a-z0-9]|(?=[A-Z]))([A-Z])/g,"$1_$2").replace(/^_/,"").toLowerCase(),b=`
  defmodule ${r}.${d}Test do
  use ${r}.DataCase

  alias ${r}.${a}
  alias ${r}.${d}

  @valid_attrs %{example1: 1, example2: "1", example3: 1.0}
  @update_attrs %{example1: 2, example2: "2", example3: 2.0}
  @invalid_attrs %{example1: "1", example2: "1"}
  @fake_id "601d74e4-a8d3-4b6e-8365-eddb4c893327"
  @fake_attrs Map.put(@valid_attrs, :id, @fake_id)

${Fs($,{camelName:d,genLowerSnake:o||"",genUpperCamel:a||"",genLowerSnakePlural:l||""})}

end
`;return R({dir:f,filename:`${m}_test.exs`,content:b},"gen_phx_contex_test")};var Ht=({genName:e,context:t,pluralNameSnake:r,AppNameCamel:n})=>(u({genName:e,context:t,pluralNameSnake:r,AppNameCamel:n},"create_list"),`
    def create(conn, ${e}_list) when is_list(${e}_list) do
      with {:ok, ${r}, []} <- ${t}.create_${e}(${e}_list) do
        conn
        |> put_status(:created)
        |> put_resp_header("location", ~p"/api/${e}")
        |> render(:show, ${r}: ${r})
      else
        {:partial_success, created_${r}, failed_${r}} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeeded: created_${r}, failed: failed_${r}, query_data: ${e}_list)
  
        error ->
          ${n}Web.FallbackController.call(conn, error)
      end
    end
    `),zt=({genName:e,camelUpperName:t,context:r,pluralNameSnake:n})=>(u({genName:e,camelUpperName:t,context:r,pluralNameSnake:n},"create"),`
    def create(conn, ${e}_params) do
      with {:ok, %${t}{} = ${e}} <- ${e}_params |> MapUtil.str_to_atom() |> ${r}.create_${e}() do
        conn
        |> put_status(:created)
        |> put_resp_header("location", ~p"/api/${e}/#{${e}.id}")
        |> render(:show, ${e}: ${e})
      end
    end
    `),Xt=[{id:"create_list",fn:Ht,header:e=>g(e,Ht)},{id:"create",fn:zt,header:e=>g(e,zt)}];var qs=({header:e})=>(u({header:e},"custom"),`
    def ${e} do
        # TODO: Provide function definition here
    end
`),Yt={id:"custom",fn:qs,header:({header:e})=>e};var Jt=({context:e,genName:t,AppNameCamel:r})=>(u({context:e,genName:t,AppNameCamel:r},"delete_list"),`
    def delete(conn, ${t}_list) when is_list(${t}_list) do
      with {:ok, count, _} <- ${e}.delete_${t}(${t}_list) do
        render(conn, :show, count: count)
      else
        {:partial_success, success_count, fail_count} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeess_count: success_count, fail_count: fail_count, query_data: ${t}_list)
  
        e ->
          ${r}Web.FallbackController.call(conn, e)
      end
    end
  `),Kt=({genName:e,context:t,camelUpperName:r})=>`
    def delete(conn, %{"id" => id}) do
      with %${r}{} = ${e} <- ${t}.delete_${e}(id) do
        conn
        |> put_status(:ok)
        |> render(:show, ${e}: ${e})
      end
    end 
  `,Qt=[{id:"delete_list",fn:Jt,header:e=>g(e,Jt)},{id:"delete",fn:Kt,header:e=>g(e,Kt)}];var Le=async(e,t)=>{let{AppData:{WebDir:r,AppNameCamel:n,AppNameSnake:i},generate:s,name:o}=e,{http_controller:a}=s,{singleUpperCamel:c,pluralSnake:l,singleSnake:d}=o,{ImmutableGlobal:$,Schema:f}=t,m=y(r||".",`lib/${i}_web/controllers`),_=($||f)?.ex,b=Object.keys(_||{}).map(I=>`${I}: Map.get(${d}, :${I})`).join(`,
      `),v=`
defmodule ${n}Web.${c}JSON do
  alias ${n}Web.FallbackController

  @doc """
  Renders a ${d} or list of ${l}.

  ## Examples
      iex> render(conn, :show, ${l}: ${l})
      {:ok, %{data: [%${c}{}]}

      iex> render(conn, :show, ${d}: ${d})
      {:ok, %{data: %${c}{}}}
  """
  def show(%{${l}: ${l}, query_data: q}) when is_list(${l}) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.merge(%{data: transform(${l}), count: length(${l})})
  end

  def show(%{${d}: ${d}, query_data: q}) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.put(:data, transform(${d}))
  end

  def show(%{count: c}), do: %{success_count: c, fail_count: 0}

  def show(params), do: Map.merge(%{query_data: %{}}, params) |> show

  @doc """
  Renders ${l} from batch operations

  ## Examples
      iex> render(conn, :show_partial, succeeded: ${d}_maps, failed: ${d}_changesets)
      {:partial_success, [%${c}{}], [%Changeset{}]}
  """
  def show_partial(params \\\\ %{query_data: %{}, succeeded: [], failed: []})

  def show_partial(%{succeeded: succeeded_${l}, failed: failed_changesets, query_data: q})
      when is_list(succeeded_${l}) and is_list(failed_changesets) do
    if(q != %{},
      do: %{query: q},
      else: %{}
    )
    |> Map.merge(%{
      success_count: length(succeeded_${l}),
      fail_count: length(failed_changesets),
      data: transform(succeeded_${l}),
      failed: FallbackController.error_transform(failed_changesets)
    })
  end

  def show_partial(%{success_count: s_count, fail_count: f_count}), do: %{success_count: s_count, failed_count: f_count}

  defp transform(${l}) when is_list(${l}), do: Enum.map(${l}, &transform/1)

  defp transform(${d}) when is_map(${d}) do
    %{
      id: Map.get(${d}, :id),
      ${b}
    }
  end
end
`,h=x({str:v,type:"JSON_HANDLER",entity:d},"EX");return a?R({dir:m,filename:`${d}_json.ex`,content:h},"gen_json_handler"):null};var Zt=({pluralNameSnake:e,context:t})=>(u({pluralNameSnake:e,context:t},"index_standard"),`
    defp routed_index(conn, entity_queries, page_queries) when entity_queries == %{} do
      with {:ok, ${e}, query_data} <- ${t}.list_${e}(page_queries) do
        render(conn, :show, ${e}: ${e}, query_data: query_data)
      end
    end
  `),Vt=({pluralNameSnake:e,context:t})=>(u({pluralNameSnake:e,context:t},"index_dynamic"),`
    defp routed_index(conn, entity_queries, page_queries) when entity_queries != %{} do
      with {:ok, ${e}, query_data} <- ${t}.list_${e}_by(entity_queries, page_queries) do
        render(conn, :show, ${e}: ${e}, query_data: query_data)
      end
    end
  `),Nt=[{id:"index_standard",fn:Zt,header:e=>g(e,Zt)},{id:"index_dynamic",fn:Vt,header:e=>g(e,Vt)}];var er=({pluralNameSnake:e,context:t,genName:r})=>(u({pluralNameSnake:e,context:t,genName:r},"show_list"),`
    def show(conn, ${r}_list) when is_list(${r}_list) do
      ${e} = ${t}.get_${r}!(${r}_list)
      render(conn, :show, ${e}: ${e})
    end
  `),tr=({genName:e,context:t})=>(u({genName:e,context:t},"show"),`
    def show(conn, %{"id" => id}) do
        ${e} = ${t}.get_${e}!(id)
        render(conn, :show, ${e}: ${e})
    end
`),rr=[{id:"show_list",fn:er,header:e=>g(e,er)},{id:"show",fn:tr,header:e=>g(e,tr)}];var nr=({pluralNameSnake:e,context:t,genName:r,AppNameCamel:n})=>(u({pluralNameSnake:e,context:t,genName:r,AppNameCamel:n},"update_list"),`
    def update(conn, ${r}_list) when is_list(${r}_list) do
      with {:ok, ${e}, []} <- ${t}.update_${r}(${r}_list) do
        render(conn, :show, ${e}: ${e})
      else
        {:partial_success, updated_${e}, failed_${e}} ->
          conn
          |> put_status(:partial_content)
          |> render(:show_partial, succeeded: updated_${e}, failed: failed_${e}, query_data: ${r}_list)
  
        error ->
          ${n}Web.FallbackController.call(conn, error)
      end
    end
    `),sr=({genName:e,context:t,camelName:r})=>(u({genName:e,context:t,camelName:r},"update"),`
    def update(conn, ${e}_params) when is_map(${e}_params) do
      with {:ok, %${r}{} = ${e}} <- ${t}.update_${e}(${e}_params) do
        render(conn, :show, ${e}: ${e})
      end
    end
  `),ir=[{id:"update_list",fn:nr,header:e=>g(e,nr)},{id:"update",fn:sr,header:e=>g(e,sr)}];var Gs=[rr,Nt,Xt,ir,Qt].flat(),js=(e,t,r)=>{p({level:7},"Requested Routes: ",e);let n=t.reduce((i,s)=>({...i,[s.header(r)]:s.fn(r)}),{});return p({level:7},"Route Data Computed: ",n),e.map(i=>(p({level:7},"Header: ",i),n[i]||Yt.fn({header:i}))).map(i=>x({str:i,type:"CONTROLLER",entity:r.genName},"EX")).join(`

`)},or=async(e,t)=>{let{AppData:{AppNameSnake:r,AppNameCamel:n,WebDir:i},generate:{http_controller:s,context:o},name:{singleSnake:a,singleUpperCamel:c,pluralSnake:l}}=e,{name:d,routes:$}=s,{name:f}=o,m=y(i||"",`/lib/${r}_web/controllers/`),_=d.replace(/([a-z0-9])([A-Z])/g,"$1_$2").toLowerCase(),b={camelName:c||"",genName:a,context:f,pluralNameSnake:l||"",AppNameCamel:n||"",camelUpperName:c||""};p({level:7},"Generating controller: ",d,_,b);let v=`
defmodule ${n}Web.${d} do
use ${n}Web, :controller
plug ${n}.Plugs.ListAsJSON
plug ${n}.Plugs.ValidateBinaryId, fallback: ${n}Web.FallbackController

alias ${n}.Utils.Paginate
alias ${n}.Utils.MapUtil

alias ${n}.${f}
alias ${n}.${c}

action_fallback ${n}Web.FallbackController

def index(conn, params) do
    {entity_queries, page_queries} = Paginate.split_page_opts(params)
    routed_index(conn, entity_queries, page_queries)
end

${js($,Gs,b)}

end
`;return R({dir:m,filename:`${_}.ex`,content:v},"gen_phx_controller")};var pr=require("child_process"),lr=require("fs"),mr=require("path");var Us=async(e,t)=>{if(await k("nomix")!="true")return e;let n=!!e.match(/\bmix\b/g),i=!!e.match(/\bphx.new\b/g),s="",o="docker/compose.yaml";return n&&p({level:2,color:"PINK"},"Running MIX in Docker..."),i&&(s=`mkdir -p ${t}_umbrella && cd ${t}_umbrella && `,e=`${e} && cp -rf ${t}_umbrella/* . && rm -rf ${t}_umbrella`,o="docker/compose.yaml"),n?`${s}docker compose -f ${o} run --rm ${t}_dev bash -c "shopt -s dotglob && ${e}"`:e},ar=Us;var cr={dir:"",command:"",options:{forceReturnOnPrompt:!0}};var dr=async(e,t=null)=>{let{dir:r,command:n,env:i,options:s}={...cr,...e},{timeoutResolve:o,timeoutReject:a,forceReturnOnPrompt:c,resolveOnErrorCode:l}={...cr.options,...s},d=await ar(n,(await W())?.AppNameSnake||"");return et({command:d,dir:r},t),p({level:1,color:"PURPLE"},`Executing: ${d}`),p({level:1,color:"TEAL"},`      in ${r}...

`),new Promise(($,f)=>{let m=(0,mr.resolve)(r);(0,lr.mkdirSync)(m,{recursive:!0});let[_,...b]=d.split(" "),v=(0,pr.spawn)(_,b,{cwd:m,shell:!0,env:i});v.stdout.on("data",h=>{p({level:5},h.toString()),s?.prompts&&s.prompts.forEach(([I,G])=>{if(h.toString().includes(I)){let z=G+(c?`
`:"");v.stdin.write(z)}})}),v.stderr.on("error",h=>{console.error(`Could not run ${d}:
      ${h}`),f(h||`Could not run ${d}`)}),v.on("close",h=>{!l&&h?(console.error(`Process exited with exit code ${h}:
       ${d}`),f(`Process exited with ${h}`)):$(r)}),o&&setTimeout(()=>$(r),o),a&&setTimeout(()=>f(new Error("Time out")),a)})};var ur=async({generate:{schema:e,databaseTable:t},AppData:{WebDir:r,UmbrellaDir:n}},i)=>{let s=(i.Schema||i.ImmutableGlobal)?.ex||{};p({level:9},"Gen schema source: ",s);let o=`cd ${r.match(/\w*\/\w*$/g)} && mix phx.gen.schema ${e} ${t}`+Object.keys(s).map(a=>` ${a}:${s[a]}`).join("")+" --no-prompts";return p({level:2,color:"BLUE"},`Generating Phoenix Schema and Migrations for ${e}`),dr({command:o,dir:n},"gen_schema")};var $r=S(require("path"));var We=S(require("fs"));var B=async({file:e,injections:t},r=null)=>{try{return r&&p({level:5,color:"TAN"},r),p({level:5},`Injecting into ${e} ...`),new Promise(async(n,i)=>{rt(e,r);let o=We.default.readFileSync(e,"utf8");t.forEach(([a,c,l])=>{switch(p({level:7},`Injecting ${l} into ${e}`),p({level:9},"File: ",o),a){case"REPLACE":let d=typeof l=="function"?l(o):o.replace(c,l);if(l&&(d==o||d=="")){_r(c,e,i);return}else p({level:8},`Found ${c} in ${e}`),o=d;break;default:o=Ls(o,e,[a,c,l])||_r(c,e,i)}}),o.length?(We.default.writeFileSync(e,o,"utf8"),await K(e),n([e])):i(new Error(`Insertion failed for ${e}`))})}catch(n){throw new Error(`Error in ${r}`,{cause:n})}},_r=(e,t,r)=>(console.error(`${e} not found in the ${t} file.`),r(new Error(`Insertion failed for ${t}`)),""),Ls=(e,t,[r,n,i])=>{let s=new RegExp(n.source,n.flags).exec(e);if(!s)return null;let o=s.index;if(p({level:8},`Found ${n} at ${o} in ${t}`),r==="AFTER")o+=s[0].length;else if(r!="BEFORE")return null;return e.slice(0,o)+i+e.slice(o)};var gr=async e=>{let{generate:t,name:r,AppData:{AppNameSnake:n,WebDir:i}}=e||{},{singleSnake:s}=r||{},{http_controller:o}=t||{},{name:a}=o||{},c=$r.default.join(i||".",`lib/${n}_web/router.ex`),l=[["AFTER",/pipe_through[\s\(]{1,3}:api\){0,1}/,`
resources "/${s}", ${a}
put "/${s}", ${a}, :update
delete "/${s}", ${a}, :delete`]];return B({file:c,injections:l},"inject_router")};var yr=S(require("path"));var hr=async({AppData:{LibDir:e,AppNameSnake:t},name:r})=>{let n=yr.default.join(e||".",`lib/${t}/${r.singleSnake}.ex`),i=[["REPLACE",/.*/gms,s=>x({str:s,type:"SCHEMA"},"EX")]];return B({file:n,injections:i},"mark_schema")};var br=async(e,t)=>{let r=e.generate,n=[];if(r.schema){let i=await ur(e,t);await hr(e),n.push(i)}return r.context&&(n.push(await At(e,t)),r.test&&n.push(await Bt(e,t))),r.http_controller&&n.push(await Promise.all([or(e,t),Le(e,t),gr(e)])),n};var Hr=S(Br()),Gp=new Hr.LoremIpsum,Ti={number:"Math.floor(Math.random() * 100)",string:"Lorem.generateWords(3)",boolean:"Math.random() > 0.5",object:"({ lorem: Lorem.generateWords(1), ipsum: Lorem.generateWords(2) })",array:'Lorem.generateWords(3).split(" ")',any:"Lorem.generateSentences(1)"};var zr=e=>Ti[e];var Mi=({singleUpperCamel:e,singleLowerCamel:t,appstate:r})=>({header:`set${e}(state: ${r}, action: PayloadAction<${e}>`,definition:`set${e}(state: ${r}, action: PayloadAction<${e}>) {
          state.${t} = action.payload;
        }`}),Pi=({pluralUpperCamel:e,singleUpperCamel:t,appstate:r,pluralLowerCamel:n})=>({header:`set${e}(state: ${r}, action: PayloadAction<${t}[]>`,definition:`set${e}(state: ${r}, action: PayloadAction<${t}[]>) {
          state.${n} = action.payload;
        }`}),wi=e=>`${e} {
      // TODO: implement custom reducer 
      return state;   
  `,Di=({pluralUpperCamel:e,singleUpperCamel:t,singleLowerCamel:r,appstate:n},i=`set${e}(state: ${n}, action: PayloadAction<${t}[]>`)=>({header:i,definition:`it("${i}", () => {
    const ${r} = ${t}Factory();
    const state = ${r}Slice.reducer(initial${t}StoreStateState, set${t}(${r}));
    expect(state.${r}).toEqual(${r});
  });`}),Ci=({singleUpperCamel:e,singleLowerCamel:t,pluralLowerCamel:r,pluralUpperCamel:n,appstate:i},s=`set${e}(state: ${i}, action: PayloadAction<${e}>`)=>({header:s,definition:`it("${s}", () => {
  const ${r} = [${e}Factory(), ${e}Factory()];
  const state = ${t}Slice.reducer(initial${e}StoreStateState, set${n}(${r}));
  expect(state.${r}).toEqual(${r});
});`}),Fi=e=>`
it("${e}", () => {
    // TODO: implement custom reducer test
})`,Je=e=>{let{name:t,generate:r}=e,n=r?.stateSlice?.reducers,i=r?.appstate||"";p({level:8},{reducers:n});let s=[Mi,Pi].map(a=>a({...t,appstate:i}));p({level:8},{generatedReducers:s});let o=n?.map(a=>s.find(c=>a===c.header)?.definition||wi(a));return p({level:8},{processedReducers:o}),o},le=e=>e?.map(t=>typeof t=="string"&&t.match(/^\w+/)?.[0]),Xr=e=>{let{name:t,generate:r}=e,n=r?.stateSlice?.reducers,i=r?.appstate||"";p({level:8},{reducers:n});let s=[Di,Ci].map(a=>a({...t,appstate:i}));p({level:8},{generatedReducerTests:s});let o=n?.map(a=>s.find(({header:c})=>a===c)?.definition||Fi(a));return p({level:8},{processedReducerTests:o}),o};var qi=({singleUpperCamel:e,singleLowerCamel:t})=>({header:`select${e} = (state: GenericAppState)`,definition:`const select${e} = (state: GenericAppState) => state.${`${e}Store`}.${t};`}),Gi=({pluralUpperCamel:e,singleUpperCamel:t,pluralLowerCamel:r})=>({header:`select${e} = (state: GenericAppState)`,definition:`const select${e} = (state: GenericAppState) => state.${t}Store.${r}`}),ji=e=>`const ${e} => {
      // TODO: implement custom selector 
      return state;   
  }`,Ui=({singleUpperCamel:e,singleLowerCamel:t},r=`select${e} = (state: GenericAppState)`)=>({header:r,definition:`it("${r}", () => {
  const ${t} = ${e}Factory();
  const state = ${t}Slice.reducer(initial${e}StoreStateState, set${e}(${t}));
  const selected${e} = select${e}({ ${e}Store: state });
  expect(selected${e}).toEqual(${t});
});`}),Li=({singleUpperCamel:e,singleLowerCamel:t,pluralUpperCamel:r},n=`select${r} = (state: GenericAppState)`)=>({header:n,definition:`it("select${e}s", () => {
  const ${t}s = [${e}Factory(), ${e}Factory()];
  const state = ${t}Slice.reducer(initial${e}StoreStateState, set${e}s(${t}s));
  const selected${e}s = select${e}s({ ${e}Store: state });
  expect(selected${e}s).toEqual(${t}s);
});`}),Wi=e=>`
it("${e}", () => {
    // TODO: implement custom selector test
})`,Ke=e=>{let{name:t,generate:r}=e,n=r?.stateSlice?.selectors,i=r?.appstate||"",s=[qi,Gi].map(a=>a({...t,appstate:i}));return n?.map(a=>s.find(c=>a===c.header)?.definition||ji(a))},me=e=>e?.map(t=>typeof t=="string"&&t.match(/(?<=\bconst\s)\w+/)?.[0]),Yr=async e=>{let{name:t,generate:r}=e,n=r?.stateSlice?.selectors,i=r?.appstate||"";p({level:8},{selectors:n});let s=[Ui,Li].map(a=>a({...t,appstate:i}));p({level:8},{generatedSelectorTests:s});let o=n?.map(a=>s.find(c=>a===c.header)?.definition||Wi(a));return p({level:8},{processedSelectorTests:o}),o};var Jr=async(e,t,r)=>{let{name:{singleUpperCamel:n},generate:{stateSlice:i,factory:s,test:o},AppData:{LibDir:a}}=e;if(o){let c=await Xr(e),l=await Yr(e),d=le(t),$=me(r),f=`
    import ${i?.name||""}, {
  ${d.join(", ")},
  ${$.join(", ")},
  ${s?`${n}Factory`:""},
  initial${n}StoreStateState,
} from "./${n}";
    

`+c.map(m=>x({str:m,entity:n,type:"REDUCER TEST"})).join(`
`)+`

`+l?.map(m=>x({str:m,entity:n,type:"SELECTOR TEST"}))?.join(`
`);return R({filename:`${n}.test.tsx`,dir:y(a,"lib/typescript/state/"),content:f})}};var Kr=async(e,t)=>{p({level:7},"GEN ENTITY STORE",e),p({level:7},"TYPE DICT",t);let{name:{singleUpperCamel:r},generate:{tstype:n,appstate:i,factory:s,stateSlice:o},AppData:{LibDir:a}}=e,c=o?.name,l=y(a,"lib/typescript/state/"),d=(t.TsType||t.ImmutableGlobal)?.ts,$=(t.AppState||t.ImmutableGlobal)?.ts,f=t.InitialAppState?.ts||{},m=Je(e),_=le(m),b=Ke(e),v=me(b||[]),h=`id: number;
`+Object.keys(d||{}).map(E=>`${E}: ${d?.[E]}`).join(`;
`),I=x({str:`type ${n} = {${h}}`,type:"TYPEDEF",entity:r}),G=Object.keys($||{}).map(E=>`${E}: ${$?.[E]}`).join(`;
`),z=x({str:`interface ${i} {${G}}`,type:"APPSTATE",entity:r}),de=Object.keys(d||{}).map(E=>`${E}: ${zr(d?.[E])}`).join(`,
`),X=`const ${n}Factory = (params: object = {}): ${n} => {
    const ${r} = {${de}};
    return Object.assign(${r}, params) as ${n};
}`,fn=x({str:X,type:"FACTORY",entity:r}),$n=Object.keys(f).map(E=>`${E}: ${f[E]}`).join(`,
`),gn=x({str:`const initial${i}State: ${r}StoreState = {${$n}}`,type:"INITIAL_APPSTATE",entity:r}),yn=`
const ${c} = createSlice({
      name: "${r}",
      initialState: initial${i}State,
      reducers: {
        ${Je(e).map(E=>x({str:E,type:"REDUCER",entity:r})).join(`,
`)}
      },
    });
const ${r}Reducer = ${c}.reducer;

${Ke(e)?.map(E=>x({str:E,type:"SELECTOR",entity:r})).join(`
`)}
`,hn=[i?`initial${i}State`:null,s?`${n}Factory`:null,c?`${r}Reducer`:null,...v].filter(E=>!!E).join(", "),bn=[c?`const { ${_.join(", ")} } = ${c}.actions
export { ${_.join(", ")} }`:null,n||i?`export type { ${[n,i,"GenericAppState"].join(", ")} }`:null,`export { ${hn} }`,c?`export default ${c}`:null].filter(E=>!!E).join(`
`),vn=`interface GenericAppState {
    ${r}Store: ${r}StoreState;
    [key: string]: any;
}`,xn=x({str:vn,type:"GENERIC_APPSTATE",entity:r}),Rn=`
import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import Lorem from "../utils/lorem";

${n?`
${I}
`:""}
${i?`
${z}
`:""}
${i?`
${gn}
`:""}
${s?`
${fn}
`:""}
${c?`
${yn}
`:""}

${xn}

${bn}
`;return Promise.all([R({dir:l,filename:`${r}.tsx`,content:Rn},"gen_entity_store"),Jr(e,m,b||[])])};var Qr=S(require("path"));var Zr=async e=>{let{name:{singleUpperCamel:t},generate:{appstate:r},AppData:{UiDir:n}}=e,i=Qr.default.join(n,"src/store/index.tsx"),s=[["AFTER",/reducer\:\scombineReducers\(\{/,`
${t}Store: ${t}Reducer,`],["AFTER",/import\s.*/,`
import type { ${r} } from '@state/${t}';
import { ${t}Reducer } from '@state/${t}';`],["AFTER",/type\s+[A-Za-z0-9_]+State\s+\=\s+\{/,`
  ${t}Store: ${r};`]];return B({file:i,injections:s},"addReducerToGlobal")};var Vr=async(e,t)=>{let{name:{singleUpperCamel:r,singleLowerCamel:n,pluralUpperCamel:i,singleSnake:s},generate:{requests:o},AppData:{AppNameCamel:a,LibDir:c}}=e,l=y(c||"","lib/typescript/requests/"),d=[ki,Bi,Hi,zi].map(_=>_({singleUpperCamel:r,singleLowerCamel:n,pluralUpperCamel:i,AppNameCamel:a,singleSnake:s})).map(_=>x({str:_,entity:r,type:"REQUEST_API"},"TS")).join(`
`),$=`
import type { Dispatch } from "redux";
import { Request } from "./index";
import { set${r}, set${i} } from "../state/${r}";
import type { ${r} } from "../state/${r}";
import type { ${r}Response, Count${r}Response, Partial${r}Response } from "./${r}Response";`,f=`export { request${r}, request${i}, update${r}, delete${r} };
`,m=[$,d,f].join(`
`);return o?R({dir:l,filename:`${r}.tsx`,content:m},"gen_entity_requests"):null},ki=({singleUpperCamel:e,singleSnake:t})=>`const request${e} = (id: string, dispatch: Dispatch) => 
    Request.API({
      name: "fetch${e}",
      route: \`${t}/\${id}\`,
      callback: (res: any) => dispatch(set${e}(res.data))
    }, dispatch) as Promise<${e}Response>;`,Bi=({pluralUpperCamel:e,singleSnake:t,singleUpperCamel:r})=>`const request${e} = (dispatch: Dispatch) => 
    Request.API({
      name: "fetch${e}",
      route: \`${t}\`,
      callback: (res: any) => dispatch(set${e}(res.data)),
    }, dispatch) as Promise<${r}Response>;`,Hi=({singleUpperCamel:e,singleLowerCamel:t,singleSnake:r})=>`const update${e} = (${t}: ${e}, dispatch: Dispatch) => 
    Request.API({
      name: "update${e}",
      route: "${r}",
      options: {
        method: "PUT",
        body: JSON.stringify(${t}),
      },
      callback: (_data: any) => null,
    }, dispatch) as Promise<Partial${e}Response>;`,zi=({singleUpperCamel:e,singleSnake:t})=>`const delete${e} = (id: string, dispatch: Dispatch) => 
    Request.API({
      name: "delete${e}",
      route: \`${t}/\${id}\`,
      options: {
        method: "DELETE",
      },
    }, dispatch) as Promise<Count${e}Response>;`;var Nr=async(e,t)=>{let{name:{singleUpperCamel:r},AppData:{LibDir:n}}=e,i=y(n||"","lib/typescript/requests"),s=`${r}Response.tsx`,o=`import type { ${r} } from "../state/${r}";

type BaseQuery = {
  query?: Record<string, any>;
};

type ${r}Response = BaseQuery & {
  data: ${r} | ${r}[];
  count?: number;
};

type Count${r}Response = {
  success_count: number;
  fail_count: number;
};

type Partial${r}Response = BaseQuery & {
  success_count: number;
  fail_count: number;
  data: ${r}[];
  failed: any[];
};

type All${r}Response =
  | ${r}Response
  | Count${r}Response
  | Partial${r}Response;

  export type { ${r}Response, Count${r}Response, Partial${r}Response, All${r}Response };
  `,a=x({str:o,entity:r,type:"API_RESPONSE"});return R({dir:i,filename:s,content:a},"gen_entity_api_response")};var en=(o=>(o.string="text",o.number="number",o.boolean="checkbox",o.date="date",o.email="email",o.password="password",o))(en||{}),Xi=(e,t,r)=>` 
  <label htmlFor="${e}">${e}</label>
  <input
    type="${en[t]||"text"}"
    name="${e}"
    value={${r}?.${e} ?? ""}
    onChange={onChange}
  />
  `,tn=async(e,t)=>{let{name:{singleUpperCamel:r,singleLowerCamel:n},AppData:{LibDir:i}}=e,o=(t.TsType||t.ImmutableGlobal)?.ts||{},a=y(i||"",`lib/typescript/components/${n}/`),c=Object.keys(o).map(d=>Xi(d,o[d],n)).join(`
`),l=`
  import React, { useState } from "react";
import { useDispatch } from "react-redux";
import type { Dispatch } from "redux";
import type { ${r} as ${r}T } from "../../state/${r}";

interface CreateProps {
  onSubmit?: (
    e: React.FormEvent<HTMLFormElement>,
    f: ${r}T | null,
    d: Dispatch
  ) => void;
  submitText?: string;
}

export const ${r}Form = ({ onSubmit, submitText }: CreateProps) => {
  const dispatch = useDispatch();
  const [${n}, set${r}] = useState<${r}T | null>(null);

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    set${r}((prev${r}) => {
      return { ...prev${r}, [name]: value } as ${r}T;
    });
  };

  return (
    <form className="form-container"
      onSubmit={(e: React.FormEvent<HTMLFormElement>) =>
        onSubmit && onSubmit(e, ${n}, dispatch)
      }
    >
      <h4 className="form-title">${r} Form</h4>

    ${c}
      
      <button type="submit" className="form-submit-btn">{submitText || "Submit"}</button>
    </form>
  );
};

export const Create${r} = ({ onSubmit }: CreateProps) => (
  <div>
    <h4>Create a ${r}</h4>
    <${r}Form onSubmit={onSubmit} submitText="Create a ${r}"/>
  </div>
);
  `;return R({dir:a,filename:"create.tsx",content:l},"gen_create_demo_component")};var rn=async(e,t)=>{let{name:{singleUpperCamel:r,singleLowerCamel:n,pluralLowerCamel:i,pluralUpperCamel:s},AppData:{LibDir:o}}=e,a=y(o||"",`lib/typescript/components/${n}/`),c=`import React from "react";
import { useSelector } from "react-redux";
import type { Dispatch } from "redux";
import { pipe } from "mincurrypipe";
import type { ${r} as ${r}T } from "../../state/${r}";
import { select${r}, select${s}, set${r} } from "../../state/${r}";
import { request${s}, update${r} } from "../../requests/${n}";
import { Create${r} } from "./create";
import { ${s} } from "./list";
import { ${r} } from "./show";

export const prevtDef = (e: React.FormEvent<HTMLFormElement>) =>
  e.preventDefault();

export const ${r}Demo = () => {
  const ${n} = useSelector(select${r});
  const ${i} = useSelector(select${s});

  return (
    <div>
      <h1>${r} Demo</h1>
      <p>This is a demo of ${n} components.</p>
      <h2>Selected ${r}</h2>
      <${r} ${n}={${n}} />
      <Create${r}
        onSubmit={(
          e: React.FormEvent<HTMLFormElement>,
          f: ${r}T | null,
          d: Dispatch,
        ) =>
          pipe(
            prevtDef(e),
            () => f && update${r}(f, d),
            set${r},
            d,
            () => request${s}(d),
          )
        }
      />
      <h2>All ${s}</h2>
      <${s} ${i}={${i}} effect={request${s}} />
    </div>
  );
};`;return R({dir:a,filename:"index.tsx",content:c},"gen_full_demo_component")};var nn=async(e,t)=>{let{name:{singleUpperCamel:r,singleLowerCamel:n,pluralLowerCamel:i,pluralUpperCamel:s},AppData:{LibDir:o}}=e,a=y(o||"",`lib/typescript/components/${n}/`),c=`import { useEffect } from "react";
import { useDispatch } from "react-redux";
import type { Dispatch } from "redux";
import type { ${r} as ${r}T } from "../../state/${r}";
import { ${r} } from "./show";
import "../styles.css";

interface ${r}Props {
  ${i}?: ${r}T[];
  effect?: (d: Dispatch) => void;
}

export const ${s}Render = ({ ${i} }: ${r}Props) => (
  <div>
    <ul className="styled-list">
      {${i}?.map((${n}) => (
        <li className="styled-list-item" key={\`${n}-\${${n}?.id}\`}>
          <${r} ${n}={${n}} key={\`${n}-\${${n}?.id}\`} />
        </li>
      ))}
    </ul>
  </div>
);

export const ${s} = ({ ${i}, effect }: ${r}Props) => {
  const dispatch = useDispatch(); // Generate a redux dispatch for this component

  useEffect(() => {
    // By passing the effect function through props, we can defer the decision whether this function requests data
    //      or merely renders existing data to the parent component
    if (effect) effect(dispatch as Dispatch);
  }, [dispatch]); // This will fire the effect once on component mount and again if dispatch changes

  return <${s}Render ${i}={${i}} />;
};`;return R({dir:a,filename:"list.tsx",content:c},"gen_list_demo_component")};var Yi=(e,t)=>`\${${t}?.${e}}`,sn=async(e,t)=>{let{name:{singleUpperCamel:r,singleLowerCamel:n},AppData:{LibDir:i}}=e,o=(t.TsType||t.ImmutableGlobal)?.ts||{},a=y(i||"",`lib/typescript/components/${n}/`),c=Object.keys(o||{}).map(d=>Yi(d,n)).join(" "),l=`import { useEffect } from "react";
import { useDispatch } from "react-redux";
import type { Dispatch } from "redux";
import type { ${r} as ${r}T } from "../../state/${r}";
import "../styles.css";

interface ${r}Props {
  ${n}?: ${r}T | null;
  effect?: (d: Dispatch) => void;
}

export const ${r}Render = ({ ${n} }: ${r}Props) => {
  if (!${n}) return null;

  return (
    <div className="form-container" style={{ background: "none" }}>
      <ul className="styled-list">
        {Object.entries(${n}).map(([key, value]) => (
          <li className="styled-list-item" key={key}>
            <span style={{ fontWeight: 600, color: "#235390", minWidth: 90, marginRight: 8 }}>
              {key}:
            </span>
            <span>{String(value)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export const ${r} = (props: ${r}Props) => {
  const { ${n}, effect } = props;
  const dispatch = useDispatch();

  useEffect(() => {
    if (effect) effect(dispatch as Dispatch);
  }, [dispatch, effect]);

  return (
    <div>
      {${n} ? <${r}Render ${n}={${n}} /> : <p>No ${r} selected</p>}
    </div>
  );
};`;return R({dir:a,filename:"show.tsx",content:l},"gen_show_demo_component")};var on=async(e,t)=>{let{generate:r}=e;return r?Promise.all([tn(e,t),nn(e,t),sn(e,t),rn(e,t)]):null};var an=async(e,t)=>Promise.all([Zr(e),on(e,t),Kr(e,t),Vr(e,t),Nr(e,t)]);var dn=S(require("fs"));var cn=e=>{let t=/(?<=const\s+Immutable:\s+ImmutableGenerator\s+=\s+)[\s\S]*?(?=[\s\n\*;]+PRIMITIVES)/,r=e.match(t)?.[0],n={},i=[["keysInQuotes",s=>s?.replace(/^\s{0,100}(\w+):/gm,"Q_HLD$1Q_HLD:")],["fullLineCommentsRemoved",s=>s?.replace(/^\s{0,999}\/\/.*\n/g,"")],["inlineCommentsRemoved",s=>s?.replace(/\/\/.*(?=\n)/g,"")],["trailingCommasRemoved",s=>s?.replace(/,(?=[\s\n]+[\}\]])/gs,"")],["double_escape",s=>s?.replace(/\\/g,"\\\\\\\\")],["escaped_inner_quotes",s=>s?.replace(/(['`\"])(.*)(\".*\")(.*)(['`\"])/g,(o,a,c,l,d,$)=>{let f=a==$?l.replace(/\"/g,'\\"'):l;return`${a}${c}${f}${d}${$}`})],["single_quotes_turned_double",s=>s?.replace(/[\'\`]/g,'"')],["keys_restored",s=>s?.replace(/Q_HLD/g,'"')],["trailing_semicolons_removed",s=>s?.replace(/(?<=\})[;\/\s\n\*]+$/,"")],["json_parse",s=>JSON.parse(s||"{}")]];try{let s=i.reduce((o,[a,c])=>{let l=c(o);return n[a]=l,l},r)}catch(s){console.error("Error parsing generator file:"),console.log("Original String:",e);for(let o of Object.keys(n))console.log(`${o}:
`,`${n[o]}`,`

`);throw console.error(s),s}return n.json_parse};var pn=(e,t)=>({...Ji(e,t),...Ki(e)}),Ji=(e,t)=>{let r={};return e.replace(/(interface\s+)(\w+)(\s+extends\s+GenType\<\{\s+)([^\>]*?)(\s+\}\>\s*\{\})/g,(n,i,s,o,a)=>{p({level:9},"Found Type: ",{name:s,definition:a});let{ex:c,ts:l}=ln(s,a,t);return(!!Object.keys(l).length||!!Object.keys(c).length)&&(r[s]={name:s,ts:l,ex:c}),""}),r},Ki=e=>{let t={};return e.replace(/(interface\s+)(InitialAppState)(\s+extends\s+AppState\s*\{\s*)([^\>]*?)(\s*\}\s+\w+)/g,(r,n,i,s,o)=>{p({level:9},"Found InitalState: ",{definition:o});let{ex:a,ts:c}=ln("InitialAppState",o);return(!!Object.keys(c).length||!!Object.keys(a).length)&&(t.InitialAppState={name:"InitialAppState",ts:c,ex:a}),""}),t},ln=(e,t,r={})=>{let n=[];t.replace(/\/\/.*|\/\*[\s\S]*?\*\//g,"").replace(/[;,]\s*(?=$)/gm,"").trim().replace(/^\s*\"?(\w+)\"?\s*:\s*(.*?)\s*$/gm,(o,a,c)=>(c=c.trim(),p({level:8},{key:a,value:c}),n.push({key:a,value:c}),""));let s=n.reduce((o,{key:a,value:c})=>Object.assign(o,{ex:{...o.ex,[a]:c},ts:{...o.ts,[a]:r[c]||c}}),{name:e,ts:{},ex:{}});return p({level:6},"Parsed Type: ",s),s},mn=(e,t={})=>{let r=/type\s(\w+)\s=\s(\w+)\s&\s\{\s__brand\:/gs;return e.replace(r,(n,i,s)=>(t[i]=s,"")),t};var un=async e=>{let t=dn.readFileSync(e,"utf8");p({level:3,color:"BLUE"},`
Reading genfile: ${e}`),p({level:5},"Analyzing types...");let r=mn(t);p({level:5},"Reading generator...");let n=await cn(t),i={...n,name:Oe(n?.name)||{},AppData:await W()};p({level:3,color:"BLUE"},"Found app:"),await p({level:3,color:"GREEN"},`      ${i.AppData.AppNameCamel}`),await p({level:3,color:"BLUE"},`Generator: 
`,i);let s=i.generate;[["ControllerRoutes",s.http_controller?.routes],["ContextFunctions",s.context?.apiFunctions],["Requests",s.requests?.requestFunctions],["Reducers",s.stateSlice?.reducers],["Selectors",s.stateSlice?.selectors]].forEach(([c,l])=>p({level:3,color:"YELLOW"},`${c}:`,l)),await $e(2);let a=pn(t,r);return await p({level:3,color:"BLUE"},`TypeDict: 
`,a),{generator:i,genTypes:a}};Ve(5);var Qi=async()=>{let e=process.argv.slice(2),t=_n.resolve(e[0]);e.length<1&&(console.error("Please provide the input file path as an argument."),process.exit(1)),p({level:1,color:"GREEN"},`

 Reading genfile...

`);let{generator:r,genTypes:n}=await un(t),{name:{pluralUpperCamel:i,singleSnake:s},AppData:{AppNameCaps:o,UmbrellaDir:a}}=r;nt(a),p({level:1,color:"BLUE"},`
Generating front end components...`),await an(r,n),p({level:1,color:"BLUE"},`
Generating server components...`),await br(r,n),tt(a,`generate_${s}`),p({level:1,color:"GREEN"},`
Generation Complete.

Generated ${i}
`),p({level:1,color:"TEAL"},`    in ${o} App

`),p({level:2,color:"YELLOW"},`
Don't forget to update your repository by running migrations:`),p({level:4,color:"BLUE"},`    yarn d.mig
`),p({level:4,color:"BLUE"},`          or
`),p({level:4,color:"BLUE"},`    mix ecto.migrate
`)};Qi().catch(console.error);
