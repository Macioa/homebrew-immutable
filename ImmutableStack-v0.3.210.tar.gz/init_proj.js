"use strict";var ct=Object.create;var M=Object.defineProperty;var lt=Object.getOwnPropertyDescriptor;var pt=Object.getOwnPropertyNames;var ut=Object.getPrototypeOf,dt=Object.prototype.hasOwnProperty;var mt=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of pt(t))!dt.call(e,r)&&r!==n&&M(e,r,{get:()=>t[r],enumerable:!(o=lt(t,r))||o.enumerable});return e};var p=(e,t,n)=>(n=e!=null?ct(ut(e)):{},mt(t||!e||!e.__esModule?M(n,"default",{value:e,enumerable:!0}):n,e));var j=require("path");var w=99,_t={GREEN:"\x1B[32m%s\x1B[0m",RED:"\x1B[31m%s\x1B[0m",YELLOW:"\x1B[33m%s\x1B[0m",BLUE:"\x1B[34m%s\x1B[0m"},C=e=>(w=e,w),l=async({level:e,color:t},...n)=>{if(e<=w)return n=t?[_t[t],...n]:n,e<5&&console.log(`

`),console.log(...n),await ft(e>=5?0:5-e)},ft=e=>new Promise(t=>setTimeout(t,e*1e3));var z=require("child_process"),V=require("fs"),J=require("path");var D=require("fs"),I=p(require("path"));var f=(e,t=null)=>(Object.keys(e).forEach(n=>{let o=e[n];if(o==null)throw console.error(`${n} in StringOnlyMap cannot be null or undefined.
     Caller: ${t}`),`${n} in StringOnlyMap cannot be null or undefined. Caller: ${t}`}),!0),S=(e,t)=>t.reduce((n,o)=>n?.[o],e);var R=(e,t,n)=>{let o=t.pop(),r=S(e,t);r&&typeof r=="object"?r[o]=n:R(e,t,{[o]:n})};var $=null,v={_name:null,commands:[],file_modifications:{}},A=({command:e,dir:t},n=null)=>{v.commands.push({command:e,dir:t,caller:n||"unreferenced"})},q=({filename:e,dir:t},n=null)=>{f({filename:e,dir:t},n);let o=gt(t),{file_modifications:r}=v,c=o.split("/").filter(u=>u).concat([e]),d=(S(r,c)||[]).concat([n||"unreferenced"]);return R(v,["file_modifications",...c],d),v},U=(e,t)=>{v._name=t;let n=JSON.stringify(v,null,2);(0,D.writeFileSync)(I.default.resolve(e,`.immutable_history_${t}.json`),n,"utf8")},G=(e,t=null)=>{let n=e.split("/").filter(c=>c),o=n.slice(-1)[0],r=n.slice(0,-1).join("/");return q({filename:o,dir:r},t)},B=e=>{$=I.default.resolve(e).replace(/^[^\w]+/,"")},gt=e=>(e=e.replace(/^[^\w]+/,""),($?e.replace($,""):e).replace(/^[^\w]+/,""));var W={dir:"",command:"",options:{forceReturnOnPrompt:!0}};var x=async(e,t=null)=>{let{dir:n,command:o,options:r}={...W,...e},{timeoutResolve:c,timeoutReject:s,forceReturnOnPrompt:d,resolveOnErrorCode:u}={...W.options,...r};return A({command:o,dir:n},t),l({level:2,color:"YELLOW"},`Executing: ${o}`),l({level:4},`      in ${n}...`),new Promise((g,_)=>{let T=(0,J.resolve)(n);(0,V.mkdirSync)(T,{recursive:!0});let[ot,...rt]=o.split(" "),b=(0,z.spawn)(ot,rt,{cwd:T,shell:!0});b.stdout.on("data",y=>{l({level:5},y.toString()),r?.prompts&&r.prompts.forEach(([it,st])=>{if(y.toString().includes(it)){let at=st+(d?`
`:"");b.stdin.write(at)}})}),b.stderr.on("error",y=>{console.error(`Could not run ${o}:
      ${y}`),_(y||`Could not run ${o}`)}),b.on("close",y=>{!u&&y?(console.error(`Process exited with exit code ${y}:
       ${o}`),_(`Process exited with ${y}`)):g(n)}),c&&setTimeout(()=>g(n),c),s&&setTimeout(()=>_(new Error("Time out")),s)})};var F=p(require("path"));var O=p(require("fs"));var P=require("child_process"),k=async e=>new Promise((t,n)=>{let o=e.endsWith(".tsx")||e.endsWith(".ts"),r=e.endsWith(".ex")||e.endsWith(".exs");o&&(0,P.execSync)(`npx prettier --write ${e}`,{stdio:"inherit"}),r&&(0,P.execSync)(`mix format ${e}`,{stdio:"inherit"}),t(!0)});var i=async({file:e,injections:t},n=null)=>(l({level:3},`Injecting into ${e}....`),new Promise(async(o,r)=>{G(e,n);let s=O.default.readFileSync(e,"utf8");t.forEach(([d,u,g])=>{switch(l({level:7},`Injecting ${g} into ${e}`),l({level:9},"File: ",s),d){case"REPLACE":let _=s.replace(u,g);if(_==s||_==""){K(u,e,r);return}else l({level:8},`Found ${u} in ${e}`),s=_;break;default:s=yt(s,e,[d,u,g])||K(u,e,r)}}),s.length?(O.default.writeFileSync(e,s,"utf8"),await k(e),o([e])):r(new Error(`Insertion failed for ${e}`))})),K=(e,t,n)=>(console.error(`${e} not found in the ${t} file.`),n(new Error(`Insertion failed for ${t}`)),""),yt=(e,t,[n,o,r])=>{let c=e.match(o);if(!c)return null;let s=c.index;if(l({level:8},`Found ${o} at ${s} in ${t}`),n==="AFTER")s+=c[0].length;else if(n!="BEFORE")return null;return e.slice(0,s)+r+e.slice(s)};var ht=async(e,t)=>{let n=F.default.join(t,"vite.config.ts"),o=[["AFTER",/export\s+default\s+defineConfig\(\{[\s\n]+plugins\:\s+\[react\(\)\]\,/,`

  resolve: {
    alias: {
      '@utils': path.resolve(__dirname, '../${e}/lib/typescript/utils'),
      '@state': path.resolve(__dirname, '../${e}/lib/typescript/state'),
      '@requests': path.resolve(__dirname, '../${e}/lib/typescript/requests'),
      '@components': path.resolve(__dirname, '../${e}/lib/typescript/components'),
      '@test': path.resolve(__dirname, 'src/test')
    }
  },
`],["BEFORE",/import\s+react/,`import path from 'path';
`]];return i({file:n,injections:o},"inject_viteconfig")},xt=async(e,t)=>{let n=F.default.join(t,"tsconfig.app.json"),o=[["AFTER",/"compilerOptions":\s+\{/,`

  "baseUrl": "../../",
  "paths": {
    "@utils/*": ["apps/${e}/lib/typescript/utils/*"],
    "@state/*": ["apps/${e}/lib/typescript/state/*"],
    "@requests/*": ["apps/${e}/lib/typescript/requests/*"],
    "@components/*": ["apps/${e}/lib/typescript/components/*"]
  },
`]];return i({file:n,injections:o},"inject_tsconfig")},Y=async(e,t)=>Promise.all([ht(e,t),xt(e,t)]);var Q=p(require("path"));var H=async(e,t)=>{let n=Q.default.join(t,"vite.config.ts"),o=[["AFTER",/export\s+default\s+defineConfig\(\{/,`

  build: {
    outDir: '../${e}_web/priv/static', // Output the build to priv/static/assets
    assetsDir: 'assets', 
  },
`]];return i({file:n,injections:o},"inject_vite_build_output")};var X=require("path");var h=require("fs"),E=require("path");var a=async({filename:e,dir:t,content:n},o=null)=>{q({filename:e,dir:t},o);let r=e.replace(/(.*)\.(\w+)$/,(d,u,g)=>`${u.replace(/\./g,"/")}.${g}`),c=(0,E.resolve)(t),s=(0,E.join)(t,r);return l({level:3},`Generating ${r} ...`),l({level:9},n),(0,h.mkdirSync)(c,{recursive:!0}),(0,h.existsSync)(s)&&(0,h.unlinkSync)(s),(0,h.writeFileSync)(s,n,"utf8"),await k(s),[s]};var Z=async(e,t,n)=>{let o=(0,X.join)(n,"/lib/mix/processes/"),r=`
defmodule ${t}.ViteDevSupervisor do
  use GenServer

  @vite_dev_cmd ["run", "dev", "--prefix", "apps/${e}_ui/"]
  @timeout_sec 5
  @type state :: %{
          vite_server: nil | Port.t(),
          existing_vite_pids: [Integer.t()],
          timeout: nil | PID.t()
        }
  @init_state %{vite_server: nil, existing_vite_pids: [], timeout: nil}

  def init_state(map) when is_map(map), do: Map.merge(@init_state, map)

  def start_link(_), do: GenServer.start(__MODULE__, nil, name: __MODULE__)

  @impl true
  def init(_) do
    existing_vite_pids = get_vite_processes()
    Process.flag(:trap_exit, true)
    Process.link(self())

    Process.whereis(:vite_server) |> kill

    state =
      %{existing_vite_pids: existing_vite_pids}
      |> init_state()
      |> restart_timeout()

    Process.send_after(self(), :restart, @timeout_sec * 1000)
    {:ok, state}
  end

  @impl true
  # Polling mechanism
  def handle_info(:restart, state) do
    Process.send_after(self(), :restart, @timeout_sec * 1000)
    {:noreply, restart_timeout(state)}
  end

  @impl true
  # Forward Vite console output
  def handle_info({_port, {:data, msg}}, state) do
    IO.puts(msg)
    {:noreply, state}
  end

  @impl true
  # Ignore Process exit
  def handle_info({:EXIT, _port, :normal}, state), do: {:noreply, state}

  @impl true
  # Catch all unhandled info, print, and force error
  def handle_info(msg, state) do
    IO.inspect({msg, state}, label: :error_unhandled_info)
    {:error, :unhandled_info}
  end

  defp restart_timeout(state = %{vite_server: port, timeout: timeout}) do
    case [port, timeout] do
      [nil, nil] ->
        state
        |> start_dev_server()
        |> start_timeout()

      [nil, _] ->
        state
        |> cancel_timeout()
        |> start_dev_server()
        |> start_timeout()

      [_, nil] ->
        state
        |> start_timeout()

      [_, _] ->
        state
        |> cancel_timeout()
        |> start_timeout()
    end
  end

  defp start_dev_server(state) do
    port =
      {:spawn_executable, System.find_executable("npm")}
      |> Port.open([:binary, args: @vite_dev_cmd])

    Process.register(port, :vite_server)
    Process.link(port)

    %{state | vite_server: port}
  end

  defp start_timeout(state = %{existing_vite_pids: pids}) do
    spawned_vite_pids =
      get_vite_processes()
      |> Enum.filter(fn pid -> pid not in pids end)

    kill_cmd = fn pid -> "kill -9 #{pid}" end
    kill_vite_pids = spawned_vite_pids |> Enum.map(&kill_cmd.(&1)) |> Enum.join(" & ")

    full_cmd =
      "sleep #{@timeout_sec + 0.15} ; #{kill_vite_pids} #ViteTimeout"

    %{state | timeout: Task.async(fn -> {_, 0} = System.cmd("bash", ["-c", full_cmd]) end)}
  end

  defp cancel_timeout(state = %{timeout: timeout}) do
    Task.shutdown(timeout)

    case System.cmd("bash", [
           "-c",
           "ps aux | grep 'ViteTimeout' | grep -v grep | awk '{print $2}'"
         ]) do
      {timeout_pids, 0} ->
        timeout_pids
        |> String.split("
")
        |> Enum.filter(fn s -> s not in ["", nil] end)
        |> Enum.each(&kill/1)

      _ ->
        :ok
    end

    %{state | timeout: nil}
  end

  defp get_vite_processes do
    case System.cmd("pgrep", ["-af", "vite"]) do
      {output, 0} ->
        output
        |> String.split("
")
        |> Enum.map(&String.trim/1)
        |> Enum.filter(fn string -> string != "" end)

      _ ->
        []
    end
  end

  defp get_pid(nil), do: {:error, :cannot_be_nil}
  defp get_pid(port) when is_port(port), do: Port.info(port)[:os_pid]
  defp get_pid(key) when is_atom(key), do: Process.whereis(key)

  defp kill(nil), do: {:error, :cannot_be_nil}
  defp kill(pid) when is_integer(pid) or is_binary(pid), do: System.cmd("kill", ["-9", pid])
  defp kill(port) when is_port(port), do: port |> get_pid |> kill
  defp kill(pid) when is_pid(pid), do: Process.exit(pid, :kill)
end
`;return a({dir:o,filename:"vite_dev_supervisor.ex",content:r},"gen_vite_supervisor")};var N=p(require("path"));var ee=async(e,t,n)=>{let o=N.default.join(n,`lib/${e}_web/application.ex`),r=[["REPLACE",new RegExp(`${t}Web\\.Endpoint\\n\\s+\\]`),`
      ${t}Web.Endpoint,
      (if (Mix.env() == :dev), do: {${t}.ViteDevSupervisor, []})
    ]
    |> Enum.filter(&(&1 != nil))
`]];return i({file:o,injections:r},"inject_vite_supervisor_to_application_ex")};var te=async({projectName:e,projectNameCamel:t,appdir:n,libdir:o,uidir:r,webdir:c})=>{f({projectName:e,projectNameCamel:t,appdir:n,libdir:o,uidir:r,webdir:c},"init_react_app_with_vite"),l({level:2,color:"BLUE"},`
Generating React app: ${e}_ui with vite ...`);let s=await x({command:`npx create-vite@latest ${e}_ui --template react-ts --no-install`,dir:n},"init_react_app_with_vite");return l({level:2,color:"BLUE"},`
Configuring Vite build output and aliases...`),[await Y(e,r),await H(e,r),await Z(e,t,o),await ee(e,t,c)].flat()};var ne=require("path");var oe=async e=>{let t=(0,ne.join)(e,"/lib/typescript/utils/");return a({dir:t,filename:"lorem.ts",content:`
import { LoremIpsum } from "lorem-ipsum";

const Lorem = new LoremIpsum();
export default Lorem;
`},"gen_lorem_utils")};var re=require("path");var ie=async e=>{let t=(0,re.join)(e,"lib/typescript/requests");return a({dir:t,filename:"index.tsx",content:`
import { Dispatch } from "redux";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import merge from "deepmerge";

interface GenericAppState {
  RequestsStore: RequestsStoreState;
  [key: string]: any;
}

type AppRequest = {
  name: string;
  request: Promise<any>;
  details: requestAPIinterface;
};

interface RequestsStoreState {
  activeRequests: {
    [key: string]: object;
  };
}

const initialRequestsState: RequestsStoreState = {
  activeRequests: {},
};

const requestSlice = createSlice({
  name: "requests",
  initialState: initialRequestsState,
  reducers: {
    addRequest(
      state: RequestsStoreState,
      { payload }: PayloadAction<AppRequest>
    ) {
      state.activeRequests = {
        ...state.activeRequests,
        [payload.name]: payload.request,
      };
    },
    completeRequest(
      state: RequestsStoreState,
      { payload }: PayloadAction<string>
    ) {
      delete state.activeRequests[payload];
    },
  },
});
const requestReducer = requestSlice.reducer;

const isLoading = (state: GenericAppState, key: string | null = null) => {
  const requests = state.requestsStore.activeRequests;
  return key ? !!requests[key] : !!Object.keys(requests).length;
};

type requestAPIinterface = {
  name: string;
  api_url_key: string;
  route: string;
  options?: RequestInit;
  callback?: Function;
};
const defaultOptions = {
  method: "GET",
  headers: {
    "Content-Type": "application/json",
  },
};

const API = async (details: requestAPIinterface, dispatch: Dispatch) => {
  const { name, api_url_key, route, options, callback } = details;
  const req = new Promise<any>(async (resolve, reject) => {

    const handleError = (err: string, rej: Function) => {
      console.error(err);
      rej(err);
      dispatch(completeRequest(name));
    };
    const handleSuccess = (data: any, res: Function) => {
      if (callback) callback(data);
      res(data);
      dispatch(completeRequest(name));
    };

    try {
      const API_URL = import.meta.env[api_url_key] || "http://localhost:4000/api/",
        reqOptions = merge(defaultOptions, options || {});

      const res = await fetch(\`\${API_URL}/\${route}\`, reqOptions)
        .catch((err) => handleError(String(err), reject));

      if (!res?.ok)
        handleError(
          \`\${API_URL} request failed: \${res?.status}\\n\${res?.statusText}\`,
          reject
        );

      handleSuccess(await res?.json(), resolve);
    } catch (error) {
      handleError(String(error), reject);
    }
  });

  dispatch(addRequest({ name, details, request: req }));
  return (await req).data;
};

const Request = { API };

export const { addRequest, completeRequest } = requestSlice.actions;
export type { AppRequest, RequestsStoreState, requestAPIinterface, GenericAppState };
export {
  initialRequestsState,
  requestReducer,
  isLoading,
  Request,
};
export default requestSlice;
`},"gen_request_lib")};var se=require("path");var ae=async(e,t)=>{let n=(0,se.join)(t,"/src/store"),o=`
import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { RequestsStoreState, requestReducer } from "@requests/index"; 


type ${e}State = {
    requestsStore: RequestsStoreState;
};

const ${e}Store = configureStore({
  reducer: combineReducers({
    requestsStore: requestReducer,
  }),
      middleware: (getDefaultMiddleware) => getDefaultMiddleware({
    serializableCheck: {
      ignoredActionPaths: ['payload.details.callback', 'payload.request'],
      ignoredPaths: ["requestsStore.activeRequests"],
    },
  }),
    // devTools: {
    // actionsDenylist: ['add_request', 'complete_request'],
    // },
});

export { ${e}Store };
export type { ${e}State };
        `;return a({dir:n,filename:"index.tsx",content:o},"gen_store")};var ce=p(require("path"));var le=async(e,t)=>{let n=ce.default.join(t,"src/App.tsx"),o=[["AFTER",/import\s+['"]\.\/App\.css['"]/,`
import { Provider } from 'react-redux';
 import { ${e}Store } from './store';`],["AFTER",/\<\>/,`
<Provider store={${e}Store}>`],["BEFORE",/\<\/\>/,`</Provider>
`]];return i({file:n,injections:o},"inject_redux_provider")};var pe=p(require("path"));var ue=async(e,t)=>{let n=pe.default.join(t,"package.json"),o=[["AFTER",/\"scripts\":\s+\{/,`
    "postinstall": "ln -s $(pwd)/node_modules ../${e}/lib/typescript/node_modules",`]];return i({file:n,injections:o},"inject_package_scripts")};var de=p(require("path"));var me=async e=>{let t=de.default.join(e,"package.json"),n=[["AFTER",/\"dependencies\":\s+\{/,`
    "@reduxjs/toolkit": "^2.3.0",
    "@types/react-redux": "^7.1.34",
    "deepmerge": "^4.3.1",
    "react-redux": "^9.1.2",
    "mincurrypipe": "^3.0.0",`],["AFTER",/\"devDependencies\":\s+\{/,`
    "@babel/plugin-transform-private-property-in-object": "^7.25.9",
    "@types/node": "^22.10.0",
    "lorem-ipsum": "^2.0.8",`]];return i({file:t,injections:n},"inject_react_deps")};var _e=async({projectName:e,projectNameCamel:t,uidir:n,libdir:o})=>(f({projectName:e,projectNameCamel:t,uidir:n,libdir:o},"build_tool_agnostic_init_tasks"),[await Promise.all([ae(t,n),le(t,n),oe(o),ie(o),ue(e,n),me(n)]).catch(console.error)].flat());var fe=p(require("path"));var ge=async(e,t)=>{let n=fe.default.join(t,"mix.exs"),o=[["AFTER",/apps_path\:\s\"apps\"\,/,`
  apps: [:${e}, :${e}_web],`]];return i({file:n,injections:o},"inject_app_declarations")};var ye=p(require("path"));var he=async(e,t)=>{let n=ye.default.join(t,"config/dev.exs"),o=[["BEFORE",/config\s*:\w+\s*,\s*\w+\.\s*Endpoint\s*,/,`config :${e}, CORSPlug, origin: "*"
`],["REPLACE",/(?<=config\s+:\w+,\s+\w+\.Repo,(\n\s+\w+:\s+[^\n]+){0,10}\n\s+database:\s+\")[^\n]+(?=\",)/,"postgres"]];return i({file:n,injections:o},"inject_dev_config")};var L=p(require("path"));var vt=async(e,t)=>{let n=L.default.join(t,"mix.exs"),o=[["AFTER",/defp\sdeps\sdo\s*\n{0,5}\s*\[/,`
      {:cors_plug, "~> 2.0"},`]];return i({file:n,injections:o},"inject_web_app_libs")},jt=async(e,t)=>Promise.resolve(!0),bt=async e=>{let t=L.default.join(e,"mix.exs"),n=[["AFTER",/\{\:ecto_sql\, \".*\"\}\,/,`
      {:scrivener_ecto, "~> 3.0"},`]];return i({file:t,injections:n},"inject_app_libs")},xe=async(e,{WebDir:t,AppDir:n,UmbrellaDir:o,LibDir:r})=>Promise.all([vt(e,t||""),bt(r||""),jt(e,o||"")]);var ve=p(require("path"));var je=async(e,t)=>{let n=ve.default.join(t,`lib/${e}_web/endpoint.ex`),o=[["BEFORE",/plug\sPlug\.MethodOverride/,`plug CORSPlug, origin: Application.compile_env(:${e}, CORSPlug)[:origin]
`]];return i({file:n,injections:o},"inject_web_endpoint")};var be=require("path");var ke=async(e,t)=>{let n=(0,be.join)(t||"","/lib/utils"),o=`
defmodule ${e}.Utils.Chunk do
  @size 1000

  @doc """
  Applies a function to a list in chunks with specified or default chunk size.
  """
  def apply(list, fun, size \\\\ @size) do
    list
    |> Enum.chunk_every(size)
    |> Enum.map(&fun.(&1))
  end

  @doc """
  Given a chunked list of :ok, :partial_success, or :error tuples, in
  {:status, succeeded_list, failed_list} or
  {:status, success_count, fail_count} format,
  reduce the result lists, counts, and status to summarize the entire operation.
  """
  def flat_reduce(chunked_tuples) do
    case List.first(chunked_tuples) do
      {status, s, f} when is_atom(status) and is_list(s) and is_list(f) ->
        chunked_tuples
        |> Enum.reduce({:ok, [], []}, fn
          # {:status, created [], invalid []}
          # destructured chunk, destructured accumulator -> accumulated result
          {:ok, c, []}, {:ok, csum, []} -> {:ok, csum ++ c, []}
          {:ok, c, []}, {_, csum, isum} -> {:partial_success, csum ++ c, isum}
          {:partial_success, c, i}, {_, csum, isum} -> {:partial_success, csum ++ c, isum ++ i}
          {:error, [], i}, {_, [], isum} -> {:error, [], isum ++ i}
          {:error, [], i}, {_, csum, isum} -> {:partial_success, csum, isum ++ i}
        end)

      {status, s, f} when is_atom(status) and is_integer(s) and is_integer(f) ->
        chunked_tuples
        |> Enum.reduce({:ok, 0, 0}, fn
          # {:status, succeeded 0, failed 0}
          # destructured chunk, destructured accumulator -> accumulated result
          {:ok, s, 0}, {:ok, ssum, 0} -> {:ok, ssum + s, 0}
          {:ok, s, 0}, {_, ssum, fsum} -> {:partial_success, ssum + s, fsum}
          {:partial_success, s, f}, {_, ssum, fsum} -> {:partial_success, ssum + s, fsum + f}
          {:error, 0, f}, {_, 0, fsum} -> {:error, 0, fsum + f}
          {:error, 0, f}, {_, ssum, fsum} -> {:partial_success, ssum, fsum + f}
        end)
    end
  end

  @doc """
  Given a list of records, prep the chunk for bulk db edits
  """
  def prep(changesets, opts \\\\ %{}) do
    def_opts = %{
      inserted_at?: true
    }

    %{inserted_at?: inserted} = Map.merge(def_opts, opts)
    timestamp = NaiveDateTime.utc_now() |> NaiveDateTime.truncate(:second)

    changesets
    |> Enum.map(& &1.changes)
    |> Enum.map(fn record ->
      new_properties =
        case [inserted] do
          [true] -> Map.merge(record, %{inserted_at: timestamp, updated_at: timestamp})
          [false] -> Map.delete(record, :inserted_at) |> Map.merge(%{updated_at: timestamp})
        end

      Map.merge(record, new_properties)
    end)
  end
end
`;return a({dir:n,filename:"chunk.ex",content:o},"gen_chunk_util")};var Ee=require("path");var we=async(e,t)=>{let n=(0,Ee.join)(t||"","/lib/utils"),o=`
defmodule ${e}.Utils.DynamicQuery do
  import Ecto.Query
  @moduledoc """
  A utility module for building dynamic queries based on controller level restful query params.
  Pass the params and schema to by_schema to convert the restful query to a database query.
  """

  @doc """
  Given a map of controller level restful query params and a schema module,
      cast controller parameters to schema types for dynamic Ecto query construction.
  """
  def by_schema(controller_params, schema_module) do
    field_types = get_schema_field_types(schema_module)

    case validate_params(controller_params, field_types) do
      {:ok, parsed_params} ->
        query = Enum.reduce(parsed_params, from(s in schema_module), &apply_filter/2)

        opts =
          Enum.reduce(parsed_params, %{}, fn {key, op, value}, acc ->
            Map.put(acc, key, "#{op} #{value}")
          end)

        {:ok, query, opts}

      error_forward ->
        error_forward
    end
  end

  @doc """
  Given a schema module, return a map of field names to their types.
  """
  def get_schema_field_types(schema_module) when is_atom(schema_module) do
    schema_module.__schema__(:fields)
    |> Enum.map(fn field ->
      {field, schema_module.__schema__(:type, field)}
    end)
    |> Enum.into(%{})
  end

  @doc """
  Given controller level params and designated field types, validate the mathmatical operator and return a list of parsed params.
  """
  def validate_params(params, field_types) do
    Enum.reduce_while(params, {:ok, []}, fn {key, value}, {:ok, acc} ->
      case parse_param(key, value, field_types) do
        {:ok, parsed_param} -> {:cont, {:ok, [parsed_param | acc]}}
        {:error, message} -> {:halt, {:error, message}}
      end
    end)
  end

  @doc """
  Build query with parsed params.
  """
  def apply_filter({field, operator, value}, query) do
    field_atom = String.to_atom(field)

    dynamic_clause =
      case operator do
        "<" -> dynamic([u], field(u, ^field_atom) < ^value)
        ">" -> dynamic([u], field(u, ^field_atom) > ^value)
        "<=" -> dynamic([u], field(u, ^field_atom) <= ^value)
        ">=" -> dynamic([u], field(u, ^field_atom) >= ^value)
        "=" -> dynamic([u], field(u, ^field_atom) == ^value)
        _ -> raise "Invalid operator: #{operator}"
      end

    where(query, ^dynamic_clause)
  end

  # Check type of each param and build where clauses
  defp parse_param(key, value, field_types) do
    reg =
      ~r/(?<key>[_a-zA-z0-9]+)(?<operator>[ =<>])(?<value>.*)/
      |> Regex.named_captures(key)

    case reg do
      nil ->
        {:ok, {key, "=", value}}

      %{"key" => k, "operator" => o, "value" => v} ->
        validate_param_type(k, o, v, field_types)
    end
  end

  # Validate type based on the schema's field types
  defp validate_param_type(key, operator, value, field_types) do
    expected_type = Map.get(field_types, String.to_atom(key))

    case {expected_type, parse_value(value, expected_type)} do
      {nil, _} -> {:error, "Unknown field #{key}"}
      {_, :error} -> {:error, "Invalid value for #{key}. Expected a #{expected_type}."}
      {_, parsed_value} -> {:ok, {key, operator, parsed_value}}
    end
  end

  # Parse the value based on expected type
  defp parse_value(value, :integer) do
    case Integer.parse(value) do
      {v, ""} -> v
      _ -> :error
    end
  end

  defp parse_value(value, :string), do: value
end

defmodule ${e}.Plugs.ListAsJSON do
  @moduledoc """
  A plug for controllers that allows lists to be sent as top-level JSON arrays
  without needing to wrap them in an object. It detects the "_json" param and
  elevates it to the top level.
  """

  def init(options), do: options

  def call(%Plug.Conn{params: %{"_json" => json_data}} = conn, _opts) do
    %{conn | params: json_data}
  end

  def call(conn, _opts), do: conn
end
`;return a({dir:n,filename:"dynamic_query.ex",content:o},"gen_dynamic_query_util")};var Se=require("path");var Re=async(e,t)=>{let n=(0,Se.join)(t||"","/lib/utils"),o=`
defmodule ${e}.Utils.Paginate do
  @doc """
  Utility functions for pagination with Scriniver Lib.
  """

  def apply(query, repo, pagination_options \\\\ %{}) do
    page = repo.paginate(query, default(pagination_options))
    res = page |> Map.get(:entries)
    params = Map.drop(page, [:entries])

    {:ok, res, Map.from_struct(params)}
  end

  def default(opts) do
    %{
      page: 1,
      page_size: 100,
      max_page_size: 1000
    }
    |> Map.merge(opts)
  end

  def split_page_opts(opts) do
    page_opts = ["page", "page_size", "max_page_size", "filter", "select", "sort"]

    {Map.drop(opts, page_opts), Map.take(opts, page_opts)}
  end
end
`;return a({dir:n,filename:"paginate.ex",content:o},"gen_paginate_util")};var $e=require("path");var Ie=async(e,t)=>{let n=(0,$e.join)(t||"","/lib/utils"),o=`
defmodule ${e}.Utils.MapUtil do
  def get(map, key, default \\\\ nil),
    do: Map.get(map, key, false) || Map.get(map, Atom.to_string(key), default)

  def str_to_atom(map),
    do:
      Map.keys(map)
      |> Enum.reduce(%{}, fn key, acc -> Map.put(acc, to_atom(key), Map.get(map, key)) end)

  defp to_atom(string) when is_binary(string), do: String.to_atom(string)
  defp to_atom(atom) when is_atom(atom), do: atom

  def id_list_from(list) when is_list(list) do
    Enum.map(list, fn 
      s when is_binary(s) -> s; 
      m when is_map(m) -> get(m, :id);
    end)
  end
end
`;return a({dir:n,filename:"map.ex",content:o},"gen_map_util")};var qe=async(e,t)=>Promise.all([ke(e,t),we(e,t),Re(e,t),Ie(e,t)]);var Pe=p(require("path"));var Oe=async e=>{let{LibDir:t,AppNameSnake:n}=e||{},o=Pe.default.join(t||".",`lib/${n}/repo.ex`),r=[["BEFORE",/end[\s\n]*$/,`  use Scrivener
`]];return i({file:o,injections:r},"inject_scrinever")};var Fe=require("path");var Le=async(e,t)=>{let n=(0,Fe.join)(t,"/lib/mix/tasks"),o=`
defmodule Mix.Tasks.Compile.CustomCompiler do
  use Mix.Task.Compiler

  @impl Mix.Task.Compiler
  def run(_args) do
    case System.cmd("npm", ["run", "build", "--emptyOutDir"], stderr_to_stdout: true, cd: "apps/${e}_ui") do
      {output, 0} ->
        IO.puts(output)
        {:ok, []}
      {output, _exit_code} ->
        IO.puts(:stderr, output)
        {:error, []}
    end
  end

  @impl Mix.Task.Compiler
  def manifests, do: []
end
`;return a({dir:n,filename:"custom_compiler.ex",content:o},"gen_custom_compiler")};var Te=require("path");var Me=async(e,t,n)=>{let o=(0,Te.join)(n,`/lib/${e}_web/controllers`),r=`
defmodule ${t}Web.PageController do
  use ${t}Web, :controller

  def index(conn, _params) do
    # Serve the static index.html file
    conn
    |> put_resp_content_type("text/html")
    |> send_file(200, Path.join([:code.priv_dir(:${e}_web), "static", "index.html"]))
  end
end

`;return a({dir:o,filename:"page_controller.ex",content:r},"gen_page_controller")};var Ce=p(require("path"));var De=async(e,t)=>{let n=Ce.default.join(t,"mix.exs"),o=[["AFTER",/def\sproject\s+do[\s\n]+\[/,`compilers: Mix.compilers() ++ [:custom_compiler],
`]];return i({file:n,injections:o},"inject_custom_compile_to_mix_exs")};var Ae=p(require("path"));var Ue=async(e,t,n)=>{let o=Ae.default.join(n,`lib/${e}_web/router.ex`),r=[["BEFORE",/pipeline\s+\:api\s+do/,`
  scope "/", ${t}Web do
    get "/", PageController, :index
  end
`]];return i({file:o,injections:r},"inject_page_to_router")};var Ge=p(require("path"));var Be=async(e,t)=>{let n=Ge.default.join(t,`lib/${e}_web/endpoint.ex`),o=[["REPLACE",/(?<=plug\(Plug\.Static\,.*only:\s)[^\n]*/s,"~w(assets fonts images js css vite.svg index.html)"]];return i({file:n,injections:o},"inject_static_output_to_endpoint")};var We=async({AppName:e,AppNameCamel:t,WebDir:n,LibDir:o})=>{f({AppName:e,AppNameCamel:t,WebDir:n,LibDir:o},"configure_phoenix_to_serve_react");let r=await Me(e,t,n),c=await Be(e,n),s=await Ue(e,t,n),d=await Le(e,o),u=await De(e,n);return[r,c,s,d,u].flat()};var ze=p(require("path"));var Ve=async(e,t)=>{let n=ze.default.join(t,"mix.exs"),o=[["BEFORE",/defp\s+aliases\s+do[\s\n]+\[/,`
  defp npm_install(_) do
    Mix.shell().cmd("npm install", cd: "apps/${e}_ui")
  end


`],["AFTER",/defp\s+aliases\s+do[\s\n]+\[/,`
"deps.get": ["deps.get", &npm_install/1],`]];return i({file:n,injections:o},"inject_deps_get_aliases_to_mix_exs")};var Je=require("path");var Ke=async(e,t)=>{let n=(0,Je.join)(t,"/lib/mix/tasks/"),o=`
defmodule Mix.Tasks.CustomFormatter do
  use Mix.Task

  def run(args \\\\ []) do
    IO.puts("Immutable Formatter")

    {js_paths, ex_paths} =
      Enum.split_with(args, fn path ->
        String.contains?(path, "apps/${e}_ui") || String.ends_with?(path, ".ts") ||
          String.ends_with?(path, ".tsx")
      end)

    js_paths = Enum.map(js_paths, &String.replace(&1, ~r/(.*){0,1}apps\\/${e}_ui\\//, ""))

    IO.puts("Formatting Elixir files...")
    Mix.Task.run("format", ex_paths)

    IO.puts("Formatting TS files...")
    format_react_files(js_paths)

    IO.puts("Complete.")
  end

  defp format_react_files(paths) do
    js_paths = Enum.join(paths, " ")

    {_result, 0} =
      System.cmd("bash", ["-c", "npm run format #{js_paths}"], cd: "./apps/${e}_ui")

    # IO.puts(result)
  end
end
`;return a({dir:n,filename:"custom_formatter.ex",content:o},"gen_custom_formatter")};var Ye=p(require("path"));var Qe=async e=>{let t=Ye.default.join(e,"mix.exs"),n=[["AFTER",/defp\s+aliases\s+do[\s\n]+\[/s,`
format: "custom_formatter",`]];return i({file:t,injections:n},"inject_custom_format_to_mix_exs")};var He=async({AppName:e,LibDir:t})=>{f({AppName:e,LibDir:t},"configure_phoenix_to_format_react");let n=Ke(e,t),o=Qe(t);return[n,o].flat()};var Xe=require("path");var Ze=async({WebDir:e,AppNameCamel:t,AppNameSnake:n})=>{let o=(0,Xe.join)(e||".",`lib/${n}_web/controllers`),r=`
defmodule ${t}Web.FallbackController do
  @moduledoc """
  Translates controller action results into valid \`Plug.Conn\` responses.

  See \`Phoenix.Controller.action_fallback/1\` for more details.
  """
  use ${t}Web, :controller

  alias Ecto.Changeset

  # This clause handles errors returned by Ecto's insert/update/delete.
  def call(conn, {:error, %Ecto.Changeset{} = changeset}) do
    conn
    |> put_status(:unprocessable_entity)
    |> json(error_transform(changeset))
  end

  def call(conn, {:error, [], failed_changesets}) when is_list(failed_changesets) do
    conn
    |> put_status(:unprocessable_entity)
    |> json(%{errors: error_transform(failed_changesets)})
  end

  # This clause is an example of how to handle resources that cannot be found.
  def call(conn, {:error, :not_found}) do
    conn
    |> put_status(:not_found)
    |> put_view(html: ${t}Web.ErrorHTML, json: ${t}Web.ErrorJSON)
    |> render(:"404")
  end

  def call(conn, {:error, status, error}) when is_atom(error) do
    conn
    |> put_status(status)
    |> json(%{error: Atom.to_string(error)})
  end

  def call(%Plug.Conn{private: %{plug_error: %{status: status, message: message}}} = conn) do
    conn
    |> put_status(status)
    |> json(%{error: message})
  end

  def error_transform(changesets) when is_list(changesets),
    do: changesets |> Enum.map(&error_transform/1)

  def error_transform(%Changeset{} = cs) do
    errors =
      Enum.reduce(cs.errors, %{}, fn {key, {reason, _}}, acc -> Map.put(acc, key, reason) end)

    Map.put(cs.changes, :errors, errors)
  end
end
`;return a({dir:o,filename:"fallback_controller.ex",content:r},"gen_fallback_controller")};var Ne=require("path");var et=async(e,t)=>{let n=(0,Ne.join)(t,"/lib/mix/plugs/"),o=`
defmodule ${e}.Plugs.ValidateBinaryId do
  import Plug.Conn
  alias Ecto.UUID

  def init(opts) do
    case Keyword.get(opts, :fallback) do
      controller ->
        case Code.ensure_loaded?(controller) do
          true -> opts
          _ -> {:error, :validate_fallback_controller_not_loaded}
        end

      _ ->
        {:error, :validate_requires_fallback_controller}
    end
  end

  def call(conn, opts) do
    with id when not is_nil(id) <- Map.get(conn.params, "id"),
         {:ok, _} <- UUID.cast(id) do
      conn
    else
      nil -> conn
      _ ->
        controller = Keyword.get(opts, :fallback, ${e}Web.FallbackController)

        conn
        |> put_private(:plug_error, %{
          status: :bad_request,
          message: "Unable to cast id as UUID"
        })
        |> controller.call
    end
  end
end
`;return a({dir:n,filename:"validate_uuid.ex",content:o},"gen_id_validation_plug")};var tt=async({projectName:e,projectNameCamel:t,umbrellaDir:n,libdir:o,webdir:r})=>{f({projectName:e,projectNameCamel:t,umbrellaDir:n,libdir:o,webdir:r},"init_phoenix_umbrella_app"),l({level:2,color:"BLUE"},`
Generating Phoenix project...`);let c=await x({command:`mix phx.new ${e} --no-live --no-html --no-assets --binary-id --umbrella --no-install`,dir:"."},"init_phoenix_umbrella_app"),s=await ge(e,n),d=await Promise.all([xe(e,{WebDir:r,LibDir:o}),je(e,r),he(e,n),Oe({LibDir:o,AppNameSnake:e}),qe(t,o),et(t,o),Ze({WebDir:r,AppNameCamel:t,AppNameSnake:e})]),u=await We({AppName:e,AppNameCamel:t,WebDir:r,LibDir:o}),g=await He({AppName:e,LibDir:o}),_=await Ve(e,n);return[c,s,d,u,g,_].flat()};C(5);var nt=process.argv.slice(2);async function kt(){nt.length<1&&(console.error(`Usage: node init_proj.js <project_name>
   Or: immutable -init <project_name>`),process.exit(1));let e=nt[0];e=e.toLowerCase().replace(/[\s-]/g,"_").replace(/[^a-z0-9_]/g,"");let t=e.split("_").map(_=>_.charAt(0).toUpperCase()+_.slice(1)).join(""),n=process.cwd(),o=(0,j.join)(n,`${e}_umbrella`),r=(0,j.join)(o,"apps"),c=(0,j.join)(r,e),s=(0,j.join)(r,`${e}_ui`),d=(0,j.join)(r,`${e}_web`);B(o),l({level:1,color:"GREEN"},`

 Generating ${e} App with Immutable Stack

`),await tt({projectName:e,projectNameCamel:t,umbrellaDir:o,libdir:c,webdir:d}),await te({projectName:e,projectNameCamel:t,appdir:r,uidir:s,webdir:d,libdir:c}),await _e({projectName:e,projectNameCamel:t,uidir:s,libdir:c}),U(o,`init_project_${e}`);let u=await x({command:"mix deps.get",dir:o},"init_proj"),g=await x({command:"mix compile",dir:o},"init_proj");l({level:1,color:"GREEN"},`

Initialization Complete.

Generated ${e}_umbrella`),l({level:1,color:"BLUE"},`    in ${n}

`)}kt().catch(console.error);
